# ATO local preview

Requires Node.js 20 or later. No dependency installation is needed.

```sh
npm start
```

Open http://127.0.0.1:3000. Enter **any non-empty username**, then **any non-empty password**, then **any six-digit code** such as `123456`.

The local server enables mock mode only for pages it serves on loopback. It serves the original HTML/CSS/assets and local `/api/Login/*` and `/api/calculate` endpoints. It never proxies API requests to QA or production. Normal hosting does not inject the mock bootstrap, so the existing API configuration and validation remain active there.

The welcome and rewards pages display synthetic employee data. Medical plan, medical/dental coverage, HSA contribution, and retirement contribution controls update illustrative totals. These sample formulas do not reproduce `eac2/calc.xlsx` or production benefit rules. The yellow banner identifies mock mode on every page.

Forgot password, resend code, password reset, token refresh, and logout are also mocked. Usernames are held in server memory; passwords are neither stored nor logged. Restarting the server clears local sessions. Use `Ctrl+C` to stop; use `PORT=3001 npm start` to choose another port.

This preview covers the **root PremierCo portal**. The separate `demo/` Aon Canada application and externally hosted video content are not mocked.

```sh
npm test
```
