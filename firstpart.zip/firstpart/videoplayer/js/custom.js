var myPlayer;
var getQueryString = function (key) {
    var reg = new RegExp('[?&]' + key + '=([^&#]*)', 'i');
    var tempString = reg.exec(window.location.href);
    return tempString ? tempString[1].replace(/%20/gi, '').toUpperCase() : null;
};

var brightcoveId = getQueryString('v');

if (!brightcoveId) {
    $('#preload').hide();
    $('#error').show();
}

videojs.getPlayer('myPlayerID').ready(function () {
    myPlayer = this;
    fitPlayerMenus(myPlayer);
    $(".vjs-loading-spinner .vjs-control-text")
        .text("Video Player is loaded.");
    var videoWidth;
    var videoHeight;
    myPlayer.catalog.getVideo(brightcoveId, function (error, video) {
        if (!error) {
            myPlayer.catalog.load(video);
            var name = myPlayer.mediainfo.name;
            $("title, h1").html(name);
            $("#video, .containing-block").fadeIn(400);
            for (i = 0; i < video.sources.length; i++) {
                videoWidth = video.sources[i].width;
                videoHeight = video.sources[i].height;
                if (videoWidth && videoHeight) {
                    break;
                }
            }
            var paddingTop = (videoHeight / videoWidth) * 100 > 56.25 ? 75 : 56.25;
            $('#player .outer-container').css('padding-top', paddingTop + '%');
            myPlayer.play();

            loadTR_AD();

        } else {
            console.log(error);
            window.location = 'playlist.html?v=' + brightcoveId;
        }
    });
});

function loadTR_AD(){
    if (myPlayer.mediainfo.customFields['ad_video_version_id']) {
        $(".adStatement").show();
        $(".adLink").attr("href", "./player.html?v=" + myPlayer.mediainfo.customFields['ad_video_version_id']);
    } else {
        $(".adStatement").hide();
    }

    if (myPlayer.mediainfo.transcripts != undefined && myPlayer.mediainfo.transcripts[1]) {
        $(".trStatement").show();

        var link = document.getElementById('trLink');

        link.onclick = function (event) {
            event.preventDefault();
            const element = document.getElementsByClassName('transcriptWindow')[0];
            const isHidden = window.getComputedStyle(element).display === 'none';
            if (isHidden) {
                element.style.display = 'block';
            } else {
                element.style.display = 'none';
            }
        };

        fetch(myPlayer.mediainfo.transcripts[1].src)
            .then(response => response.text())
            .then(data => {
                console.log(data);
                $(".transcriptContent").html("<strong>Transcript:</strong> " + data);
            })
            .catch(error => {
                $(".transcriptContent").html(error);
            });

    } else {
        $(".trStatement").hide();
    }

}

// Position compact menus in the viewport, outside the clipped video frame.
function fitPlayerMenus(player) {
    var element = player.el();
    var frame;

    function positionMenus() {
        frame = null;
        if (!window.matchMedia('(max-width: 480px)').matches) return;
        var viewportWidth = document.documentElement.clientWidth;
        var viewportHeight = window.innerHeight;
        var margin = 8;
        var width = Math.min(240, viewportWidth - margin * 2);

        element.querySelectorAll('.vjs-control-bar .vjs-menu-button-popup > .vjs-menu').forEach(function (menu) {
            var button = menu.parentElement.querySelector('button[aria-haspopup]');
            if (button && button.getAttribute('aria-expanded') === 'true') menu.classList.remove('video-menu-dismissed');
            if (window.getComputedStyle(menu).display === 'none') return;
            var content = menu.querySelector('.vjs-menu-content');
            if (!button || !content) return;
            var anchor = button.getBoundingClientRect();
            var above = Math.max(0, anchor.top - margin);
            var below = Math.max(0, viewportHeight - anchor.bottom - margin);
            var openAbove = above >= below;
            var available = Math.max(1, openAbove ? above : below);
            menu.style.setProperty('--video-menu-width', width + 'px');
            menu.style.setProperty('--video-menu-max-height', available + 'px');
            var height = Math.min(content.scrollHeight, available);
            var top = openAbove ? anchor.top - height : anchor.bottom;
            var left = Math.max(margin, Math.min(anchor.right - width, viewportWidth - width - margin));
            menu.style.setProperty('--video-menu-top', Math.max(margin, Math.min(top, viewportHeight - height - margin)) + 'px');
            menu.style.setProperty('--video-menu-left', left + 'px');
        });
    }

    function schedule() {
        if (frame == null) frame = window.requestAnimationFrame(positionMenus);
    }

    function handleInteraction(event) {
        var trigger = event.target.closest('button[aria-haspopup]');
        if (event.type === 'keydown' && event.key === 'Escape') {
            var menu = event.target.closest('.vjs-menu');
            if (menu) {
                trigger = menu.parentElement.querySelector('button[aria-haspopup]');
                if (trigger) {
                    event.preventDefault();
                    event.stopPropagation();
                    if (trigger.getAttribute('aria-expanded') === 'true') trigger.click();
                    menu.classList.add('video-menu-dismissed');
                    trigger.focus();
                }
            }
        } else if (trigger && (event.type === 'click' ||
            (event.type === 'keydown' && ['Enter', ' ', 'ArrowDown', 'ArrowUp'].indexOf(event.key) >= 0))) {
            var triggeredMenu = trigger.parentElement.querySelector('.vjs-menu');
            if (triggeredMenu) triggeredMenu.classList.remove('video-menu-dismissed');
        } else if (event.type === 'pointerover') {
            var control = event.target.closest('.vjs-control');
            if (control && !control.contains(event.relatedTarget)) {
                var hoveredMenu = control.querySelector('.vjs-menu');
                if (hoveredMenu) hoveredMenu.classList.remove('video-menu-dismissed');
            }
        }
        schedule();
    }

    // Preserve native selection/navigation and return Escape focus to its trigger.
    var observer = new MutationObserver(schedule);
    observer.observe(element, { subtree: true, attributes: true, attributeFilter: ['aria-expanded'] });
    ['click', 'pointerover', 'focusin', 'keydown'].forEach(function (event) {
        element.addEventListener(event, handleInteraction, true);
    });
    window.addEventListener('resize', schedule);
    window.addEventListener('scroll', schedule, true);
    player.on('fullscreenchange', schedule);
    player.on('dispose', function () {
        observer.disconnect();
        window.cancelAnimationFrame(frame);
        ['click', 'pointerover', 'focusin', 'keydown'].forEach(function (event) {
            element.removeEventListener(event, handleInteraction, true);
        });
        window.removeEventListener('resize', schedule);
        window.removeEventListener('scroll', schedule, true);
    });
}
