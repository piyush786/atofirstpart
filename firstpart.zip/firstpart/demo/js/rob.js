((basicHD = 0),
  (basicDental = 0),
  (basiclife = 0),
  (basicadd = 0),
  (basicltd = 0),
  (provmed = 0),
  (eieecost = 0),
  (eiercost = 0),
  (cppeecost = 0),
  (cppercost = 0),
  (QPIPeeCost = 0),
  (QPIPerCost = 0),
  (rrspEeConts = 0),
  (rrspErConts = 0),
  (espEeConts = 0),
  (espErConts = 0));
((robBonus1 = 0),
  (robBonus2 = 0),
  (robBonus3 = 0),
  (robBonus4 = 0),
  (robBonus5 = 0),
  (robBonus6 = 0),
  (robBonus7 = 0),
  (robBonus8 = 0),
  (robBonus9 = 0),
  (robBonus10 = 0),
  (robBonus11 = 0));
((robPay = 0), (robLTI = ""));

//isRecruit = (location.href.indexOf("params=") >= 0 || document.getElementById("BusUnit").innerHTML=="C") ? 1 : 0;
//isRecruit = (location.href.indexOf("params=") >= 0 || (location.href.indexOf("params=") <= 0 && document.getElementById("BusUnit").innerHTML == "C")) ? 1 : 0;

// commented by Pooja : start

// if(document.getElementById("BusUnit")){//console.log("BusUnit")
// isRecruit = (location.href.indexOf("params=") >= 0 || (location.href.indexOf("params=") <= 0 && document.getElementById("BusUnit").innerHTML=="XXX")) ? 1 : 0;
//                                        //console.log("isRecruit: " + isRecruit)
// }else{
// isRecruit = (location.href.indexOf("params=") >= 0 || (location.href.indexOf("params=") <= 0)) ? 1 : 0;
//   //console.log("nonBU isRecruit: " + isRecruit)
// }

// //2022
// if($("#EmpID").html() == "99999999" || $("#EmpID").html() == "88888888"){
//  isRecruit=1;
// }else{
//  // isRecruit = 0;
// }

// comment : end
//
//console.log("isRecruit",isRecruit)

function robSwitches(modelflag) {
  console.log("robSwitches");
  if (modelflag == true) {
    globalmodelflag = true;
  }
  startpos = location.search.indexOf("params=");
  //if(startpos<0 && weAreComingFromAddNewScreen== false && newSS == false && existingSS == false){
  console.log("weAreComingFromAddNewScreen: " + weAreComingFromAddNewScreen);

  if (
    startpos < 0 &&
    weAreComingFromAddNewScreen == false &&
    location.href.indexOf("?new") < 0 &&
    location.href.indexOf("?ssId=") < 0
  ) {
    console.log("big rob");
    robArray = [];
    robArray[0] = document.getElementById("EmpID").innerHTML;
    robArray[1] = document.getElementById("FirstName").innerHTML;
    robArray[2] = document.getElementById("LastName").innerHTML;
    robArray[3] = document.getElementById("Gender").innerHTML;
    robArray[4] = document.getElementById("Province").innerHTML;
    robArray[5] = document.getElementById("BusUnit").innerHTML;
    robArray[6] = document.getElementById("EmpGroup").innerHTML;
    robArray[7] = document.getElementById("EmpType").innerHTML;
    robArray[8] = document.getElementById("DOB").innerHTML;
    robArray[9] = document.getElementById("DOH").innerHTML;
    robArray[10] = document.getElementById("PData10").innerHTML;
    robArray[11] = document.getElementById("PData11").innerHTML;
    robArray[12] = document.getElementById("PData12").innerHTML;
    robArray[13] = document.getElementById("PData13").innerHTML;
    robArray[14] = document.getElementById("PData14").innerHTML;
    robArray[15] = document.getElementById("PData15").innerHTML;
    robArray[16] = document.getElementById("PData16").innerHTML;
    robArray[17] = document.getElementById("PData17").innerHTML;
    robArray[18] = document.getElementById("PData18").innerHTML;
    robArray[19] = document.getElementById("PData19").innerHTML;
    robArray[20] = document.getElementById("PData20").innerHTML;
    robArray[21] = document.getElementById("otc1").innerHTML;
    robOther1 = robArray[21];
    robArray[22] = document.getElementById("otc2").innerHTML;
    robOther2 = robArray[22];
    robArray[23] = document.getElementById("otc3").innerHTML;
    robOther3 = robArray[23];
    robArray[24] = document.getElementById("otc4").innerHTML;
    robOther4 = robArray[24];
    robArray[25] = document.getElementById("otc5desc").innerHTML;
    robOtcdesc1 = robArray[25];
    robArray[26] = document.getElementById("otc5").innerHTML;
    robOther5 = robArray[26];
    robArray[27] = document.getElementById("otc6desc").innerHTML;
    robOtcdesc1 = robArray[27];
    robArray[28] = document.getElementById("otc6").innerHTML;
    robOther6 = robArray[28];
    robArray[29] = document.getElementById("oth1").innerHTML;
    robOther7 = robArray[29];
    robArray[30] = document.getElementById("oth2").innerHTML;
    robOther8 = robArray[30];
    robArray[31] = document.getElementById("oth3").innerHTML;
    robOther9 = robArray[31];
    robArray[32] = document.getElementById("oth4").innerHTML;
    robOther10 = robArray[32];
    robArray[33] = document.getElementById("oth5desc").innerHTML;
    robOthdesc1 = robArray[23];
    robArray[34] = document.getElementById("oth5").innerHTML;
    robOther11 = robArray[34];
    robArray[35] = document.getElementById("oth6desc").innerHTML;
    robOthdesc2 = robArray[35];
    robArray[36] = document.getElementById("oth6").innerHTML;
    robOther12 = robArray[36];
    robArray[37] = document.getElementById("ob1").innerHTML;
    robOther13 = robArray[37];
    robArray[38] = document.getElementById("ob2").innerHTML;
    robOther14 = robArray[38];
    robArray[39] = document.getElementById("ob3").innerHTML;
    robOther15 = robArray[39];
    robArray[40] = document.getElementById("ob4").innerHTML;
    robOther16 = robArray[40];
    robArray[41] = document.getElementById("ob5desc").innerHTML;
    robObdesc1 = robArray[41];
    robArray[42] = document.getElementById("ob5").innerHTML;
    robOther17 = robArray[42];
    robArray[43] = document.getElementById("ob6desc").innerHTML;
    robObdesc2 = robArray[43];
    robArray[44] = document.getElementById("ob6").innerHTML;
    robOther18 = robArray[44];
    robArray[45] = document.getElementById("lti1").innerHTML;
    robArray[46] = document.getElementById("SavedAsRecruit").innerHTML; // if(parseInt(robArray[46])==1){isRecruit=1}
    robArray[47] = document.getElementById("Pay1").innerHTML;
    robArray[48] = document.getElementById("Pay2").innerHTML;
    robArray[49] = document.getElementById("Pay3").innerHTML;
    robArray[50] = document.getElementById("Pay4").innerHTML;
    robArray[51] = document.getElementById("Pay5").innerHTML;
    robArray[52] = document.getElementById("Pay6").innerHTML;
    robArray[53] = document.getElementById("Pay7").innerHTML;
    robArray[54] = document.getElementById("Pay8").innerHTML;
    robArray[55] = document.getElementById("Pay9").innerHTML;
    robArray[56] = document.getElementById("subtot_Pay").innerHTML;
    robArray[57] = document.getElementById("Flex1").innerHTML;
    robArray[58] = document.getElementById("Flex2").innerHTML;
    robArray[59] = document.getElementById("Flex3").innerHTML;
    robArray[60] = document.getElementById("Flex4").innerHTML;
    robArray[61] = document.getElementById("subtot_Flex").innerHTML;
    robArray[62] = document.getElementById("Sav1").innerHTML;
    robArray[63] = document.getElementById("Sav2").innerHTML;
    robArray[64] = document.getElementById("Sav3").innerHTML;
    robArray[65] = document.getElementById("Sav4").innerHTML;
    robArray[66] = document.getElementById("Sav5").innerHTML;
    robArray[67] = document.getElementById("Sav6").innerHTML;
    robArray[68] = document.getElementById("Sav7").innerHTML;
    robArray[69] = document.getElementById("Sav8").innerHTML;
    robArray[70] = document.getElementById("subtot_Sav").innerHTML;
    robArray[71] = document.getElementById("Other1").innerHTML;
    robArray[72] = document.getElementById("Other2").innerHTML;
    robArray[73] = document.getElementById("Other3").innerHTML;
    robArray[74] = document.getElementById("Other4").innerHTML;
    robArray[75] = document.getElementById("subtot_Other").innerHTML;
    robArray[76] = document.getElementById("Othben1").innerHTML;
    robArray[77] = document.getElementById("Othben2").innerHTML;
    robArray[78] = document.getElementById("Othben3").innerHTML;
    robArray[79] = document.getElementById("Othben4").innerHTML;
    robArray[80] = document.getElementById("subtot_Othben").innerHTML;
    robArray[81] = document.getElementById("Reserve1").innerHTML;
    robArray[82] = document.getElementById("Reserve2").innerHTML;
    robArray[83] = document.getElementById("Reserve3").innerHTML;
    robArray[84] = document.getElementById("Reserve4").innerHTML;
    robArray[85] = document.getElementById("Reserve5").innerHTML;
    robArray[86] = document.getElementById("Reserve6").innerHTML;
    robArray[87] = document.getElementById("Reserve7").innerHTML;
    robArray[88] = document.getElementById("Reserve8").innerHTML;
    robArray[89] = document.getElementById("Reserve9").innerHTML;
    robArray[90] = document.getElementById("subtot_Reserve").innerHTML;
    robArray[91] = document.getElementById("Gov1").innerHTML;
    robArray[92] = document.getElementById("subtot_Gov").innerHTML;
    robArray[93] = document.getElementById("eeCore1").innerHTML;
    robArray[94] = document.getElementById("eeCore2").innerHTML;
    robArray[95] = document.getElementById("eeCore3").innerHTML;
    robArray[96] = document.getElementById("eeCore4").innerHTML;
    robArray[97] = document.getElementById("subtot_eeCore").innerHTML;
    robArray[98] = document.getElementById("erCore1").innerHTML;
    robArray[99] = document.getElementById("erCore2").innerHTML;
    robArray[100] = document.getElementById("erCore3").innerHTML;
    robArray[101] = document.getElementById("erCore4").innerHTML;
    robArray[102] = document.getElementById("subtot_erCore").innerHTML;
    robArray[103] = document.getElementById("eeRetPlan1").innerHTML;
    robArray[104] = document.getElementById("eeRetPlan2").innerHTML;
    robArray[105] = document.getElementById("eeRetPlan3").innerHTML;
    robArray[106] = document.getElementById("eeRetPlan4").innerHTML;
    robArray[107] = document.getElementById("subtot_eeRetPlan").innerHTML;
    robArray[108] = document.getElementById("erRetPlan1").innerHTML;
    robArray[109] = document.getElementById("erRetPlan2").innerHTML;
    robArray[110] = document.getElementById("erRetPlan3").innerHTML;
    robArray[111] = document.getElementById("erRetPlan4").innerHTML;
    robArray[112] = document.getElementById("subtot_erRetPlan").innerHTML;
    robArray[113] = document.getElementById("eeReserve1").innerHTML;
    robArray[114] = document.getElementById("subtot_eeReserve").innerHTML;
    robArray[115] = document.getElementById("erReserve1").innerHTML;
    robArray[116] = document.getElementById("subtot_erReserve").innerHTML;
    robArray[117] = document.getElementById("eeSavPlan1").innerHTML;
    robArray[118] = document.getElementById("eeSavPlan2").innerHTML;
    robArray[119] = document.getElementById("eeSavPlan3").innerHTML;
    robArray[120] = document.getElementById("eeSavPlan4").innerHTML;
    robArray[121] = document.getElementById("eeSavPlan5").innerHTML;
    robArray[122] = document.getElementById("eeSavPlan6").innerHTML;
    robArray[123] = document.getElementById("subtot_eeSavPlan").innerHTML;
    robArray[124] = document.getElementById("erSavPlan1").innerHTML;
    robArray[125] = document.getElementById("erSavPlan2").innerHTML;
    robArray[126] = document.getElementById("erSavPlan3").innerHTML;
    robArray[127] = document.getElementById("erSavPlan4").innerHTML;
    robArray[128] = document.getElementById("erSavPlan5").innerHTML;
    robArray[129] = document.getElementById("erSavPlan6").innerHTML;
    robArray[130] = document.getElementById("subtot_erSavPlan").innerHTML;
    robArray[131] = document.getElementById("eeCash1").innerHTML;
    robArray[132] = document.getElementById("subtot_eeCash").innerHTML;
    robArray[133] = document.getElementById("erCash1").innerHTML;
    robArray[134] = document.getElementById("subtot_erCash").innerHTML;
    robArray[135] = document.getElementById("eeGovBen1").innerHTML;
    robArray[136] = document.getElementById("subtot_eeGovBen").innerHTML;
    robArray[137] = document.getElementById("erGovBen1").innerHTML;
    robArray[138] = document.getElementById("subtot_erGovBen").innerHTML;
    robArray[139] = document.getElementById("tot_Rewards").innerHTML;
    robArray[140] = document.getElementById("tot_eeCost").innerHTML;
    robArray[141] = document.getElementById("tot_erCost").innerHTML;
    robArray[142] = document.getElementById("Glance1").innerHTML;
    robArray[143] = document.getElementById("Glance2").innerHTML;
    robArray[144] = document.getElementById("Glance3").innerHTML;
    robArray[145] = document.getElementById("Glance4").innerHTML;
    robArray[146] = document.getElementById("Glance5").innerHTML;
    robArray[147] = document.getElementById("Glance6").innerHTML;
    robArray[148] = document.getElementById("Glance7").innerHTML;
    robArray[149] = document.getElementById("Glance8").innerHTML;
    robArray[150] = document.getElementById("Glance9").innerHTML;
    robArray[151] = document.getElementById("Glance10").innerHTML;
    robArray[152] = document.getElementById("Glance11").innerHTML;
    robArray[153] = document.getElementById("Glance12").innerHTML;
    robArray[154] = document.getElementById("Glance13").innerHTML;
    robArray[155] = document.getElementById("Glance14").innerHTML;
    robArray[156] = document.getElementById("Glance15").innerHTML;
    robArray[157] = document.getElementById("Glance16").innerHTML;
    robArray[158] = document.getElementById("Glance17").innerHTML;
    robArray[159] = document.getElementById("Glance18").innerHTML;
    robArray[160] = document.getElementById("Glance19").innerHTML;
    robArray[161] = document.getElementById("Glance20").innerHTML;
    robArray[162] = document.getElementById("comGlance1").innerHTML;
    robArray[163] = document.getElementById("comGlance2").innerHTML;
    robArray[164] = document.getElementById("comGlance3").innerHTML;
    robArray[165] = document.getElementById("comGlance4").innerHTML;
    robArray[166] = document.getElementById("comGlance5").innerHTML;
    robArray[167] = document.getElementById("comGlance6").innerHTML;
    robArray[168] = document.getElementById("comGlance7").innerHTML;
    robArray[169] = document.getElementById("comGlance8").innerHTML;
    robArray[170] = document.getElementById("comGlance9").innerHTML;
    robArray[171] = document.getElementById("comGlance10").innerHTML;
    robArray[172] = document.getElementById("comGlance11").innerHTML;
    robArray[173] = document.getElementById("comGlance12").innerHTML;
    robArray[174] = document.getElementById("comGlance13").innerHTML;
    robArray[175] = document.getElementById("comGlance14").innerHTML;
    robArray[176] = document.getElementById("comGlance15").innerHTML;
    robArray[177] = document.getElementById("comGlance16").innerHTML;
    robArray[178] = document.getElementById("comGlance17").innerHTML;
    robArray[179] = document.getElementById("comGlance18").innerHTML;
    robArray[180] = document.getElementById("comGlance19").innerHTML;
    robArray[181] = document.getElementById("comGlance20").innerHTML;
    robArray[182] = document.getElementById("optGlance1").innerHTML;
    robArray[183] = document.getElementById("optGlance2").innerHTML;
    robArray[184] = document.getElementById("optGlance3").innerHTML;
    robArray[185] = document.getElementById("optGlance4").innerHTML;
    robArray[186] = document.getElementById("optGlance5").innerHTML;
    robArray[187] = document.getElementById("optGlance6").innerHTML;
    robArray[188] = document.getElementById("optGlance7").innerHTML;
    robArray[189] = document.getElementById("optGlance8").innerHTML;
    robArray[190] = document.getElementById("optGlance9").innerHTML;
    robArray[191] = document.getElementById("optGlance10").innerHTML;
    robArray[192] = document.getElementById("optGlance11").innerHTML;
    robArray[193] = document.getElementById("optGlance12").innerHTML;
    robArray[194] = document.getElementById("optGlance13").innerHTML;
    robArray[195] = document.getElementById("optGlance14").innerHTML;
    robArray[196] = document.getElementById("optGlance15").innerHTML;
    robArray[197] = document.getElementById("optGlance16").innerHTML;
    robArray[198] = document.getElementById("optGlance17").innerHTML;
    robArray[199] = document.getElementById("optGlance18").innerHTML;
    robArray[200] = document.getElementById("optGlance19").innerHTML;
    robArray[201] = document.getElementById("optGlance20").innerHTML;
    robSOF = robArray[201];

    robMedopt =
      modelflag == true
        ? document.getElementById("medopt").selectedIndex
        : robArray[143];
    robDentopt =
      modelflag == true
        ? document.getElementById("dentopt").selectedIndex
        : robArray[144];
    robMedcov =
      modelflag == true
        ? document.getElementById("medcov").selectedIndex
        : robArray[163];
    robDentcov =
      modelflag == true
        ? document.getElementById("dentcov").selectedIndex
        : robArray[164];
    /*
if(modelflag==true && document.getElementById("pageID").value=="2"){
    document.getElementById("link1").href="Welcome?opts="+document.getElementById("medopt").selectedIndex+";"+document.getElementById("medcov").selectedIndex+";"+document.getElementById("dentopt").selectedIndex+";"+document.getElementById("dentcov").selectedIndex;
    document.getElementById("link2").href="Rewards?opts="+document.getElementById("medopt").selectedIndex+";"+document.getElementById("medcov").selectedIndex+";"+document.getElementById("dentopt").selectedIndex+";"+document.getElementById("dentcov").selectedIndex;
    document.getElementById("link3").href="CostSharing?opts="+document.getElementById("medopt").selectedIndex+";"+document.getElementById("medcov").selectedIndex+";"+document.getElementById("dentopt").selectedIndex+";"+document.getElementById("dentcov").selectedIndex;
    document.getElementById("link4").href="Glance?opts="+document.getElementById("medopt").selectedIndex+";"+document.getElementById("medcov").selectedIndex+";"+document.getElementById("dentopt").selectedIndex+";"+document.getElementById("dentcov").selectedIndex;
    document.getElementById("link5").href="Personal?opts="+document.getElementById("medopt").selectedIndex+";"+document.getElementById("medcov").selectedIndex+";"+document.getElementById("dentopt").selectedIndex+";"+document.getElementById("dentcov").selectedIndex;
}  
*/
    robOnetime =
      parseInt(robArray[21]) +
      parseInt(robArray[22]) +
      parseInt(robArray[23]) +
      parseInt(robArray[24]) +
      parseInt(robArray[26]) +
      parseInt(robArray[28]);
    robOthercomp =
      parseInt(robArray[29]) +
      parseInt(robArray[30]) +
      parseInt(robArray[31]) +
      parseInt(robArray[32]) +
      parseInt(robArray[34]) +
      parseInt(robArray[36]);
    robOtherben =
      parseInt(robArray[37]) +
      parseInt(robArray[38]) +
      parseInt(robArray[39]) +
      parseInt(robArray[40]) +
      parseInt(robArray[42]) +
      parseInt(robArray[44]);
    console.log("robOnetime: " + robOnetime);
    console.log("robOthercomp: " + robOthercomp);
    console.log("robOtherben: " + robOtherben);
    //alert(parseInt(robArray[37]));alert(parseInt(robArray[38]));alert(parseInt(robArray[39]));alert(parseInt(robArray[40]));alert(parseInt(robArray[42]));alert(parseInt(robArray[44]));
    robSal = parseInt(robArray[47]);
    robBonus = parseInt(robArray[48]);
    robPay = robSal + robBonus + robOthercomp + robOnetime;
    // alert(robPay)
    robCountry = 1; //robArray[6];
    robProvince = getProvIndex(robArray[4]);
    console.log("Prov: " + robProvince);
    robEmpclass = robCountry == 1 ? robArray[7] : "X";
    robBusUnit = 0; //needed from scenario data
    robEmptype = robArray[5];
    /* baag1=1;baag2=1;baag3=1;baag4=1;rewards8b=0;robEmptype=robArray[5];*/
    //	}else if(weAreComingFromAddNewScreen== false){console.log("running rob");
  } else {
    console.log("running rob");

    loc = decodeURIComponent(location.search);
    //loc = location.href.substring(
    //  location.href.indexOf("?params="),
    //  location.href.length
    //);

    startpos = location.search.indexOf("params=") + 7;

    loc = loc.substring(startpos, loc.length);
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robArray = loc.split(";");
    for (var i = 0; i < robArray.length; i++) {
      robArray[i] = robArray[i].replace(/%20/g, " ");
      robArray[i] = decodeURIComponent(robArray[i]);
    }

    robArray[robArray.length - 1] = robArray[robArray.length - 1].substring(
      0,
      1,
    );
    //console.log(robArray);
    robFname = loc.substring(0, loc.indexOf(";")); //alert("robFname: " + robFname)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robLname = loc.substring(0, loc.indexOf(";")); //alert("robLname: " + robLname)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robProvince = parseFloat(loc.substring(0, loc.indexOf(";")));
    console.log("robProvince: " + robProvince);
    // robProvince=provLookup(loc.substring(0,loc.indexOf(";")));alert("robProvince: " + robProvince)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robBusUnit = parseFloat(loc.substring(0, loc.indexOf(";"))); //alert("robBusUnit: " + robBusUnit)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robEmpclass = parseFloat(loc.substring(0, loc.indexOf(";"))); //alert("robEmpclass: " + robEmpclass)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robSal = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robBonus = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robPaidvac = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther1 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther2 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther3 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther4 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther5 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther6 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOtcdesc1 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOtcdesc2 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther7 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther8 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther9 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther10 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther11 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther12 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOthdesc1 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOthdesc2 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther13 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther14 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther15 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther16 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther17 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOther18 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robObdesc1 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robObdesc2 = loc.substring(0, loc.indexOf(";")).replace(/%20/g, " ");
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOnetime = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOthercomp = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robLTI = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robOtherben = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robSOF = loc.substring(0, loc.indexOf(";")); //note no parseFloat...
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robMedopt = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robMedcov = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robDentopt = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robDentcov = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robCountry = 1; //parseFloat(loc.substring(0,loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robEmptype = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    tmpPassword = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robEmpid = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robGender = loc.substring(0, loc.indexOf(";"));
    console.log("robGender: " + robGender);
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robType = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    robEmail = loc.substring(0, loc.indexOf("?admin"));
    //startpos=loc.indexOf(";")+1;
    //loc=loc.substring(startpos,loc.length);
    //robDOB=loc.substring(0,loc.indexOf(";"));
    //startpos=loc.indexOf(";")+1;
    //loc=loc.substring(startpos,loc.length);
    //robDOH=loc.substring(0,loc.indexOf(";?"));
    robCountry = 1; //robArray[41];
    robPay = robSal + robBonus + robOthercomp + robOnetime;
    robSOF = location.href
      .substring(location.href.indexOf("?params="))
      .split(";")[37];
  }



    /* 2026 Start */

    countryvar = 1;

    if (robArray.length > 5) {
        medont = [3378.72, 8444.52, 8444.52];
        medque = [3378.72, 8444.52, 8444.52];
        medother = [3378.72, 8444.52, 8444.52];
        denont = [978.36, 2445.0, 2445.0];
        denque = [978.36, 2445.0, 2445.0];
        denother = [978.36, 2445.0, 2445.0];

        CS01COmed =
            robProvince < 4 || robProvince > 5
                ? medother[robSOF]
                : robProvince == 4
                    ? medont[robSOF]
                    : medque[robSOF];
        CS01COden =
            robProvince < 4 || robProvince > 5
                ? denother[robSOF]
                : robProvince == 4
                    ? denont[robSOF]
                    : denque[robSOF];
        CS01COltd = (Math.min((0.75 * robSal) / 12, 20000) * 12 * 2.012) / 100;
        CS01COlife = (12 * 0.247 * Math.min(5000000, 3 * robSal)) / 1000;
        CS01COadd = (12 * 0.01 * Math.min(2500000, 5 * robSal)) / 1000;

        CS01CO =
            robEmpclass == 3
                ? parseFloat(CS01COmed) +
                parseFloat(CS01COden) +
                parseFloat(CS01COltd) +
                parseFloat(CS01COlife) +
                parseFloat(CS01COadd)
                : 0;

        CS02OPT = robEmpclass == 0 ? 3 : 4;

        CS02COAdmin = [];
        CS02COProf = [];
        CS02COOff1 = [];
        CS02COOff2 = [];
        CS02COAdmin[0] = 1590.0;
        CS02COAdmin[1] = 3184.0;
        CS02COAdmin[2] = 4773.0;
        CS02COProf[0] = 1590.0;
        CS02COProf[1] = 3184.0;
        CS02COProf[2] = 4773.0;
        CS02COOff1[0] = 1938.0;
        CS02COOff1[1] = 3878.0;
        CS02COOff1[2] = 5815.0;
        CS02COOff2[0] = 1938.0;
        CS02COOff2[1] = 3878.0;
        CS02COOff2[2] = 5815.0;

        CS02CO = 0;
        if (robEmpclass == 0) {
            CS02CO = CS02COProf[robSOF];
        } else if (robEmpclass == 1) {
            CS02CO = CS02COOff1[robSOF];
        } else if (robEmpclass == 2) {
            CS02CO = CS02COOff2[robSOF];
        } else if (robEmpclass == 3) {
            CS02CO = 0;
        }


        CS03OPT = robEmpclass == 0 ? 3 : 4;

        CS03COAdmin = [];
        CS03COProf = [];
        CS03COOff1 = [];
        CS03COOff2 = [];
        CS03COAdmin[0] = 521.0;
        CS03COAdmin[1] = 1043.0;
        CS03COAdmin[2] = 1565.0;
        CS03COProf[0] = 521.0;
        CS03COProf[1] = 1043.0;
        CS03COProf[2] = 1565.0;
        CS03COOff1[0] = 690.0;
        CS03COOff1[1] = 1380.0;
        CS03COOff1[2] = 2071.0;
        CS03COOff2[0] = 690.0;
        CS03COOff2[1] = 1380.0;
        CS03COOff2[2] = 2071.0;

        CS03CO = 0;

        if (robEmpclass == 0) {
            CS03CO = CS03COProf[robSOF];
        } else if (robEmpclass == 1) {
            CS03CO = CS03COOff1[robSOF];
        } else if (robEmpclass == 2) {
            CS03CO = CS03COOff2[robSOF];
        } else if (robEmpclass == 3) {
            CS03CO = 0;
        }


        CS04CO =
            robEmpclass == 3
                ? 0
                : (Math.min((0.5 * robSal) / 12, 20000) * (12 * 1.08)) / 100;

        //Life Insurance Cost – EE paid – not Exec – Assumes Option 2

        CS05EE = robEmpclass == 3 ? 0 : (0.247 * 12 * robSal) / 1000;

        //Accidental Death & Dismemberment Cost – EE paid – not Exec – Assumes Option 2

        CS06EE = robEmpclass == 3 ? 0 : (0.01 * 12 * 1 * robSal) / 1000;

        //Defined Contribution Pension Plan
        //2026 Maximum DC = 35390
        ITAMax = 35390;

        CS07penearn = robEmpclass < 3 ? robSal : robSal + robBonus * 0.5;
        if (robEmpclass == 0) {
            CS07EE = 0.04 * CS07penearn;
            CS07CO = 0.0425 * CS07penearn;
        } else if (robEmpclass == 1) {
            CS07EE = Math.min(ITAMax - 0.01 * CS07penearn, 0.04 * CS07penearn);
            CS07CO = Math.min(ITAMax - CS07EE, 0.055 * CS07penearn);
        } else if (robEmpclass == 2) {
            CS07EE = Math.min(ITAMax - 0.01 * CS07penearn, 0.04 * CS07penearn);
            CS07CO = Math.min(ITAMax - CS07EE, 0.055 * CS07penearn);
        } else {
            CS07EE = Math.min(ITAMax - 0.01 * CS07penearn, 0.04 * CS07penearn);
            CS07CO = Math.min(ITAMax - CS07EE, 0.12 * CS07penearn);
        }
        CS08CO =
            robEmpclass == 0
                ? 0
                : robEmpclass == 1
                    ? Math.min(3 * ITAMax, 0.055 * CS07penearn) - CS07CO
                    : robEmpclass == 2
                        ? Math.min(3 * ITAMax, 0.055 * CS07penearn) - CS07CO
                        : Math.min(3 * ITAMax, 0.12 * CS07penearn) - CS07CO;

        //Voluntary Contributions

        CS09EE = 0.03 * robSal;

        if (robEmpclass == 0) {
            CS09CO = CS09EE;
        } else if (robEmpclass == 1) {
            CS09CO = 1.2 * CS09EE;
        } else if (robEmpclass == 2) {
            CS09CO = 1.5 * CS09EE;
        } else {
            CS09CO = 1.5 * CS09EE;
        }

        //CPP/QPP
        //YMPE for 2026 =74600 2nd Level= 85000
        YMPE = 74600;
        YMPE2 = 85000;

        totCashComp = robSal + robBonus + robOnetime + robOthercomp;

        CQPPEE =
            robProvince != 5
                ? 0.0595 * (Math.min(totCashComp, YMPE) - 3500) +
                0.04 * Math.max(0, Math.min(totCashComp, YMPE2) - YMPE)
                : 0.064 * (Math.min(totCashComp, YMPE) - 3500) +
                0.04 * Math.max(0, Math.min(totCashComp, YMPE2) - YMPE);
        CQPPCO = CQPPEE;

        if (robProvince == 0) {
            PROVCO = 0.0195 * totCashComp;
        } else if (robProvince == 1) {
            PROVCO = 0;
        } else if (robProvince == 2) {
            PROVCO = 0;
        } else if (robProvince == 3) {
            PROVCO = 0.0195 * totCashComp;
        } else if (robProvince == 4) {
            PROVCO = 0.0426 * totCashComp;
        } else if (robProvince == 5) {
            PROVCO = 0;
        } else if (robProvince == 6) {
            PROVCO = 0;
        } else if (robProvince == 7) {
            PROVCO = 0;
        } else if (robProvince == 9) {
            PROVCO = 0.02 * totCashComp;
        } else if (robProvince == 10) {
            PROVCO = 0;
        } else if (robProvince == 11) {
            PROVCO = 0;
        }

        //Employment Insurance (EI)
        //Max Earnings for EI in 2026 = $68,900

        eeei =
            (parseInt(robProvince) != 5 ? 0.0163 : 0.013) *
            Math.min(totCashComp, 68900);

        if (robBusUnit == 0) {
            eeco = eeei * 1.165;
        } else if (robBusUnit == 1) {
            eeco = eeei * 1.144;
        } else if (robBusUnit == 2) {
            eeco = eeei * 1.16;
        } else if (robBusUnit == 3) {
            eeco = eeei * 1.167;
        } else if (robBusUnit == 4) {
            eeco = eeei * 1.167;
        } else if (robBusUnit == 5) {
            eeco = eeei * 1.119;
        } else if (robBusUnit == 6) {
            eeco = eeei * 1.173;
        }
        qpipee = robProvince == 5 ? 0.0043 * Math.min(totCashComp, 103000) : 0;
        qpipco = robProvince == 5 ? 0.00602 * Math.min(totCashComp, 103000) : 0;

        eeei += qpipee;
        eeco += qpipco;

        CS10EE = parseFloat(eeei) + parseFloat(CQPPEE);

        CS10CO = parseFloat(eeco) + parseFloat(CQPPEE) + parseFloat(PROVCO);

        //Premier Credits allocated to you in 2026
        //Basic Credits

        AIY02CO = robEmpclass == 0 ? 0.0135 * robSal : 0.0235 * robSal;
        if (robEmpclass == 3) {
            AIY02CO = 0;
        }

        //Excess Benefit Credits

        CSEXCESSCO = parseFloat(AIY02CO) - parseFloat(CS04CO);

        //Totals for Cost of benefits

        TOTCSXXEE =
            parseFloat(CS05EE) +
            parseFloat(CS06EE) +
            parseFloat(CS07EE) +
            parseFloat(CS09EE) +
            parseFloat(CS10EE);
        TOTCSXXCO =
            parseFloat(CS01CO) +
            parseFloat(CS02CO) +
            parseFloat(CS03CO) +
            parseFloat(CS04CO) +
            parseFloat(CS07CO) +
            parseFloat(CS08CO) +
            parseFloat(CS09CO) +
            parseFloat(CS10CO) +
            parseFloat(CSEXCESSCO);

        //Matching Credits
        AIY03CO = CS09CO;
        if (robEmpclass == 3) {
            AIY03CO = 0;
        }

        //Benefit Plan and Excess Credits
        AIY04CO = parseFloat(CS02CO) + parseFloat(CS03CO);
        if (robEmpclass == 3) {
            AIY04CO = 0;
        }

        //Executive Group Insurance benefits
        AIY05CO = robEmpclass == 3 ? CS01CO : 0;

        //Executive Matching Contributions
        AIY06CO = robEmpclass == 3 ? CS09CO : 0;

        //Defined Contribution Pension Plan
        AIY07CO = CS07CO;

        //Defined Contribution Supplemental Employee Retirement Plan
        AIY08CO = CS08CO;

        //total
        AIY01CO = Math.round(
            parseFloat(AIY02CO) +
            parseFloat(AIY03CO) +
            parseFloat(AIY04CO) +
            parseFloat(AIY05CO) +
            parseFloat(AIY06CO) +
            parseFloat(AIY07CO) +
            parseFloat(AIY08CO),
        );

        //Government benefits
        AIY09CO = CS10CO;
    }

    // end new 2026




  // Glance vars
  baag1 = robArray[142]; //console.log("baag1: " + baag1 )
  //robArray[142]

  //}
}

function provLookup(prov) {
  switch (prov) {
    case "ALTA":
      return 0;
      break;
    case "BC":
      return 1;
      break;
    case "MAN":
      return 2;
      break;
    case "NFLD":
      return 3;
      break;
    case "NS":
      return 4;
      break;
    case "NWT":
      return 5;
      break;
    case "ONT":
      return 6;
      break;
    case "QUE":
      return 7;
      break;
    case "SASK":
      return 8;
      break;
    case "YUK":
      return 9;
      break;
    case "NB":
      return 10;
      break;
    case "PEI":
      return 11;
      break;
  }
}

function switchExecInputs(classID) {
  document.getElementById("lti").style.display = classID == 3 ? "" : "none";
  document.getElementById("execmed").style.display = classID == 3 ? "" : "none";
  if (classID != 3) {
    document.getElementById("specialstock").checked = false;
    document.getElementById("leadership").checked = false;
    document.getElementById("ltiText").innerHTML =
      selectedUICulture == "en-US" ? "(none selected)" : "(aucune selection)";
    document.getElementById("o13").value = "$0";
    document.getElementById("hdnO13").value = 0;
  }
  windup();
}
