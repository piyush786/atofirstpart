var RSData;
var excelData;

async function loadFile(){
    if(excelData == null){
        await fetch('./media/resourceStringFile/localisation.xlsx')
        .then(response=>response.arrayBuffer())
        .then(data => {
            var workbook = XLSX.read(new Uint8Array(data), {type:'array'});
            var workSheet = workbook.Sheets["ResourceString"];
            excelData = XLSX.utils.sheet_to_json(workSheet,{headers:true});
            console.log(excelData);       
        })
        .catch(error =>{
            console.error('Error loding the file:',error);
        })
    } 
    return excelData;  
}

function loadContent(selector, url){
    return new Promise((resolve,reject) => {
        try{
            $(selector).load(url, function(response,status,xhr){
                if(status=="success"){
                    resolve(`content loaded into ${selector}`);
                }else{
                    reject(`failed to load content for ${selector}: ${xhr.status}`);
                }
            })
        }catch{
            error=>{
                reject(`failed to load content for ${selector}: ${error}`);
            }
        }
    })
}

function loadScript(src){
     
    return new Promise((resolve, reject) => {
        try {
            const scriptEle = document.createElement("script");
            scriptEle.type = "text/javascript";
            scriptEle.async = false;
            scriptEle.src ="js/"+src;//GetResourceStringVal("CED.BAYER.FormatJS");

            scriptEle.addEventListener("load", (ev) => {
                resolve({ status: true });
            });

            scriptEle.addEventListener("error", (ev) => {
                reject({
                    status: false,
                    message: `Failed to load the script ${src}`
                });
            });

            document.body.appendChild(scriptEle);
        } catch (error) {
            reject(error);
        }
    }); 

}

function loadResourceString(){
    var langCode  = sessionStorage.getItem(sessionKey.LangCode);
    langCode = langCode == null || langCode=='undefined'? "en":langCode;
    console.log("langcode inside loadResourceString:",langCode);
    $("[RSKey]").each(function(){
        keyName = $(this).attr("RSKey");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log("type",typeof(result[0][langCode]),result[0][langCode]);
            $(this).replaceWith(result[0][langCode]);
        }
    })
    $("[styleRS]").each(function(){
        keyName = $(this).attr("styleRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("style",function(i,s){return (s||"")+result[0][langCode]});
            $(this).removeAttr("styleRS");
        }
    })
    $("[classRS]").each(function(){
        keyName = $(this).attr("classRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).addClass(result[0][langCode]);
            $(this).removeAttr("classRS");
        }
    })
    $("[placeholderRS]").each(function(){
        keyName = $(this).attr("placeholderRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("placeholder",result[0][langCode]);
            $(this).removeAttr("placeholderRS");
        }
    })
    $("[valueRS]").each(function(){
        keyName = $(this).attr("valueRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("value",result[0][langCode]);
            $(this).removeAttr("valueRS");
        }
    })
    $("[idRS]").each(function(){
        keyName = $(this).attr("idRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("id",result[0][langCode]);
            $(this).removeAttr("idRS");
        }
    })
    $("[qtip-titleRS]").each(function(){
        keyName = $(this).attr("qtip-titleRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("qtip-title",result[0][langCode]);
            $(this).removeAttr("qtip-titleRS");
        }
    })
    $("[hrefRS]").each(function(){
        keyName = $(this).attr("hrefRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("href",result[0][langCode]);
            $(this).removeAttr("hrefRS");
        }
    })
    $("[qtipcontentRS]").each(function(){
        keyName = $(this).attr("qtipcontentRS");
        var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
        console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result[0][langCode]);
            $(this).attr("qtipcontent",result[0][langCode]);
            $(this).removeAttr("qtipcontentRS");
        }
    })
}
  
function GetResourceStringVal(keyName){
    var langCode  = sessionStorage.getItem(sessionKey.LangCode);
    langCode = langCode == null? "en":langCode;
    var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
    console.log("Key:"+keyName+" result:", result);
        console.log("Length",result.length);
        if(result.length> 0){
            console.log(result);
            return result[0][langCode];
        }
}


// function loadRSWithEvalutedScript(){
//     debugger;
//     var langCode  = sessionStorage.getItem(sessionKey.LangCode);

//     // CED.Bayer.TakeAction.reviewSavings
//     $("[RSKey='CED.Bayer.ProjectedRetirementIncome.NotesAndAssumptionsText']").each(function(){
//         keyName = $(this).attr("RSKey");
//         var result= alasql("SELECT * FROM ? WHERE LOWER(ResourceStringKey) =LOWER('"+keyName+"')",[excelData]);
//         console.log("Key:"+keyName+" result:", result);
//         console.log("Length",result.length);
//         if(result.length> 0){
//             console.log(result[0][langCode]);
//             //$(this).replaceWith(result[0][langCode]);
//             var htmlString = result[0][langCode];

//             const scriptRegrex = /<script\b[^>]*>([\s\S]*?)<\/script>/gi;
//             let processHtml = htmlString.replace(scriptRegrex,(match,scriptContent)=>{
//                 try{
//                     console.log("script",scriptContent);
//                     const result = new Function(scriptContent)();
//                     console.log("result",result);
//                     return result != undefined ? result:'';

//                 }catch(error){
//                     console.log("error:",error);
//                 }
//             })
//             console.log("processhtml",processHtml);
//             $(this).innerHtml = processHtml;
//         }
//     })
// }