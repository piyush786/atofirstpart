//Current

//const { exec } = require("node:child_process");

//var hdnRef=document.Informa_Content
var lang = "";
var monthArrFR = new Array(12);
var monthArr = new Array(12);
monthArrFR[0] = "janvier";
monthArr[0] = "January";
monthArrFR[1] = "f&eacute;vrier";
monthArr[1] = "February";
monthArrFR[2] = "mars";
monthArr[2] = "March";
monthArrFR[3] = "avril";
monthArr[3] = "April";
monthArrFR[4] = "mai";
monthArr[4] = "May";
monthArrFR[5] = "juin";
monthArr[5] = "June";
monthArrFR[6] = "juillet";
monthArr[6] = "July";
monthArrFR[7] = "a&ocirc;ut";
monthArr[7] = "August";
monthArrFR[8] = "septembre";
monthArr[8] = "September";
monthArrFR[9] = "octobre";
monthArr[9] = "October";
monthArrFR[10] = "novembre";
monthArr[10] = "November";
monthArrFR[11] = "d&eacute;cembre";
monthArr[11] = "December";

function loadPageRecruiting() {
  console.log("recruiting");
  lang = document.getElementById("userlang").value;

  if (document.getElementById("pageID")) {
    var thePage = document.getElementById("pageID").value;

    //if(newSS==false){
    //if(thePage==99||thePage=="0"||thePage=="1"||thePage=="2"){eval("setFields"+thePage)()}
    if (thePage == "2" || thePage == "P") {
        setFields2();
        $("#paidvacation").hide();
        $("#paidvacationForRecruits").show();

    }
    if (thePage == "1" || thePage == "P") {
      setFields1();
      $(".recruiterText").show();
      $("#volNote").hide();
      $(".recruiterText").show();
    }
    //if(thePage=="3" |l| thePage=="P")(updateChart(3))
    //}else{

    //individual items

    if (thePage == "2" || thePage == "P") {
      document.getElementById("row2").style.display = "none";
      document.getElementById("row21").style.display =
        AIY08CO > 0 ? "" : "none";
      document.getElementById("row22").style.display = "none";
      document.getElementById("subtotal_Flex_1").style.visibility = "hidden";
      document.getElementById("row10").style.display = "none";
      //document.getElementById("spanFlex2").style.visibility="hidden";
      //document.getElementById("spanFlex3").style.visibility="hidden";
      document.getElementById("row28").style.display = "none";
      document.getElementById("row29").style.display = "none";

      if (robLTI == "") {
        document.getElementById("tbl_Flexhead").style.display = "none";
        document.getElementById("row11").style.display = "none";
        document.getElementById("row12").style.display = "none";
      } else if (robLTI == "SSP") {
        document.getElementById("tbl_Flexhead").style.display = "";
        document.getElementById("row11").style.display = "";
      } else if (robLTI == "LPP") {
        document.getElementById("tbl_Flexhead").style.display = "";
        document.getElementById("row12").style.display = "";
      } else if (robLTI == "SSPLPP") {
        document.getElementById("tbl_Flexhead").style.display = "";
        document.getElementById("row11").style.display = "";
        document.getElementById("row12").style.display = "";
      }

      document.getElementById("subtotal_Pay_1").innerHTML = fmtCurrency(
        robSal + robBonus + robOnetime + robOthercomp,
        0,
      );
      document.getElementById("spanPay1").innerHTML = fmtCurrency(robSal, 0);
      document.getElementById("spanPay3").innerHTML = fmtCurrency(robBonus, 0);

      // document.getElementById("spanSav1").style.visibility="hidden";
      document.getElementById("spanSav2_2").innerHTML = fmtCurrency(AIY02CO, 0);
      document.getElementById("spanSav3_2").innerHTML = fmtCurrency(AIY03CO, 0);
      document.getElementById("spanSav4_2").innerHTML = fmtCurrency(AIY04CO, 0);
      document.getElementById("spanSav5").innerHTML = fmtCurrency(AIY05CO, 0);
      document.getElementById("spanSav6").innerHTML = fmtCurrency(AIY06CO, 0);
      document.getElementById("spanSav7").innerHTML = fmtCurrency(AIY07CO, 0);
      document.getElementById("spanSav8").innerHTML = fmtCurrency(AIY08CO, 0);
      document.getElementById("subtotal_Sav_1").innerHTML = fmtCurrency(
        AIY01CO,
        0,
      );

      document.getElementById("subtotal_Gov_1").innerHTML = fmtCurrency(
        AIY09CO,
        0,
      ); //+Math.round(formHRef.hdnNwtpayroll.value)

      document.getElementById("subtotal_Othben_1").innerHTML = fmtCurrency(
        robOtherben,
        0,
      );

      //  document.getElementById('spantot_Rewards_2').innerHTML=fmtCurrency(AIY09CO+AIY01CO+robSal+robBonus+robOnetime+robOthercomp+robOtherben,0);

      //exec switching

      execSS = robEmpclass == 3 ? true : false;

      document.getElementById("tbl_Flexhead").style.display =
        execSS == false || robLTI == "" ? "none" : "";

      document.getElementById("row14").style.display =
        execSS == false ? "" : "none";
      document.getElementById("row15").style.display =
        execSS == false ? "" : "none";
      document.getElementById("row16").style.display =
        execSS == false ? "" : "none";
      document.getElementById("row17").style.display =
        execSS == false ? "" : "none";

      console.log("utils");
      document.getElementById("row18").style.display =
        execSS == false ? "none" : "";
      document.getElementById("row19").style.display =
        execSS == false ? "none" : "";
      document.getElementById("row27").style.display =
        execSS == false ? "none" : robOther13 > 0 ? "" : "none";

      showOtc =
        robOther1 + robOther2 + robOther3 + robOther4 + robOther5 + robOther6 >
        0
          ? true
          : false;
      labelwidth = thePage != "P" ? "452px" : "260px";

      if (showOtc == true) {
        if (lang == "E") {
          document.getElementById("spanlabel4").innerHTML +=
            robOther1 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Signing bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther1, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther2 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Guaranteed bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther2, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther3 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Retention bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther3, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther4 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Relocation support</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther4, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther5 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOtcdesc1 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther5, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther6 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOtcdesc2 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther6, 0) +
                "</div>"
              : "";
        } else {
          document.getElementById("spanlabel4").innerHTML +=
            robOther1 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime d'embauche</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther1, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther2 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime garantie</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther2, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther3 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime de fidélisation</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther3, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther4 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Aide au transfert</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther4, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther5 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOtcdesc1 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther5, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            robOther6 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOtcdesc2 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther6, 0) +
                "</div>"
              : "";
        }
        document.getElementById("spanPay4").style.width = "15%";
        document.getElementById("spanPay4").style.display = "";
        document.getElementById("spanPay4_2").style.display = "none";
        document.getElementById("spanPay4").style.verticalAlign = "top";
        document.getElementById("spanPay4").innerHTML = fmtCurrency(
          robOnetime,
          0,
        );

        document.getElementById("row4").style.display = "";
      } else {
        document.getElementById("row4").style.display = "none";
      }

      showOther =
        robOther7 +
          robOther8 +
          robOther9 +
          robOther10 +
          robOther11 +
          robOther12 >
        0
          ? true
          : false;
      if (showOther == true) {
        if (lang == "E") {
          document.getElementById("spanlabel5").innerHTML +=
            robOther7 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Automobile allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther7, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther8 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Transit allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther8, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther9 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Living allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther9, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther10 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Parking</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther10, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther11 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOthdesc1 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther11, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther12 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOthdesc2 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther12, 0) +
                "</div>"
              : "";
        } else {
          document.getElementById("spanlabel5").innerHTML +=
            robOther7 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité pour usage de véhicule personnel</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther7, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther8 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité de transport</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther8, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther9 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité de séjour</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther9, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther10 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Stationnement</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther10, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther11 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOthdesc1 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther11, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            robOther12 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                robOthdesc2 +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(robOther12, 0) +
                "</div>"
              : "";
        }
        document.getElementById("spanPay5").style.width = "15%";
        document.getElementById("spanPay5").style.display = "";
        document.getElementById("spanPay5").style.visibility = "visible";
        document.getElementById("spanPay5_2").style.display = "none";
        document.getElementById("spanPay5").style.verticalAlign = "top";
        document.getElementById("spanPay5").innerHTML = fmtCurrency(
          robOthercomp,
          0,
        );
        document.getElementById("row5").style.display = "";
      } else {
        document.getElementById("row5").style.display = "none";
      }

      showOb =
        robOther13 +
          robOther14 +
          robOther15 +
          robOther16 +
          robOther17 +
          robOther18 >
        0
          ? true
          : false;
      if (showOb == true) {
        if (lang == "E") {
          if (robOther13 > 0) {
            document.getElementById("spanlabel27").innerHTML =
              "Executive Medical";
            document.getElementById("spanOthben1").innerHTML = fmtCurrency(
              robOther13,
              0,
            );
            document.getElementById("row27").style.display = "";
          } else {
            document.getElementById("row27").style.display = "none";
          }
          if (robOther14 > 0) {
            document.getElementById("spanlabel28").innerHTML = "Club Dues";
            document.getElementById("spanOthben2").innerHTML = fmtCurrency(
              robOther14,
              0,
            );
            document.getElementById("row28").style.display = "";
          } else {
            document.getElementById("row28").style.display = "none";
          }
          if (robOther15 > 0) {
            document.getElementById("spanlabel29").innerHTML = "House Loans";
            document.getElementById("spanOthben3").innerHTML = fmtCurrency(
              robOther15,
              0,
            );
            document.getElementById("row29").style.display = "";
          } else {
            document.getElementById("row29").style.display = "none";
          }
          if (robOther16 > 0) {
            document.getElementById("spanlabel30").innerHTML =
              "Training & Development";
            document.getElementById("spanOthben4").innerHTML = fmtCurrency(
              robOther16,
              0,
            );
            document.getElementById("row30").style.display = "";
          } else {
            document.getElementById("row30").style.display = "none";
          }
        } else {
          if (robOther13 > 0) {
            document.getElementById("spanlabel27").innerHTML =
              "Protection médicale des dirigeants";
            document.getElementById("spanOthben1").innerHTML = fmtCurrency(
              robOther13,
              0,
            );
            document.getElementById("row27").style.display = "";
          } else {
            document.getElementById("row27").style.display = "none";
          }
          if (robOther14 > 0) {
            document.getElementById("spanlabel28").innerHTML =
              "Frais d'adhésion à des clubs";
            document.getElementById("spanOthben2").innerHTML = fmtCurrency(
              robOther14,
              0,
            );
            document.getElementById("row28").style.display = "";
          } else {
            document.getElementById("row28").style.display = "none";
          }
          if (robOther15 > 0) {
            document.getElementById("spanlabel29").innerHTML =
              "Prêts hypothécaires";
            document.getElementById("spanOthben3").innerHTML = fmtCurrency(
              robOther15,
              0,
            );
            document.getElementById("row29").style.display = "";
          } else {
            document.getElementById("row29").style.display = "none";
          }
          if (robOther16 > 0) {
            document.getElementById("spanlabel30").innerHTML =
              "Formation et perfectionnement";
            document.getElementById("spanOthben4").innerHTML = fmtCurrency(
              robOther16,
              0,
            );
            document.getElementById("row30").style.display = "";
          } else {
            document.getElementById("row30").style.display = "none";
          }
        }
        if (robOther17 > 0) {
          document.getElementById("spanlabel31").innerHTML = robObdesc1;
          document.getElementById("spanReserve1").innerHTML = fmtCurrency(
            robOther17,
            0,
          );
          document.getElementById("row31").style.display = "";
        } else {
          document.getElementById("row31").style.display = "none";
        }
        if (robOther18 > 0) {
          document.getElementById("spanlabel32").innerHTML = robObdesc2;
          document.getElementById("spanReserve2").innerHTML = fmtCurrency(
            robOther18,
            0,
          );
          document.getElementById("row32").style.display = "";
        } else {
          document.getElementById("row32").style.display = "none";
        }
        document.getElementById("row31").style.display = "none";
        document.getElementById("row32").style.display = "none";
        document.getElementById("tbl_Othbenhead").style.display = "";
      } else {
        document.getElementById("tbl_Othbenhead").style.display = "none";
      }

      updateChart(2);
    }
    if (thePage == "3" || thePage == "P") {
      document.getElementById("tbl_TFSAhead").style.display = "none";
      document.getElementById("tagLine2").style.display = "none";
      document.getElementById("spanlabel45").innerHTML =
        lang == "E" ? "Group insurance benefits" : "Assurances collectives";
      console.log("utils");
      document.getElementById("row45").style.display =
        robEmpclass == 3 && CS01CO > 0 ? "" : "none";

      document.getElementById("row46").style.display =
        robEmpclass == 3 ? "none" : CS02CO > 0 ? "" : "none";
      document.getElementById("row47").style.display =
        robEmpclass == 3 ? "none" : CS03CO > 0 ? "" : "none";

      document.getElementById("row48").style.display = "none";
      document.getElementById("row48a").style.display = "none";
      document.getElementById("row49").style.display =
        robEmpclass == 3 ? "none" : CS04CO > 0 ? "" : "none";
      document.getElementById("row50").style.display = "none";
      document.getElementById("row51").style.display =
        robEmpclass == 3 ? "none" : CS05EE > 0 ? "" : "none";
      document.getElementById("row52").style.display =
        robEmpclass == 3 ? "none" : CS06EE > 0 ? "" : "none";

      document.getElementById("fullCovMedNote").style.display =
        robEmpclass == 3 ? "" : "none";

      document.getElementById("row52").outerHTML +=
        lang == "E"
          ? "<table style='border-bottom: 1px solid #666;DISPLAY: ' id='row52a' border='0' cellpadding='4' cellspacing='0' width='100%'><tbody><tr><td class='tableText2a firstChild' style='min-width: 140px;padding-left: 23px' width='62%'><span id='spanlabel52a'>Benefit Plan and Excess Credits</span></td><td class='tableText2a' id='spaneeRetPlan4a' align='right' width='15%'></td><td style='padding-right: 8px' class='tableText2a lastChild' id='spanerRetPlan4a' align='right' width='23%'></td></tr></tbody></table>"
          : "<table style='border-bottom: 1px solid #666;DISPLAY: ' id='row52a' border='0' cellpadding='4' cellspacing='0' width='100%'><tbody><tr><td class='tableText2a firstChild' style='min-width: 140px;padding-left: 23px' width='62%'><span id='spanlabel52a'>Cr" +
            String.fromCharCode(233) +
            "dits du programme et cr" +
            String.fromCharCode(233) +
            "dits suppl" +
            String.fromCharCode(233) +
            "mentaires</span></td><td class='tableText2a' id='spaneeRetPlan4a' align='right' width='15%'></td><td style='padding-right: 8px' class='tableText2a lastChild' id='spanerRetPlan4a' align='right' width='23%'></td></tr></tbody></table>";
      document.getElementById("row52a").style.display =
        robEmpclass == 3 ? "none" : CSEXCESSCO > 0 ? "" : "none";

      var spns = document.getElementsByTagName("span");
      for (var i = 0; i < spns.length; i++) {
        if (
          spns[i].id ||
          spns[i].innerHTML.indexOf("Retirement and Savings Programs") >= 0 ||
          spns[i].innerHTML.indexOf("Government Benefits") >= 0
        ) {
          spns[i].style.textDecoration = "none";
        }
      }

      document.getElementById("spanlabel52a").innerHTML =
        lang == "E"
          ? "Excess Benefit Credits"
          : "Cr" +
            String.fromCharCode(233) +
            "dits exc" +
            String.fromCharCode(233) +
            "dentaires li" +
            String.fromCharCode(233) +
            "s aux avantages sociaux";
      document.getElementById("row55").style.display =
        AIY08CO > 0 ? "" : "none";
      // if(document.getElementById("tbl_Reservehead")){document.getElementById("tbl_Reservehead").style.display = "none";}
      document.getElementById("tbl_Cashhead").style.display = "none";
      document.getElementById("tbl_GovBen").style.display = "none";
      document.getElementById("row56").style.display = "none";
      document.getElementById("spanlabel57").innerHTML =
        lang == "E" ? "Voluntary Contributions" : "Cotisations volontaires";
      document.getElementById("spanlabel58").innerHTML =
        lang == "E"
          ? robEmpclass == 3 //level 60-85 exec
            ? "Matching Premier Contributions"
            : "Matching Premier Credits"
          : "Cr" + String.fromCharCode(233) + "dits correspondants d'Aon";
      document.getElementById("row59").style.display = "none";
      document.getElementById("row60").style.display = "none";
      document.getElementById("row62").style.display = "none";
      document.getElementById("row63").style.display = "none";
      document.getElementById("row64").style.display = "none";
      document.getElementById("row65").style.display = "none";
      document.getElementById("row66").style.display = "none";

      document.getElementById("spanerCore1").innerHTML =
        robEmpclass == 3 && CS01CO > 0 ? fmtCurrency(CS01CO, 0) : "";
      document.getElementById("spanerCore2").innerHTML = fmtCurrency(CS02CO, 0);
      document.getElementById("spanerCore3").innerHTML = fmtCurrency(CS03CO, 0);
      document.getElementById("subtotal_Core_2").innerHTML = fmtCurrency(
        parseFloat(CS01CO) + parseFloat(CS02CO) + parseFloat(CS03CO),
        0,
      );

      document.getElementById("spanerRetPlan1").innerHTML = fmtCurrency(
        CS04CO,
        0,
      );
      document.getElementById("spaneeRetPlan3").innerHTML = fmtCurrency(
        CS05EE,
        0,
      );
      document.getElementById("spaneeRetPlan4").innerHTML = fmtCurrency(
        CS06EE,
        0,
      );
      document.getElementById("spanerRetPlan4a").innerHTML = fmtCurrency(
        CSEXCESSCO,
        0,
      );
      document.getElementById("subtotal_RetPlan_1").innerHTML = fmtCurrency(
        parseFloat(CS05EE) + parseFloat(CS06EE),
        0,
      );
      document.getElementById("subtotal_RetPlan_2").innerHTML = fmtCurrency(
        parseFloat(CS04CO) + parseFloat(CSEXCESSCO),
        0,
      );
      document.getElementById("tbl_RetPlanhead").style.display =
        robEmpclass == 3
          ? "none"
          : parseFloat(CS05EE) + parseFloat(CS06EE) > 0 ||
              parseFloat(CS04CO) + parseFloat(CSEXCESSCO) > 0
            ? ""
            : "none";

      document.getElementById("spaneeSavPlan1").innerHTML = fmtCurrency(
        CS07EE,
        0,
      );
      document.getElementById("spanerSavPlan1").innerHTML = fmtCurrency(
        CS07CO,
        0,
      );
      document.getElementById("spanerSavPlan2").innerHTML = fmtCurrency(
        CS08CO,
        0,
      );
      document.getElementById("spaneeSavPlan3").innerHTML = fmtCurrency(
        CS09EE,
        0,
      );
      document.getElementById("spanerSavPlan4").innerHTML = fmtCurrency(
        CS09CO,
        0,
      );
      document.getElementById("subtotal_SavPlan_1").innerHTML = fmtCurrency(
        parseFloat(CS07EE) + parseFloat(CS09EE),
        0,
      );
      document.getElementById("subtotal_SavPlan_2").innerHTML = fmtCurrency(
        parseFloat(CS07CO) + parseFloat(CS08CO) + parseFloat(CS09CO),
        0,
      );
      document.getElementById("subtotal_GovBen_1").innerHTML = fmtCurrency(
        CS10EE,
        0,
      );
      document.getElementById("subtotal_GovBen_2").innerHTML = fmtCurrency(
        CS10CO,
        0,
      );

      document.getElementById("spantot_eeCost").innerHTML = fmtCurrency(
        TOTCSXXEE,
        0,
      );
      document.getElementById("spantot_erCost").innerHTML = fmtCurrency(
        TOTCSXXCO,
        0,
      );

      document.getElementById("subtotal_Core").style.marginBottom = "0px";
      document.getElementById("subtotal_RetPlan").style.marginBottom = "0px";
      document.getElementById("subtotal_SavPlan").style.marginBottom = "0px";
      updateChart(3);
    }
  }
  // if(thePage=="P"){
  toggleBlock("tbl_Pay", "block");
  // toggleBlock('tbl_Variablepay','block');
  //toggleBlock('tbl_Otherallow','block');
  toggleBlock("tbl_Othben", "block");
  toggleBlock("tbl_Sav", "block");
  toggleBlock("tbl_Flex", "block");
  toggleBlock("tbl_Gov", "block");
  //}

  //if(thePage=="P"){
  toggleBlock("tbl_Core", "block");
  toggleBlock("tbl_RetPlan", "block");
  toggleBlock("tbl_SavPlan", "block");
  toggleBlock("tbl_GovBen", "block");

  //}
  //console.log("open")

  $("#footer nav ul li:nth-child(3)").hide();
  $("#footer nav ul li:nth-child(5)").hide();
  $("#footer nav ul li:nth-child(6)").hide();
  $("#footer nav ul li:nth-child(7)").hide();
  $("#surveycallout").hide();
  $("#nav5,#nav6").hide();
  $("#refferalProgram").hide();
  $("#logoff").attr("href", "logout.html?isRecruiter=1");

  if (thePage == "P") {
    var lnks = document.getElementsByTagName("a");
    var n = lnks.length;
    for (var i = 0; i < n; i++) {
      if (lnks[i].className == "blueLink") {
        lnks[i].className = "blueLink2";
        lnks[i].onclick = "return false";
      }
    }
  }

  top.document.title =
    lang == "E"
      ? "Premier Canada - Your Total Rewards Statement"
      : "Premier Canada - Votre relev" +
        String.fromCharCode(233) +
        " de r" +
        String.fromCharCode(233) +
        "mun" +
        String.fromCharCode(233) +
        "ration globale";

  //var empname=(thePage=="P")?(location.href.indexOf("params=") >= 0)?robFname + " " + robLname:document.getElementById("FirstName").innerHTML +" "+document.getElementById("LastName").innerHTML:document.getElementById("FirstName").innerHTML;// +" "+document.getElementById("LastName").innerHTML;

  if (thePage != "P") {
    if (location.href.indexOf("params=") >= 0) {
      var empname = robFname.replace("%20", " ");
    } else {
      var empname = document
        .getElementById("FirstName")
        .innerHTML.replace("%20", " ");
    }
    document.getElementById("greeting").innerHTML =
      lang == "E"
        ? "<strong>Welcome </strong> " + empname
        : "<strong>Bienvenue </strong>" + empname;
  } else {
    if (location.href.indexOf("params=") >= 0) {
      var empname =
        robFname.replace("%20", " ") + " " + robLname.replace("%20", " ");
    } else {
      var empname =
        document.getElementById("FirstName").innerHTML.replace("%20", " ") +
        " " +
        document.getElementById("LastName").innerHTML.replace("%20", " ");
    }
    //document.getElementById("greeting2").innerHTML=empname;
    $("p.addressline1").text(empname);
  }

  // if(document.getElementById("tbl_Reservehead")){document.getElementById("tbl_Reservehead").style.display = "none";}
  $("#tbl_Reserve").hide();
  $("#tbl_Reservehead").hide();

  window.status = "";
  document.getElementById("sitecover").style.visibility = "visible";
}
function loadPage() {
  console.log("active");
  //employeeType=document.getElementById("EmpType").innerHTML;
  lang = document.getElementById("userlang").value;

  if (isRecruit == 1) {
    $("#referralProgramm").hide();
    $("#footer nav ul li:nth-child(3)").hide();
    $("#footer nav ul li:nth-child(5)").hide();
    $("#footer nav ul li:nth-child(6)").hide();
    $("#footer nav ul li:nth-child(7)").hide();
    $("#surveycallout").hide();
    $("#nav5").hide();
    $("#logoff").attr("href", "logout.html?isRecruiter=1");
  }

  // =====================Extra Code for HRP Conversion =============================================//
  // if (selectedUICulture == "en-US")
  //   lang = "E";
  // else
  //   lang = "F";
  // commented By Pooja
  // =====================Ends here New HRP Conversion =============================================//

  if (document.getElementById("pageID")) {
    var thePage = document.getElementById("pageID").value;
    document.getElementById("userlang").value = lang;
    var lStr = "nav" + thePage;
    if (document.getElementById(lStr)) {
      document.getElementById(lStr).className = "selected";
    } else {
      lStr = "nav1";
      if (document.getElementById(lStr)) {
        document.getElementById(lStr).className = "selected";
      }
    }

    resizePage();
    if (thePage != "P") {
      if (thePage == 1 || thePage == 2 || thePage == 3) {
        eval("setFields" + thePage)();
      }
    } else {
      setFields1();
      setFields2();
      setFields3();
      //setFields4();
      $("p.addressline1").text(
        $("#FirstName").text() + " " + $("#LastName").text(),
      );
      $("p.addressline2").text($("#address1").text());
      $("p.addressline3").text($("#address2").text());
      $("p.addressline4").text(
        $("#city").text() +
          " " +
          $("#province1").text() +
          "  " +
          $("#postalCode").text(),
      );
      $("p.addressline5").text($("#country").text());
      $(".seqno, .sequencenum").text($("#seqno").text());
      }

    if (thePage == 3 || thePage == "P") {
      document.getElementById("medNote").style.display = "none";
      $(".recruit").hide();
      //document.getElementById("spanlabel51").innerHTML = (robEmpclass == 4) ? "Optional Life Insurance" : "Life Insurance"
        //new 2021

        if ($("#Sav6").text() == "0") {
            let nonExecADDText = lang == "E" ? "Accidental Death and Dismemberment" : "Assurance en cas de décès et mutilation accidentels";
            $("#spanlabel52").html(nonExecADDText);
            $("#spanlabel52").attr("qtip-title", nonExecADDText);

        } else {
            let execADDText = lang == "E" ? "Optional Accidental Death and Dismemberment" : "Assurance en cas de décès et mutilation accidentels facultative";
            $("#spanlabel52").html(execADDText);
            $("#spanlabel52").attr("qtip-title", execADDText);
        }


      if ($("#comGlance4").text() != "") {
        document.getElementById("ParaForNonComGlance4").style.display = "none";
      }
      if (
        document.getElementById("tbl_RetPlanhead").style.display != "none" &&
        document.getElementById("row45").style.display != "none"
      ) {
        document.getElementById("tbl_RetPlanheadlabel").innerHTML =
          lang == "E"
            ? "Executive Group Insurance Benefits"
            : "Assurances collectives des dirigeants";
        document.getElementById("subtotal_RetPlan_1").style.width =
          thePage == "P" ? "15.5%" : "23%";
        }

        
      //end new
    }
    if (thePage == 2 || thePage == 3) {
      updateChart(thePage);
    } else if (thePage == "P") {
      updateChart(2);
      updateChart(3);
    }
  }

  if (thePage == 4 || thePage == "P") {
    $(".bp1").css("visibility", "hidden");
      $(".bp2").css("visibility", "hidden");
      $(".recruiterText").hide();
  }

    if (thePage == 6 || thePage == "P") {

        var coveragetext1 = "";
        if ($("#comGlance4").html() == "") {

            let enText = "Your group benefits, retirement and savings elections are not displayed here as enrolment was not complete as of May 31, 2026. Visit <a href = 'http://manulife.ca/signin' target = '_blank'>manulife.ca/signin</a> and login or access the Plan Member site from <a href='https://upoint.aon.com/' target = '_blank'>UPoint</a> to review your up-to-date coverage elections.";
            let frText = "Vos choix au titre des régimes d’avantages sociaux, de retraite et d’épargne n’apparaissent pas ici, car l’adhésion n’était pas terminée au 31 mai 2026. Allez à <a href='https://wwwec7.manulife.com/signin/fr' target='_blank'>manulife.ca/signin</a> et ouvrez une session, ou accédez au site des participants à partir de <a href='https://upoint.aon.com/' target='_blank'>UPoint</a>, pour passer en revue vos choix les plus récents."

            coveragetext1 = lang == 'E' ? enText : frText;
        } else {
            let enText = "The group benefits coverage statement below is based on your elections, and employment information as of May 31, 2026. Updates to coverage made after May 31, 2026 are not reflected below. Visit <a href = 'http://manulife.ca/signin' target = '_blank'>manulife.ca/signin</a> and login or access the Plan Member site from <a href ='https://upoint.aon.com/' target = '_blank'>UPoint</a> to review your up-to-date coverage elections.";
            let frText = "Le relevé de vos assurances collectives ci-dessous est établi d’après vos garanties et données d’emploi au 31 mai 2026. Les modifications apportées à votre couverture après cette date n’apparaissent pas ici. Allez à <a href='https://wwwec7.manulife.com/signin/fr' target='_blank'>manulife.ca/signin</a> et ouvrez une session, ou accédez au site des participants à partir de <a href='https://upoint.aon.com/' target='_blank'>UPoint</a>, pour passer en revue vos choix les plus récents.";
            coveragetext1 = lang == 'E' ? enText : frText;
        }

        $("#coveragetext1").html(coveragetext1)

       
    }

  top.document.title =
    lang == "E"
      ? "Premier Canada - Your Total Rewards Statement"
      : "Premier Canada - Votre relev" +
        String.fromCharCode(233) +
        " de r" +
        String.fromCharCode(233) +
        "mun" +
        String.fromCharCode(233) +
        "ration globale";

  if (thePage != "P") {
    if (location.href.indexOf("params=") >= 0) {
      var empname = robFname.replace("%20", " ");
    } else {
      var empname = document
        .getElementById("FirstName")
        .innerHTML.replace("%20", " ");
    }
    document.getElementById("greeting").innerHTML =
      lang == "E"
        ? "<strong>Welcome </strong> " + empname
        : "<strong>Bienvenue </strong>" + empname;
  } else {
    if (location.href.indexOf("params=") >= 0) {
      var empname =
        robFname.replace("%20", " ") + " " + robLname.replace("%20", " ");
    } else {
      var empname =
        document.getElementById("FirstName").innerHTML.replace("%20", " ") +
        " " +
        document.getElementById("LastName").innerHTML.replace("%20", " ");
    }
    //document.getElementById("greeting2").innerHTML=empname;
  }

  //  if(thePage=="P"){
  toggleBlock("tbl_Pay", "block");
  // toggleBlock('tbl_Variablepay','block');
  //toggleBlock('tbl_Otherallow','block');
  toggleBlock("tbl_Othben", "block");
  toggleBlock("tbl_Sav", "block");
  toggleBlock("tbl_Flex", "block");
  toggleBlock("tbl_Gov", "block");
  toggleBlock("tbl_Reserve", "block");
  //}

  // if(thePage=="P"){
  toggleBlock("tbl_Core", "block");
  toggleBlock("tbl_RetPlan", "block");
  toggleBlock("tbl_SavPlan", "block");
  toggleBlock("tbl_GovBen", "block");

  // }
  if (document.getElementById("tbl_Reserveheadz")) {
    document.getElementById("tbl_Reserveheadz").style.display = "none";
  }
  // if(document.getElementById("tbl_Reservehead")){document.getElementById("tbl_Reservehead").style.display = "none";}

  // from Premier QC
    if (thePage == 2 || thePage == "P") {
         
 
        var savPlanQtipContentText = "";

        if ($("#PData32").html()!="1") {
            $("#STermText2").hide();
        }

        if ($("#PData17").text() == "0") {
            $("#paidvacation #vac2").hide();
        }

        if ( $("#PData31").html() == 0 && $("#PData29").html() == 0 && $("#PData30").html() == 0 ) {
            $("#varBonusRow").hide();
        } else {
            if (selectedUICulture == "en-US") {
                var text1 = "Your future quarterly awards of " + fmtCurrency($("#PData31").html(), 2) + " through the installment period ending December 2026 are included in Variable pay above.";
                var text2 = "Your recent award of " + fmtCurrency($("#PData29").html(), 2) + " is included in Variable pay above.";
                var text3 = "Your future award of " + fmtCurrency($("#PData30").html(), 2) + " through the installment period ending January 2027 is included in Variable pay above.";

            } else {
                var text1 = "Votre prime trimestrielle de " + fmtCurrency($("#PData31").html(), 2) + " pour la période de versement se terminant en décembre 2026 est incluse dans la Rémunération variable ci-dessus.";
                var text2 = "Votre récente prime de " + fmtCurrency($("#PData29").html(), 2) + " est comprise dans la Rémunération variable ci-dessus.";
                var text3 = "Votre prime future de " + fmtCurrency($("#PData30").html(), 2) + " pour la période de versement se terminant en janvier 2027 est incluse dans la Rémunération variable ci-dessus.";

            }

            $("#PPB span").attr("qtipcontent", text1);
            $("#AAU span").attr("qtipcontent", text2);
            $("#PAAU span").attr("qtipcontent", text3);


            if ($("#PData31").html() == 0) {
                $("#PPB").hide();
            }
            if ($("#PData29").html() == 0) {
                $("#AAU").hide();
            }
            if ($("#PData30").html() == 0) {
                $("#PAAU").hide();
            }

        }
         
        

    if (parseInt(document.getElementById("Sav5").innerHTML) > 0) {
      savPlanQtipContentText =
        lang == "E"
          ? "Premier provides you with a wide range of benefit options. The Group Benefits values are based on the annual value of your elections as of May 31, 2026."
          : "Premier vous offre un vaste éventail d'options de garanties. La valeur de vos différents avantages sociaux collectifs est basée sur la valeur annuelle de vos protections au 31 mars 2026.";
      //: "Premier vous offre un vaste éventail d’options de garanties, en plus de crédits que vous pouvez utiliser pour payer vos options. La valeur de vos différents avantages sociaux collectifs est basée sur la valeur annuelle de vos protections au 30 avril 2025.";
    } else {
      savPlanQtipContentText =
        lang == "E"
          ? "Premier provides you with a wide range of benefit options and provides Premier Credits that you can spend on a variety of benefits, retirement and savings options or receive back as taxable cash in your pay. The Group Benefits values are based on the annual value of your elections as of May 31, 2026."
          : "Premier vous offre un vaste éventail d'options de garanties, en plus de crédits que vous pouvez utiliser pour payer vos options, contribuer à vos régimes de retraite et d'épargne, ou recevoir en espèces imposables sur votre paie. La valeur de vos différents avantages sociaux collectifs est basée sur la valeur annuelle de vos protections au 31 mars 2026.";
    }

    $("#SavPlan").attr("qtipcontent", savPlanQtipContentText);

    //console.log("EmpGroup: " + document.getElementById("EmpGroup").innerHTML)

    /*document.getElementById("row14").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass == 4)) ? "none" : "";
    document.getElementById("row15").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass == 4)) ? "none" : "";
    document.getElementById("row16").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass == 4)) ? "none" : "";
    document.getElementById("row17").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass == 4)) ? "none" : "";
    document.getElementById("row18").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass != 4)) ? "none" : "";
    document.getElementById("row19").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 2 || (parseInt(document.getElementById("EmpGroup").innerHTML) == 1 && robEmpclass != 4)) ? "none" : "";
    document.getElementById("row19a").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 1) ? "none" : "";
    document.getElementById("row19b").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 1) ? "none" : "";
    if (thePage != "P") {
      document.getElementById("row19c").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 1) ? "none" : (document.getElementById("medopt").selectedIndex > 0 ? "none" : "");
    } else {
      document.getElementById("row19c").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 1) ? "none" : (parseInt(document.getElementById("Glance2").innerHTML) > 0 ? "none" : "");
    }
    document.getElementById("row19d").style.display = (parseInt(document.getElementById("EmpGroup").innerHTML) == 1) ? "none" : "";
    //document.getElementById("row20").style.display=(AIY07CO == 0)?"none":"";*/
    if (document.getElementById("otc1")) {
      premOther1 = parseInt(document.getElementById("otc1").innerHTML);
      premOther2 = parseInt(document.getElementById("otc2").innerHTML);
      premOther3 = parseInt(document.getElementById("otc3").innerHTML);
      premOther4 = parseInt(document.getElementById("otc4").innerHTML);
      premotc5desc = document.getElementById("otc5desc").innerHTML;
      premOther5 = parseInt(document.getElementById("otc5").innerHTML);
      premotc6desc = document.getElementById("otc6desc").innerHTML;
      premOther6 = parseInt(document.getElementById("otc6").innerHTML);
      premOther7 = parseInt(document.getElementById("oth1").innerHTML);
      premOther8 = parseInt(document.getElementById("oth2").innerHTML);
      premOther9 = parseInt(document.getElementById("oth3").innerHTML);
      premOther10 = parseInt(document.getElementById("oth4").innerHTML);
      premoth5desc = document.getElementById("oth5desc").innerHTML;
      premOther11 = parseInt(document.getElementById("oth5").innerHTML);
      premoth6desc = document.getElementById("oth6desc").innerHTML;
      premOther12 = parseInt(document.getElementById("oth6").innerHTML);
      premOther13 = parseInt(document.getElementById("ob1").innerHTML);
      premOther14 = parseInt(document.getElementById("ob2").innerHTML);
      premOther15 = parseInt(document.getElementById("ob3").innerHTML);
      premOther16 = parseInt(document.getElementById("ob4").innerHTML);
      premob5desc = document.getElementById("ob5desc").innerHTML;
      premOther17 = parseInt(document.getElementById("ob5").innerHTML);
      premob6desc = document.getElementById("ob6desc").innerHTML;
      premOther18 = parseInt(document.getElementById("ob6").innerHTML);
      premotctot =
        premOther1 +
        premOther2 +
        premOther3 +
        premOther4 +
        premOther5 +
        premOther6;
      premothtot =
        premOther7 +
        premOther8 +
        premOther9 +
        premOther10 +
        premOther11 +
        premOther12;
      premobtot =
        premOther13 +
        premOther14 +
        premOther15 +
        premOther16 +
        premOther17 +
        premOther18;

      showOtc =
        premOther1 +
          premOther2 +
          premOther3 +
          premOther4 +
          premOther5 +
          premOther6 >
        0
          ? true
          : false;
      labelwidth = thePage != "P" ? "448px" : "260px";

      //if (loadflag == 0) {
      if (showOtc == true) {
        if (lang == "E") {
          document.getElementById("spanlabel4").innerHTML +=
            premOther1 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Signing bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther1, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther2 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Guaranteed bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther2, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther3 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Retention bonus</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther3, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther4 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Relocation support</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther4, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther5 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premotc5desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther5, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther6 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premotc6desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther6, 0) +
                "</div>"
              : "";
        } else {
          document.getElementById("spanlabel4").innerHTML +=
            premOther1 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime d'embauche</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther1, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther2 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime garantie</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther2, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther3 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Prime de fidélisation</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther3, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther4 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Aide au transfert</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther4, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther5 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premotc5desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther5, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel4").innerHTML +=
            premOther6 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premotc6desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther6, 0) +
                "</div>"
              : "";
        }
        document.getElementById("spanPay4").style.width = "15%";
        document.getElementById("spanPay4").style.display = "";
        document.getElementById("spanPay4_2").style.display = "none";
        document.getElementById("spanPay4").style.verticalAlign = "top";
        document.getElementById("spanPay4").innerHTML = fmtCurrency(
          premotctot,
          0,
        );

        document.getElementById("row4").style.display = "";
      } else {
        document.getElementById("row4").style.display = "none";
      }

      showOther =
        premOther7 +
          premOther8 +
          premOther9 +
          premOther10 +
          premOther11 +
          premOther12 >
        0
          ? true
          : false;
      if (showOther == true) {
        if (lang == "E") {
          document.getElementById("spanlabel5").innerHTML +=
            premOther7 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Automobile allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther7, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther8 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Transit allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther8, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther9 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Living allowance</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther9, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther10 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Parking</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther10, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther11 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premoth5desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther11, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther12 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premoth6desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther12, 0) +
                "</div>"
              : "";
        } else {
          document.getElementById("spanlabel5").innerHTML +=
            premOther7 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité pour usage de véhicule personnel</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther7, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther8 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité de transport</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther8, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther9 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Indemnité de séjour</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther9, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther10 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;Stationnement</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther10, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther11 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premoth5desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther11, 0) +
                "</div>"
              : "";
          document.getElementById("spanlabel5").innerHTML +=
            premOther12 > 0
              ? "<br><div style='width: " +
                labelwidth +
                ";float:left'>&#0149;&nbsp;" +
                premoth6desc +
                "</div><div style='width: 80px; float: left; text-align: right'>" +
                fmtCurrency(premOther12, 0) +
                "</div>"
              : "";
        }
        document.getElementById("spanPay5").style.width = "15%";
        document.getElementById("spanPay5").style.display = "";
        document.getElementById("spanPay5").style.visibility = "visible";
        document.getElementById("spanPay5_2").style.display = "none";
        document.getElementById("spanPay5").style.verticalAlign = "top";
        document.getElementById("spanPay5").innerHTML = fmtCurrency(
          premothtot,
          0,
        );
        document.getElementById("row5").style.display = "";
      } else {
        document.getElementById("row5").style.display = "none";
      }
      //}
      /* if (document.getElementById("BusUnit").innerHTML != "A") {
        document.getElementById("spanSav6").innerHTML = fmtCurrency(AIY06CO, 0);
        document.getElementById("spanSav6a").innerHTML = fmtCurrency(AIY02CO, 0);
        document.getElementById("spanSav6b").innerHTML = fmtCurrency(AIY04CO, 0);
        document.getElementById("spanSav6c").innerHTML = fmtCurrency(AIY03CO, 0);
        document.getElementById("spanSav6d").innerHTML = fmtCurrency(AIY05CO, 0);
      }*/

      //if (loadflag == 0) {
      showOb =
        premOther13 +
          premOther14 +
          premOther15 +
          premOther16 +
          premOther17 +
          premOther18 >
        0
          ? true
          : false;
      document.getElementById("row31").style.display = "none";
      document.getElementById("row32").style.display = "none";
      if (showOb == true) {
        if (lang == "E") {
          if (premOther13 > 0) {
            document.getElementById("spanlabel27").innerHTML =
              "Executive Medical";
            document.getElementById("spanOthben1").innerHTML = fmtCurrency(
              premOther13,
              0,
            );
            document.getElementById("row27").style.display = "";
          } else {
            document.getElementById("row27").style.display = "none";
          }
          if (premOther14 > 0) {
            document.getElementById("spanlabel28").innerHTML = "Club Dues";
            document.getElementById("spanOthben2").innerHTML = fmtCurrency(
              premOther14,
              0,
            );
            document.getElementById("row28").style.display = "";
          } else {
            document.getElementById("row28").style.display = "none";
          }
          if (premOther15 > 0) {
            document.getElementById("spanlabel29").innerHTML = "House Loans";
            document.getElementById("spanOthben3").innerHTML = fmtCurrency(
              premOther15,
              0,
            );
            document.getElementById("row29").style.display = "";
          } else {
            document.getElementById("row29").style.display = "none";
          }
          if (premOther16 > 0) {
            document.getElementById("spanlabel30").innerHTML =
              "Training & Development";
            document.getElementById("spanOthben4").innerHTML = fmtCurrency(
              premOther16,
              0,
            );
            document.getElementById("row30").style.display = "";
          } else {
            document.getElementById("row30").style.display = "none";
          }
        } else {
          if (premOther13 > 0) {
            document.getElementById("spanlabel27").innerHTML =
              "Protection médicale des dirigeants";
            document.getElementById("spanOthben1").innerHTML = fmtCurrency(
              premOther13,
              0,
            );
            document.getElementById("row27").style.display = "";
          } else {
            document.getElementById("row27").style.display = "none";
          }
          if (premOther14 > 0) {
            document.getElementById("spanlabel28").innerHTML =
              "Frais d'adhésion à des clubs";
            document.getElementById("spanOthben2").innerHTML = fmtCurrency(
              premOther14,
              0,
            );
            document.getElementById("row28").style.display = "";
          } else {
            document.getElementById("row28").style.display = "none";
          }
          if (premOther15 > 0) {
            document.getElementById("spanlabel29").innerHTML =
              "Prêts hypothécaires";
            document.getElementById("spanOthben3").innerHTML = fmtCurrency(
              premOther15,
              0,
            );
            document.getElementById("row29").style.display = "";
          } else {
            document.getElementById("row29").style.display = "none";
          }
          if (premOther16 > 0) {
            document.getElementById("spanlabel30").innerHTML =
              "Formation et perfectionnement";
            document.getElementById("spanOthben4").innerHTML = fmtCurrency(
              premOther16,
              0,
            );
            document.getElementById("row30").style.display = "";
          } else {
            document.getElementById("row30").style.display = "none";
          }
        }
        if (premOther17 > 0) {
          document.getElementById("spanlabel31").innerHTML = premob5desc;
          document.getElementById("spanReserve1").innerHTML = fmtCurrency(
            premOther17,
            0,
          );
          document.getElementById("row31").style.display = "";
        } else {
          document.getElementById("row31").style.display = "none";
        }
        if (premOther18 > 0) {
          document.getElementById("spanlabel32").innerHTML = premob5desc;
          document.getElementById("spanReserve2").innerHTML = fmtCurrency(
            premOther18,
            0,
          );
          document.getElementById("row32").style.display = "";
        } else {
          document.getElementById("row32").style.display = "none";
        }
        document.getElementById("tbl_Othbenhead").style.display = "";
        document.getElementById("subtotal_Othben_1").innerHTML = fmtCurrency(
          robOtherben,
          0,
        );
      }
      // new in 2021
      //   document.getElementById('spantot_Rewards_2').innerHTML=fmtCurrency(AIY09CO+AIY01CO+robSal+robBonus+robOnetime+robOthercomp+robOtherben,0);
      //
    } else {
      //document.getElementById("tbl_Othbenhead").style.display="none";
    }
    //}
  }

  if (thePage == "P") {
    // commented 2021			if(document.getElementById("bp")){document.getElementById("bp").style.display = "none";}

    var lnks = document.getElementsByTagName("a");
    var n = lnks.length;
    for (var i = 0; i < n; i++) {
      if (lnks[i].className == "blueLink") {
        lnks[i].className = "blueLink2";
        lnks[i].onclick = "return false";
      }
    }
  }

  window.status = "";
  document.getElementById("sitecover").style.visibility = "visible";
  // console.log("f: " + parseFloat(document.getElementById('subtot_Flex').innerHTML)) ;
  $("#footerL1").css(
    "display",
    parseFloat(document.getElementById("subtot_Flex").innerHTML) > 0
      ? ""
      : "none",
  );
  $("#footerL2").css(
    "border-right",
    parseFloat(document.getElementById("subtot_Flex").innerHTML) > 0
      ? "1px solid #626469"
      : "0px none",
  );
  //document.getElementById("footerL3").style.display=(parseFloat(document.getElementById('PData20').innerHTML) > 0) ? "" : "none";

  //alert("end of loadPage")
}

function resizePage() {
  var thePage = document.getElementById("pageID").value;
}

function updateChart(thePage) {
  var startpos = location.search.indexOf("params=");

  var val1 = Math.round(
    startpos >= 0
      ? robSal + robBonus + robOnetime + robOthercomp
      : document.getElementById("subtot_Pay").innerHTML,
  );
  var val2 = Math.round(
    startpos >= 0 ? 0 : document.getElementById("subtot_Flex").innerHTML,
  );
  var val3 = Math.round(
    startpos >= 0 ? AIY01CO : document.getElementById("subtot_Sav").innerHTML,
  );
  var val4 = Math.round(
    startpos >= 0 || isRecruit == 1
      ? robOtherben
      : document.getElementById("subtot_Othben").innerHTML,
  );
  //var val5=Math.round(document.getElementById('subtot_Reserve').innerHTML);
  var val6 = Math.round(
    startpos >= 0 ? AIY09CO : document.getElementById("subtot_Gov").innerHTML,
  );
  var val7 = Math.round(
    startpos >= 0 ? 0 : document.getElementById("Pay1").innerHTML,
  );
  var val8 = Math.round(
    startpos >= 0 ? 0 : document.getElementById("Pay2").innerHTML,
  );
  var val9 = Math.round(
    startpos >= 0 ? 0 : document.getElementById("Pay3").innerHTML,
  );
  var val10 = startpos >= 0 ? robOtherben : 0; //Math.round(document.getElementById('subtot_SIP').innerHTML);
  var val11 = Math.round(
    startpos >= 0 || isRecruit == 1
      ? robPay + AIY01CO + AIY09CO + robOtherben
      : document.getElementById("tot_Rewards").innerHTML,
  );
  var val12 = Math.round(
    startpos >= 0 ? TOTCSXXEE : document.getElementById("tot_eeCost").innerHTML,
  );
  var val13 = Math.round(
    startpos >= 0 ? TOTCSXXCO : document.getElementById("tot_erCost").innerHTML,
  );
  //alert(val1);alert(val2);alert(val3);alert(val4);alert(val6);alert(val7);alert(val8);alert(val9);alert(val10);alert(val11);alert(val12);alert(val13);
  //alert(val4)
  var slice1 =
    lang == "E"
      ? "Cash compensation"
      : "R" +
        String.fromCharCode(233) +
        "mun" +
        String.fromCharCode(233) +
        "ration en esp" +
        String.fromCharCode(232) +
        "ces";
  var slice2 =
    lang == "E"
      ? "Long Term Incentive compensation"
      : "R" +
        String.fromCharCode(233) +
        "mun" +
        String.fromCharCode(233) +
        "ration incitative " +
        String.fromCharCode(224) +
        " long terme";
  var slice3 =
    lang == "E"
      ? "Group Benefits, Retirement and Savings programs"
      : "Programme d'avantages sociaux et r" +
        String.fromCharCode(233) +
        "gimes de retraite et d'" +
        String.fromCharCode(233) +
        "pargne collectifs";
  var slice4 = lang == "E" ? "Other Benefits" : "Autres avantages";
  var slice5 = lang == "E" ? "ShareMatch" : "Programme ShareMatch";
  var slice6 =
    lang == "E"
      ? "Government Benefits"
      : "Prestations d'" + String.fromCharCode(201) + "tat";
  var slice7 =
    lang == "E"
      ? "Annual Base Salary as at April 30, 2016"
      : "Salaire annualis" + String.fromCharCode(233) + "";
  var slice8 =
    lang == "E"
      ? "Other Allowances"
      : "Autres indemnit" + String.fromCharCode(233) + "s";
  var slice9 =
    lang == "E"
      ? "Variable Pay"
      : "R" +
        String.fromCharCode(233) +
        "mun" +
        String.fromCharCode(233) +
        "ration variable";
  var slice10 =
    lang == "E"
      ? "Supplemental Incentive Performance Awards (SIP)"
      : "Primes au rendement suppl" + String.fromCharCode(233) + "mentaires";
  var slice11 = lang == "E" ? "ShareMatch" : "Programme ShareMatch";
  var slice12 = lang == "E" ? "Your investment" : "Votre investissement";
  var slice13 =
    lang == "E"
      ? "Premier's investment In you"
      : "Investissement d'Premier " +
        String.fromCharCode(224) +
        " votre " +
        String.fromCharCode(233) +
        "gard";

  if (thePage == 2 || thePage == 3) {
    /*	var chartheight=0; var chartangle=0; var itemstoshow=(val1>0)+(val2>0)+(val3>0)+(val4>0)+(val7>0);
  if(itemstoshow < 3){chartheight=314;chartangle=0}
  else if(itemstoshow < 4){chartheight=334;chartangle=0}
  else if(itemstoshow < 6){chartheight=354;chartangle=0}
  else if(itemstoshow < 8){chartheight=370;chartangle=0}
  else if(itemstoshow < 10){chartheight=490;chartangle=350}
  else if(itemstoshow < 12){chartheight=410;chartangle=340}
  else{chartheight=450;chartangle=330}
  */

    if (thePage == 2) {
      document.getElementById("chartcontainer").innerHTML = "";

      var data1new = [{ label: slice1, val: val1, color: "#5d6d78" }];
      if (parseFloat(val2) > 0) {
        data1new.push({ label: slice2, val: val2, color: "#000" });
      }
      if (parseFloat(val3) > 0) {
        data1new.push({ label: slice3, val: val3, color: "#262836" });
      }
      if (parseFloat(val4) > 0) {
        data1new.push({ label: slice4, val: val4, color: "#46535e" });
      }
      //if(parseFloat(val5)>0){data1new.push({label: slice5,val:val5, color:"#E5DF19"});}
      if (parseFloat(val6) > 0) {
        data1new.push({ label: slice6, val: val6, color: "#acc0c4" });
      }

      var chart = AmCharts.makeChart("chartcontainer", {
        type: "pie",
        dataProvider: data1new,
        colorField: "color",
        numberFormatter:
          lang == "E"
            ? {
                precision: -1,
                decimalSeparator: ".",
                thousandsSeparator: ",",
              }
            : {
                precision: -1,
                decimalSeparator: ".",
                thousandsSeparator: " ",
              },
        outlineThickness: 0,
        addClassNames: true,
        titleField: "label",
        valueField: "val",
        fontFamily: "Arial",
        labelRadius: 10,
        startEffect: "easeOutSine",
        startDuration: 1,
        startAngle: 330,
        pullOutRadius: 0,
        autoResize: true,
        balloonText: "",
        radius:
          document.getElementById("pageID").value == "P"
            ? "40%"
            : val11 > 800000
              ? "30%"
              : "30%",
        innerRadius:
          document.getElementById("pageID").value == "P"
            ? "67%"
            : val11 > 800000
              ? "67%"
              : "67%",
        labelText:
          lang == "E"
            ? document.getElementById("pageID").value == "P"
              ? ""
              : "$[[value]]"
            : document.getElementById("pageID").value == "P"
              ? ""
              : "[[value]] $",
        export: {
          enabled: true,
        },
        legend: {
          align: "center",
          borderAlpha: 0,
          valueText:
            lang == "E"
              ? document.getElementById("pageID").value == "P"
                ? "$[[value]]"
                : ""
              : document.getElementById("pageID").value == "P"
                ? "[[value]] $"
                : "",
          marginLeft: 6,
          markerSize: 10,
          maxColumns: 1,
          marginTop: 16,
          spacing: 2,
          switchable: false,
          valueWidth: document.getElementById("pageID").value == "P" ? 50 : 90,
          labelWidth:
            document.getElementById("pageID").value == "P" ? 100 : 200,
          maxWidth: 250,
        },
      });

      chart.addLabel(
        "0%",
        thePage == "P" ? "43%" : "45%",
        fmtCurrency(parseInt(val11), 0),
        "center",
        document.getElementById("pageID").value == "P" ? 13 : 18,
        "#626469",
        0,
        1,
        true,
      );
      if (document.getElementById("pageID").value != "P") {
        chart.startDuration = 1;
        chart.startEffect = ">";
      } else {
        chart.startDuration = 0;
        chart.startEffect = "";
      }
      if (document.getElementById("pageID").value == "P") {
        document.getElementById("chartcontainer").style.height =
          lang == "E" ? (val11 > 800000 ? "440px" : "400px") : "400px";
      }
      if (document.getElementById("pageID").value == "P") {
        chart.invalidateSize();
      }
      //secont chart
    } else if (thePage == 3 || thePage == "P") {
      var data3new = [
        { label: slice12, val: val12, color: "#262836" },
        { label: slice13, val: val13, color: "#acc0c4" },
      ];

      var chart3 = AmCharts.makeChart("chartcontainer2", {
        type: "pie",
        numberFormatter:
          lang == "E"
            ? {
                precision: -1,
                decimalSeparator: ".",
                thousandsSeparator: ",",
              }
            : {
                precision: -1,
                decimalSeparator: ".",
                thousandsSeparator: " ",
              },
        dataProvider: data3new,
        colorField: "color",
        outlineThickness: 0,
        addClassNames: true,
        titleField: "label",
        valueField: "val",
        labelRadius: 10,
        fontFamily: "Arial",
        startEffect: "easeOutSine",
        pullOutRadius: 0,
        startDuration: 1,
        startAngle: 200,
        autoResize: true,
        balloonText: "",
        radius: document.getElementById("pageID").value == "P" ? "40%" : "27%",
        innerRadius:
          document.getElementById("pageID").value == "P" ? "67%" : "67%",
        labelText:
          lang == "E"
            ? document.getElementById("pageID").value == "P"
              ? ""
              : "$[[value]]"
            : document.getElementById("pageID").value == "P"
              ? ""
              : "[[value]] $",
        export: {
          enabled: true,
        },
        legend: {
          align: "center",
          borderAlpha: 0,
          valueText:
            lang == "E"
              ? document.getElementById("pageID").value == "P"
                ? "$[[value]]"
                : ""
              : document.getElementById("pageID").value == "P"
                ? "[[value]] $"
                : "",
          marginLeft: 15,
          maxColumns: 1,
          marginTop: 24,
          reversedOrder: true,
          switchable: false,
          markerSize: 5,
          spacing: 2,
          valueWidth: document.getElementById("pageID").value == "P" ? 52 : 90,
          labelWidth:
            document.getElementById("pageID").value == "P" ? 108 : 190,
        },
      });

      chart3.addLabel(
        "0%",
        "46%",
        fmtCurrency(parseFloat(val12) + parseFloat(val13), 0),
        "center",
        document.getElementById("pageID").value == "P" ? 14 : 18,
        "#626469",
        0,
        1,
        true,
      );
      chart3.balloonText = "";
      //if(lang!="E"){document.getElementById("chartdiv").style.height=(chartheight-140)+"px"}
      if (document.getElementById("pageID").value != "P") {
        chart3.startDuration = 1;
        chart3.startEffect = ">";
      } else {
        chart3.startDuration = 0;
        chart3.startEffect = "";
      }
      //chart.addLabel(0,((navigator.userAgent.indexOf("Firefox") >= 0 || navigator.userAgent.indexOf("Chrome") >= 0)?100:100),fmtCurrency(parseFloat(val5)+parseFloat(val6),0),"center",18,"#000000",0,1,true);
      if (document.getElementById("pageID").value == "P") {
        document.getElementById("chartcontainer2").style.height =
          lang == "E" ? "320px" : "360px";
      }
      if (document.getElementById("pageID").value == "P") {
        chart3.invalidateSize();
      }
    }
  }

  //if(thePage==3){document.getElementById("chartcontainer3").style.visibility="visible";}

  window.status = "";
  chartfinished = true;
}
/*New change - Sid*/
function handleInit() {
  chart.legend.addListener("rollOverItem", handleRollOver);
}

function handleRollOver(e) {
  var wedge = e.dataItem.wedge.node;
  wedge.parentNode.appendChild(wedge);
}
/*New change - Sid*/

function blurMe(lnk) {
  if (lnk.blur) lnk.blur();
}

function printPage() {
  if (lang == "E") {
    if (
      confirm(
        "Warning!\n\nYour statement contains confidential information, including your salary, your date of birth and information about your family. If you choose to print your statement from a shared printer, be sure that you can go to it quickly to ensure that your privacy is not compromised.",
      ) == true
    ) {
      document.forms["frmPrint"].submit();
    }
  } else {
    if (
      confirm(
        "Attention!!\n\nVotre relevé renferme des renseignements confidentiels, notamment votre salaire, votre date de naissance et de l'information sur votre famille.  Si vous faites imprimer le relevé sur une imprimante partagée, assurez-vous de le récupérer aussitôt que possible afin d'en préserver le caractère confidentiel.",
      ) == true
    ) {
      document.forms["frmPrint"].submit();
    }
  }
}

function toggleBlock(blockID, setState) {
  //HideToolTip();

  try {
    var currentState = document.getElementById(blockID).style.display;

    if (setState != null) {
      document.getElementById(blockID).style.display = setState;
    } else {
      document.getElementById(blockID).style.display =
        currentState == "none" ? "" : "none";
    }
    var tbl = blockID.substring(blockID.indexOf("_") + 1, blockID.length);
    if (document.getElementById("arrow_" + tbl)) {
      if (setState != null) {
        document.getElementById("arrow_" + tbl).src =
          setState == "block"
            ? "media/arrow_open.gif"
            : "media/arrow_closed.gif";
      } else {
        document.getElementById("arrow_" + tbl).src =
          currentState == "none" || blockID == "Pay"
            ? "media/arrow_open.gif"
            : "media/arrow_closed.gif";
      }
      if (document.getElementById("pageID").value != "P") {
        document.getElementById("toggle1").style.color =
          setState == "block" ? "#0183a9" : "#0183a9";
        document.getElementById("toggle2").style.color =
          setState == "none" ? "#0183a9" : "#0183a9";
      }
    }

    if (blockID == "tbl_Othben" && newSS == true) {
      if (document.getElementById(blockID).style.display != "none") {
        if (robOther17 > 0) {
          document.getElementById("row31").style.display = "";
        }
        if (robOther18 > 0) {
          document.getElementById("row32").style.display = "";
        }
      } else {
        document.getElementById("row31").style.display = "none";
        document.getElementById("row32").style.display = "none";
      }
    }
    //if(document.getElementById("subtotal_" + tbl + "_1")){
    //	document.getElementById("subtotal_" + tbl + "_1").style.display=(currentState=="none" && tbl != "Pay")?"none":"";
    //}
    //if(document.getElementById("subtotal_" + tbl + "_2")){
    //	document.getElementById("subtotal_" + tbl + "_2").style.display=(currentState=="none" && tbl != "Pay")?"none":"";
    //}
  } catch (e) {}
}

function close_window() {
  top.window.opener = top;
  top.window.open("", "_parent", "");
  top.window.close();
}
