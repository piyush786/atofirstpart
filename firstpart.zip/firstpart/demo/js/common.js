function close_window() {
  top.window.opener = top;
  top.window.open("", "_parent", "");
  top.window.close();
}

//lang=document.getElementById("userlang").value;

var idleTime = 0;
$(document).ready(function () {
  //document.getElementById("lnkEngLang").setAttribute("onclick", "EnLangToggleRedirection()");
  //  document.getElementById("lnkFRLang").setAttribute("onclick", "FrLangToggleRedirection()");
  //Increment the idle time counter every minute.
  var idleInterval = setInterval(timerIncrement, 60000); // 1 minute
  //document.getElementById('eeName').innerHTML=document.getElementById('span_FirstName').innerHTML +' ' + document.getElementById('span_LastName').innerHTML;
});

function timerIncrement() {
  idleTime = idleTime + 1;

  if (idleTime > 10)
    //28{ // 20 minutes
    //jQuery.ajax({ cache: false, url: '/static/themes/AonCanada/SessionHandler/Logout.ashx'});
    //window.location.href = "/session-timeout.html";
    Logout();
  //window.open('/session-timeout.html','_self');
}

// (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
//   (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
//     m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
//       })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

// ga("create", "UA-37024117-13", "auto");
// ga("send", "pageview");

function getProvIndex(prv) {
  switch (prv) {
    case "ALTA":
      return 1;
      break;
    case "BC":
      return 0;
      break;
    case "MAN":
      return 3;
      break;
    case "NFLD":
      return 9;
      break;
    case "NS":
      return 7;
      break;
    case "NWT":
      return 11;
      break;
    case "ONT":
      return 4;
      break;
    case "QUE":
      return 5;
      break;
    case "SASK":
      return 2;
      break;
    case "YUK":
      return 10;
      break;
    case "NB":
      return 6;
      break;
    case "PEI":
      return 8;
      break;
  }
}
function getStateIndex(st) {
  switch (st) {
    case "AL":
      return 0;
      break;
    case "AK":
      return 1;
      break;
    case "AZ":
      return 2;
      break;
    case "AR":
      return 3;
      break;
    case "CA":
      return 4;
      break;
    case "CO":
      return 5;
      break;
    case "CT":
      return 6;
      break;
    case "DE":
      return 7;
      break;
    case "DC":
      return 8;
      break;
    case "FL":
      return 9;
      break;
    case "GA":
      return 10;
      break;
    case "HI":
      return 11;
      break;
    case "ID":
      return 12;
      break;
    case "IL":
      return 13;
      break;
    case "IN":
      return 14;
      break;
    case "IA":
      return 15;
      break;
    case "KS":
      return 16;
      break;
    case "KY":
      return 17;
      break;
    case "LA":
      return 18;
      break;
    case "ME":
      return 19;
      break;
    case "MD":
      return 20;
      break;
    case "MA":
      return 21;
      break;
    case "MI":
      return 22;
      break;
    case "MN":
      return 23;
      break;
    case "MS":
      return 24;
      break;
    case "MO":
      return 25;
      break;
    case "MT":
      return 26;
      break;
    case "NE":
      return 27;
      break;
    case "NV":
      return 28;
      break;
    case "NH":
      return 29;
      break;
    case "NJ":
      return 30;
      break;
    case "NM":
      return 31;
      break;
    case "NY":
      return 32;
      break;
    case "NC":
      return 33;
      break;
    case "ND":
      return 34;
      break;
    case "OH":
      return 35;
      break;
    case "OK":
      return 36;
      break;
    case "OR":
      return 37;
      break;
    case "PA":
      return 38;
      break;
    case "RI":
      return 39;
      break;
    case "SC":
      return 40;
      break;
    case "SD":
      return 41;
      break;
    case "TN":
      return 42;
      break;
    case "TX":
      return 43;
      break;
    case "UT":
      return 44;
      break;
    case "VT":
      return 45;
      break;
    case "VA":
      return 46;
      break;
    case "WA":
      return 47;
      break;
    case "WV":
      return 48;
      break;
    case "WI":
      return 49;
      break;
    case "WY":
      return 50;
      break;
  }
}
