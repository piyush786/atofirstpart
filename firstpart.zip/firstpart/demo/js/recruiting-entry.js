var monthArr = new Array(12)
monthArr[0] = "January"; monthArr[1] = "February"; monthArr[2] = "March"; monthArr[3] = "April"; monthArr[4] = "May"; monthArr[5] = "June"
monthArr[6] = "July"; monthArr[7] = "August"; monthArr[8] = "September"; monthArr[9] = "October"; monthArr[10] = "November"; monthArr[11] = "December"


var message;

function openWindow(file1, w, h, r, s) {
    var xc = screen.availWidth / 2; var yc = screen.availHeight / 2;
    window.open(file1, "popup", "left=" + (xc - (w / 2)) + ",top=" + (yc - (h / 2)) + ",width=" + w + ",height=" + h + ",resizable=" + r + ",scrollbars=" + s)
}

function DeleteScenarios() {

    var datatoDelete = "";
    var sel = document.getElementsByName("checkbxlstdelete");

    for (var i = 0; i < sel.length; i++) {
        if (sel[i].checked == true) {

            datatoDelete = datatoDelete + sel[i].value + ";";

        }
    }

    jQuery.ajax({
        cache: false, url: '/static/themes/AonCanada/SaveScenario.ashx?scenAction=2' + '&data=' + datatoDelete,
        success: function (data) {
            alert("Scenario(s) deleted successfully!");
            location.reload();
        },
        error: function (data) {
        }
    });
}

function openDeletePopup() {

    document.getElementById("deletePopupParent").style.display = 'block';
}
function closeDeletePopup() {
    document.getElementById("deletePopupParent").style.display = 'none';
}
function displaySS() {
    var e = document.getElementById("saveScenarioDest");
    var strUser = e.options[e.selectedIndex].value;
    //if(strUser!="0")
    //{
    window.location.href = "F/recruiting.html?/recruiting?ssId=" + strUser;
    // }

}


function ValidateCheckBoxList() {
    var checkBoxList = document.getElementById("deleteScenarioschkbx");
    var checkboxes = checkBoxList.getElementsByTagName("input");
    var isValid = false;
    for (var i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            isValid = true;
            break;
        }
    }
    //  args.IsValid = isValid;
    if (isValid == true) {

        if (confirm(message.ConfirmDelete)) {
            return true;
        }
        else {
            return false;
        }
    }
    else {
        alert(message.SelectScenario);
    }
}


function selectCheck() {
    var e = document.getElementById("ddSaveScenarioDest");
    var strUser = e.selectedIndex;
    if (strUser == "0") {
        alert(message.SelectScenario);
        return false;
    }
    else {
        var ssId = e.options[e.selectedIndex].value;
        window.location.href = message.RecruitingUrl + "?ssId=" + ssId;

    }

}

 