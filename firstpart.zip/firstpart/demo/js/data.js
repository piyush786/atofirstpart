var test = location.search.indexOf("params=") >= 0 || isRecruit == 1;

function showReferalAward() {
  var pdata10Data = parseFloat(document.getElementById("PData10").innerHTML);
  if (pdata10Data > 0) {
    document.getElementById("RfAwdAmt").innerHTML = fmtCurrency(pdata10Data, 0);
  } else {
    $("#ReferalAward").hide();
  }
}

function setFields1() {
  console.log("fields1");
  var spantot_Rewardsdata = test
    ? robPay + AIY01CO + AIY09CO + robOtherben
    : document.getElementById("tot_Rewards").innerHTML;
  document.getElementById("totalcomp").innerHTML = fmtCurrency(
    spantot_Rewardsdata,
    0
  );
}
function setFields2() {
  var spanPay1data = test ? robSal : document.getElementById("Pay1").innerHTML;
  var spanPay2data = test ? 0 : document.getElementById("Pay2").innerHTML;
  var spanPay3data = test
    ? robBonus
    : document.getElementById("Pay3").innerHTML;
  var spanPay3adata = test ? 0 : document.getElementById("PData23").innerHTML;
  var spanPay3bdata = test ? 0 : document.getElementById("PData24").innerHTML;
  var spanPay4data = test
    ? robOthercomp
    : document.getElementById("Pay4").innerHTML;

  var spansubtot_Paydata = test
    ? robSal + robBonus + robOnetime + robOthercomp
    : document.getElementById("subtot_Pay").innerHTML;

  var spanFlex1data = test ? 0 : document.getElementById("Flex1").innerHTML;
  var spanFlex2data = test ? 0 : document.getElementById("Flex2").innerHTML;
  var spanFlex2adata = test ? 0 : 0;
  var spanFlex3data = test ? 0 : document.getElementById("Flex3").innerHTML;
  var spanFlex4data = test ? 0 : document.getElementById("Flex4").innerHTML;
  //console.log("spanFlex2data: " + spanFlex2data)
  var spansubtot_Flexdata = test
    ? 0
    : document.getElementById("subtot_Flex").innerHTML;

  var spanSav1data = test
    ? AIY02CO + AIY03CO + AIY04CO
    : document.getElementById("Sav1").innerHTML;
  //console.log("test: " + test.toString())
  // console.log("spanSav1data: " + spanSav1data)
  var spanSav2data = test ? AIY02CO : document.getElementById("Sav2").innerHTML;
  var spanSav3data = test ? AIY03CO : document.getElementById("Sav3").innerHTML;
  var spanSav4data = test ? AIY04CO : document.getElementById("Sav4").innerHTML;
  //console.log("spanSav4data: " + spanSav4data)
  var spanSav5data = test ? AIY05CO : document.getElementById("Sav5").innerHTML;
  var spanSav6data = test ? AIY06CO : document.getElementById("Sav6").innerHTML;
  var spanSav7data = test ? AIY07CO : document.getElementById("Sav7").innerHTML;
  var spanSav8data = test ? AIY08CO : document.getElementById("Sav8").innerHTML;
  var spansubtot_Savdata = test
    ? AIY01CO
    : document.getElementById("subtot_Sav").innerHTML;

  var spansubtot_Otherdata = test
    ? robOnetime + robOthercomp + robOtherben
    : document.getElementById("subtot_Other").innerHTML;

  var spanOthben1data = test
    ? AIY05CO
    : document.getElementById("Othben1").innerHTML; //CS01CO
  var spanOthben2data = test ? 0 : document.getElementById("Othben2").innerHTML;
  var spanOthben3data = test ? 0 : document.getElementById("Othben3").innerHTML;

  var spansubtot_Othbendata = test
    ? 0
    : document.getElementById("subtot_Othben").innerHTML;

  var spansubtot_Reservedata = test
    ? 0
    : document.getElementById("subtot_eeReserve").innerHTML;
  //alert(spansubtot_Reservedata)

  var spansubtot_Govdata = test
    ? parseFloat(CS10CO)
    : document.getElementById("subtot_Gov").innerHTML; //CS10CO
  var spantot_Rewardsdata = test
    ? robPay + spansubtot_Govdata + spansubtot_Savdata
    : document.getElementById("tot_Rewards").innerHTML;

  if (parseFloat(spanPay1data) == 0) {
    document.getElementById("row1").style.display = "none";
  } else {
    document.getElementById("spanPay1").innerHTML =
      parseFloat(spanPay1data) == 0 ? "" : fmtCurrency(spanPay1data, 0);
  }
  if (parseFloat(spanPay2data) == 0) {
    document.getElementById("row2").style.display = "none";
  } else {
    document.getElementById("spanPay2").innerHTML =
      parseFloat(spanPay2data) == 0 ? "" : fmtCurrency(spanPay2data, 0);
  }
  if (parseFloat(spanPay3data) == 0) {
    document.getElementById("row3").style.display = "none";
  } else {
    document.getElementById("spanPay3").innerHTML =
      parseFloat(spanPay3data) == 0 ? "" : fmtCurrency(spanPay3data, 0);
  }
  if (!test) {
    //if(parseFloat(spanPay3adata)==0){document.getElementById('row3a').style.display='none';}else{document.getElementById('spanPay3_2a').innerHTML=(parseFloat(spanPay3adata) == 0)?'':'';}
    //if(parseFloat(spanPay3bdata)==0){document.getElementById('row3b').style.display='none';}else{document.getElementById('spanPay3_2b').innerHTML=(parseFloat(spanPay3bdata) == 0)?'':'';}
  }
  //if(parseFloat(spanPay4data)==0){document.getElementById('row4').style.display='none';}else{document.getElementById('spanPay4').innerHTML=(parseFloat(spanPay4data) == 0)?'':fmtCurrency(spanPay4data,0);}

  if (location.search.indexOf("params=") < 0) {
    document.getElementById("row5").style.display = "none";
  }

  document.getElementById("row6").style.display = "none";
  document.getElementById("row7").style.display = "none";
  document.getElementById("row8").style.display = "none";
  document.getElementById("row9").style.display = "none";
  document.getElementById("subtotal_Pay").style.display = "none";
  document.getElementById("subtotal_Pay_1").innerHTML =
    parseFloat(spansubtot_Paydata) == 0
      ? ""
      : fmtCurrency(spansubtot_Paydata, 0);

  if (parseFloat(spansubtot_Flexdata) == 0) {
    document.getElementById("tbl_Flexhead").style.display = "none";
  }
  if (parseFloat(spanFlex1data) == 0) {
    document.getElementById("row10").style.display = "none";
  } else {
    document.getElementById("spanFlex1").innerHTML =
      parseFloat(spanFlex1data) == 0 ? "" : fmtCurrency(spanFlex1data, 0);
  }
  if (parseFloat(spanFlex2data) == 0) {
    document.getElementById("row11").style.display = "none";
  } else {
    document.getElementById("spanFlex2").innerHTML =
      parseFloat(spanFlex2data) == 0 ? "" : fmtCurrency(spanFlex2data, 0);
  }
  //if(parseFloat(spanFlex2adata)==0){document.getElementById('row11a').style.display='none';}else{document.getElementById('spanFlex2a').innerHTML=(parseFloat(spanFlex2adata) == 0)?'':fmtCurrency(spanFlex2adata,0);}
  if (parseFloat(spanFlex3data) == 0) {
    document.getElementById("row12").style.display = "none";
  } else {
    document.getElementById("spanFlex3").innerHTML =
      parseFloat(spanFlex3data) == 0 ? "" : fmtCurrency(spanFlex3data, 0);
  }
  if (!test) {
    if (parseFloat(spanFlex4data) == 0) {
      document.getElementById("row11a").style.display = "none";
    } else {
      document.getElementById("spanFlex2a").innerHTML =
        parseFloat(spanFlex4data) == 0 ? "" : fmtCurrency(spanFlex4data, 0);
    }
  }
  document.getElementById("row13").style.display = "none";
  document.getElementById("subtotal_Flex").style.display = "none";
  document.getElementById("subtotal_Flex_1").innerHTML =
    parseFloat(spansubtot_Flexdata) == 0
      ? ""
      : fmtCurrency(spansubtot_Flexdata, 0);
  if (parseFloat(spansubtot_Savdata) == 0) {
    document.getElementById("tbl_Savhead").style.display = "none";
  }
  if (parseFloat(spanSav1data) == 0) {
    document.getElementById("row14").style.display = "none";
  } else {
    document.getElementById("spanSav1").innerHTML =
      parseFloat(spanSav1data) == 0 ? "" : fmtCurrency(spanSav1data, 0);
  }
  if (parseFloat(spanSav2data) == 0) {
    document.getElementById("row15").style.display = "none";
  } else {
    document.getElementById("spanSav2_2").innerHTML =
      parseFloat(spanSav2data) == 0 ? "" : fmtCurrency(spanSav2data, 0);
  }
  if (parseFloat(spanSav3data) == 0) {
    document.getElementById("row16").style.display = "none";
  } else {
    document.getElementById("spanSav3_2").innerHTML =
      parseFloat(spanSav3data) == 0 ? "" : fmtCurrency(spanSav3data, 0);
  }
  if (parseFloat(spanSav4data) == 0) {
    document.getElementById("row17").style.display = "none";
  } else {
    document.getElementById("spanSav4_2").innerHTML =
      parseFloat(spanSav4data) == 0 ? "" : fmtCurrency(spanSav4data, 0);
  }
  if (parseFloat(spanSav5data) == 0) {
    document.getElementById("row18").style.display = "none";
  } else {
    document.getElementById("spanSav5").innerHTML =
      parseFloat(spanSav5data) == 0 ? "" : fmtCurrency(spanSav5data, 0);
  }
  if (parseFloat(spanSav6data) == 0) {
    document.getElementById("row19").style.display = "none";
  } else {
    document.getElementById("spanSav6").innerHTML =
      parseFloat(spanSav6data) == 0 ? "" : fmtCurrency(spanSav6data, 0);
  }
  if (parseFloat(spanSav7data) == 0) {
    document.getElementById("row20").style.display = "none";
  } else {
    document.getElementById("spanSav7").innerHTML =
      parseFloat(spanSav7data) == 0 ? "" : fmtCurrency(spanSav7data, 0);
  }
  if (parseFloat(spanSav8data) == 0) {
    document.getElementById("row21").style.display = "none";
  } else {
    document.getElementById("spanSav8").innerHTML =
      parseFloat(spanSav8data) == 0 ? "" : fmtCurrency(spanSav8data, 0);
  }
  //document.getElementById("subtotal_Sav").style.display = "none";
  document.getElementById("subtotal_Sav_1").innerHTML =
    parseFloat(spansubtot_Savdata) == 0
      ? ""
      : fmtCurrency(spansubtot_Savdata, 0);

  document.getElementById("row23").style.display = "none";
  document.getElementById("row24").style.display = "none";
  document.getElementById("row25").style.display = "none";
  document.getElementById("row26").style.display = "none";
  document.getElementById("subtotal_Other").style.display = "none";
  document.getElementById("subtotal_Other_1").innerHTML =
    parseFloat(spansubtot_Otherdata) == 0
      ? ""
      : fmtCurrency(spansubtot_Otherdata, 0);
  if (parseFloat(spansubtot_Othbendata) == 0) {
    document.getElementById("tbl_Othbenhead").style.display = "none";
  }
  if (parseFloat(spanOthben1data) == 0) {
    document.getElementById("row27").style.display = "none";
  } else {
    document.getElementById("spanOthben1").innerHTML =
      parseFloat(spanOthben1data) == 0 ? "" : fmtCurrency(spanOthben1data, 0);
  }
  if (parseFloat(spanOthben2data) == 0) {
    document.getElementById("row28").style.display = "none";
  } else {
    document.getElementById("spanOthben2").innerHTML =
      parseFloat(spanOthben2data) == 0 ? "" : fmtCurrency(spanOthben2data, 0);
  }
  if (parseFloat(spanOthben3data) == 0) {
    document.getElementById("row29").style.display = "none";
  } else {
    document.getElementById("spanOthben3").innerHTML =
      parseFloat(spanOthben3data) == 0 ? "" : fmtCurrency(spanOthben3data, 0);
  }
  document.getElementById("row30").style.display = "none";
  document.getElementById("subtotal_Othben").style.display = "none";
  document.getElementById("subtotal_Othben_1").innerHTML =
    parseFloat(spansubtot_Othbendata) == 0
      ? ""
      : fmtCurrency(spansubtot_Othbendata, 0);

  document.getElementById("row31").style.display = "none";
  document.getElementById("row32").style.display = "none";
  document.getElementById("row33").style.display = "none";
  document.getElementById("row34").style.display = "none";
  document.getElementById("row35").style.display = "none";
  document.getElementById("row36").style.display = "none";
  document.getElementById("row37").style.display = "none";
  document.getElementById("row38").style.display = "none";
  document.getElementById("row39").style.display = "none";
  document.getElementById("subtotal_Reserve").style.display = "none";
  document.getElementById("subtotal_Reserve_1").innerHTML =
    parseFloat(spansubtot_Reservedata) == 0
      ? ""
      : fmtCurrency(spansubtot_Reservedata, 0);
  if (parseFloat(spansubtot_Govdata) == 0) {
    document.getElementById("tbl_Govhead").style.display = "none";
  }
  document.getElementById("row40").style.display = "none";
  document.getElementById("row41").style.display = "none";
  document.getElementById("row42").style.display = "none";
  document.getElementById("row43").style.display = "none";
  document.getElementById("subtotal_Gov").style.display = "none";
  document.getElementById("subtotal_Gov_1").innerHTML =
    parseFloat(spansubtot_Govdata) == 0
      ? ""
      : fmtCurrency(spansubtot_Govdata, 0);
  document.getElementById("spantot_Rewards_2").innerHTML =
    parseFloat(spantot_Rewardsdata) == 0
      ? ""
      : fmtCurrency(spantot_Rewardsdata /*+robOtherben*/, 0);
}
function setFields3() {
  console.log("fields3");

  var spaneeCore1data = document.getElementById("eeCore1").innerHTML;
  var spanerCore1data = document.getElementById("erCore1").innerHTML;
  var spaneeCore2data = document.getElementById("eeCore2").innerHTML;
  var spanerCore2data = document.getElementById("erCore2").innerHTML;
  var spaneeCore3data = document.getElementById("eeCore3").innerHTML;
  var spanerCore3data = document.getElementById("erCore3").innerHTML;
  var spaneeCore4data = document.getElementById("eeCore4").innerHTML;
  var spanerCore4data = document.getElementById("erCore4").innerHTML;
  var spaneeCore5data = 0;
  var spanerCore5data = document.getElementById("erCore5").innerHTML;
  var spansubtot_eeCoredata =
    document.getElementById("subtot_eeCore").innerHTML;
  var spansubtot_erCoredata =
    document.getElementById("subtot_erCore").innerHTML;

  var spaneeRetPlan1data = document.getElementById("eeRetPlan1").innerHTML;
  var spanerRetPlan1data = document.getElementById("erRetPlan1").innerHTML;
  var spaneeRetPlan2data = document.getElementById("eeRetPlan2").innerHTML;
  var spanerRetPlan2data = document.getElementById("erRetPlan2").innerHTML;
  var spaneeRetPlan3data = document.getElementById("eeRetPlan3").innerHTML;
  var spanerRetPlan3data = document.getElementById("erRetPlan3").innerHTML;
  var spaneeRetPlan4data = document.getElementById("eeRetPlan4").innerHTML;
  var spanerRetPlan4data = document.getElementById("erRetPlan4").innerHTML;
  var spansubtot_eeRetPlandata =
    document.getElementById("subtot_eeRetPlan").innerHTML;
  var spansubtot_erRetPlandata =
    document.getElementById("subtot_erRetPlan").innerHTML;

  var spaneeReserve1data = document.getElementById("eeReserve1").innerHTML;
  var spanerReserve1data = document.getElementById("erReserve1").innerHTML;
  var spansubtot_eeReservedata =
    document.getElementById("subtot_eeReserve").innerHTML;
  var spansubtot_erReservedata =
    document.getElementById("subtot_erReserve").innerHTML;

  var spaneeSavPlan1data = document.getElementById("eeSavPlan1").innerHTML;
  var spanerSavPlan1data = document.getElementById("erSavPlan1").innerHTML;
  var spaneeSavPlan2data = document.getElementById("eeSavPlan2").innerHTML;
  var spanerSavPlan2data = document.getElementById("erSavPlan2").innerHTML;
  var spaneeSavPlan3data = document.getElementById("eeSavPlan3").innerHTML;
  var spanerSavPlan3data = document.getElementById("erSavPlan3").innerHTML;
  var spaneeSavPlan4data = document.getElementById("eeSavPlan4").innerHTML;
  var spanerSavPlan4data = document.getElementById("erSavPlan4").innerHTML;
  var spaneeSavPlan5data = document.getElementById("eeSavPlan5").innerHTML;
  var spanerSavPlan5data = document.getElementById("erSavPlan5").innerHTML;
  var spaneeSavPlan6data = document.getElementById("eeSavPlan6").innerHTML;
  var spanerSavPlan6data = document.getElementById("erSavPlan6").innerHTML;
  var spansubtot_eeSavPlandata =
    document.getElementById("subtot_eeSavPlan").innerHTML;
  var spansubtot_erSavPlandata =
    document.getElementById("subtot_erSavPlan").innerHTML;

  var spansubtot_eeCashdata =
    document.getElementById("subtot_eeCash").innerHTML;
  var spansubtot_erCashdata =
    document.getElementById("subtot_erCash").innerHTML;

  var spansubtot_eeGovBendata =
    document.getElementById("subtot_eeGovBen").innerHTML;
  var spansubtot_erGovBendata =
    document.getElementById("subtot_erGovBen").innerHTML;
  var spantot_eeCostdata = document.getElementById("tot_eeCost").innerHTML;
  var spantot_erCostdata = document.getElementById("tot_erCost").innerHTML;

  var spaneeSavPlan7 = document.getElementById("eeSavPlan7").innerHTML;
  var spanerCash1 = document.getElementById("erCash1").innerHTML;

  if (parseFloat(spaneeSavPlan7) > 0) {
    document.getElementById("tbl_TFSAhead").style.display = "";
    //document.getElementById("tbl_TFSAPlan").style.display='';
    document.getElementById("subtotal_TFSA_1").innerHTML =
      parseFloat(spaneeSavPlan7) == 0 ? "" : fmtCurrency(spaneeSavPlan7, 0);
  } else {
    document.getElementById("tbl_TFSAhead").style.display = "none";
    //document.getElementById("tbl_TFSAPlan").style.display='none';
  }
  if (spanerCash1 > 0) {
    //document.getElementById('row70').style.display='';
    //document.getElementById("taxableCash2").innerHTML = fmtCurrency(spanerCash1, 0);
  } else {
    //  document.getElementById('row70').style.display='none';
  }

  if (
    parseFloat(spansubtot_eeCoredata) + parseFloat(spansubtot_erCoredata) ==
    0
  ) {
    document.getElementById("tbl_Corehead").style.display = "none";
  }
  if (parseFloat(spaneeCore1data) == 0 && parseFloat(spanerCore1data) == 0) {
    document.getElementById("row45").style.display = "none";
  } else {
    document.getElementById("spaneeCore1").innerHTML =
      parseFloat(spaneeCore1data) == 0 ? "" : fmtCurrency(spaneeCore1data, 0);
    document.getElementById("spanerCore1").innerHTML =
      parseFloat(spanerCore1data) == 0 ? "" : fmtCurrency(spanerCore1data, 0);
  }
  if (parseFloat(spaneeCore2data) == 0 && parseFloat(spanerCore2data) == 0) {
    document.getElementById("row46").style.display = "none";
  } else {
    document.getElementById("spaneeCore2").innerHTML =
      parseFloat(spaneeCore2data) == 0 ? "" : fmtCurrency(spaneeCore2data, 0);
    document.getElementById("spanerCore2").innerHTML =
      parseFloat(spanerCore2data) == 0 ? "" : fmtCurrency(spanerCore2data, 0);
  }
  if (parseFloat(spaneeCore3data) == 0 && parseFloat(spanerCore3data) == 0) {
    document.getElementById("row47").style.display = "none";
  } else {
    document.getElementById("spaneeCore3").innerHTML =
      parseFloat(spaneeCore3data) == 0 ? "" : fmtCurrency(spaneeCore3data, 0);
    document.getElementById("spanerCore3").innerHTML =
      parseFloat(spanerCore3data) == 0 ? "" : fmtCurrency(spanerCore3data, 0);
  }
  if (parseFloat(spaneeCore4data) == 0 && parseFloat(spanerCore4data) == 0) {
    document.getElementById("row48").style.display = "none";
  } else {
    document.getElementById("spaneeCore4").innerHTML =
      parseFloat(spaneeCore4data) == 0 ? "" : fmtCurrency(spaneeCore4data, 0);
    document.getElementById("spanerCore4").innerHTML =
      parseFloat(spanerCore4data) == 0 ? "" : fmtCurrency(spanerCore4data, 0);
  }
  if (!test) {
    if (parseFloat(spaneeCore5data) == 0 && parseFloat(spanerCore5data) == 0) {
      document.getElementById("row48a").style.display = "none";
    } else {
      document.getElementById("spaneeCore5").innerHTML =
        parseFloat(spaneeCore5data) == 0 ? "" : fmtCurrency(spaneeCore5data, 0);
      document.getElementById("spanerCore5").innerHTML =
        parseFloat(spanerCore5data) == 0 ? "" : fmtCurrency(spanerCore5data, 0);
    }
  } else {
    document.getElementById("row48a").style.display = "none";
  }
  document.getElementById("subtotal_Core").style.display = "none";
  document.getElementById("subtotal_Core_1").innerHTML =
    parseFloat(spansubtot_eeCoredata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeCoredata, 0);
  document.getElementById("subtotal_Core_2").innerHTML =
    parseFloat(spansubtot_erCoredata) == 0
      ? ""
      : fmtCurrency(spansubtot_erCoredata, 0);
  if (
    parseFloat(spansubtot_eeRetPlandata) +
      parseFloat(spansubtot_erRetPlandata) ==
    0
  ) {
    document.getElementById("tbl_RetPlanhead").style.display = "none";
  }
  if (
    parseFloat(spaneeRetPlan1data) == 0 &&
    parseFloat(spanerRetPlan1data) == 0
  ) {
    document.getElementById("row49").style.display = "none";
  } else {
    document.getElementById("spaneeRetPlan1").innerHTML =
      parseFloat(spaneeRetPlan1data) == 0
        ? ""
        : fmtCurrency(spaneeRetPlan1data, 0);
    document.getElementById("spanerRetPlan1").innerHTML =
      parseFloat(spanerRetPlan1data) == 0
        ? ""
        : fmtCurrency(spanerRetPlan1data, 0);
  }
  if (
    parseFloat(spaneeRetPlan2data) == 0 &&
    parseFloat(spanerRetPlan2data) == 0
  ) {
    document.getElementById("row50").style.display = "none";
  } else {
    document.getElementById("spaneeRetPlan2").innerHTML =
      parseFloat(spaneeRetPlan2data) == 0
        ? ""
        : fmtCurrency(spaneeRetPlan2data, 0);
    document.getElementById("spanerRetPlan2").innerHTML =
      parseFloat(spanerRetPlan2data) == 0
        ? ""
        : fmtCurrency(spanerRetPlan2data, 0);
  }
  if (
    parseFloat(spaneeRetPlan3data) == 0 &&
    parseFloat(spanerRetPlan3data) == 0
  ) {
    document.getElementById("row51").style.display = "none";
  } else {
    document.getElementById("spaneeRetPlan3").innerHTML =
      parseFloat(spaneeRetPlan3data) == 0
        ? ""
        : fmtCurrency(spaneeRetPlan3data, 0);
    document.getElementById("spanerRetPlan3").innerHTML =
      parseFloat(spanerRetPlan3data) == 0
        ? ""
        : fmtCurrency(spanerRetPlan3data, 0);
  }
  if (
    parseFloat(spaneeRetPlan4data) == 0 &&
    parseFloat(spanerRetPlan4data) == 0
  ) {
    document.getElementById("row52").style.display = "none";
  } else {
    document.getElementById("spaneeRetPlan4").innerHTML =
      parseFloat(spaneeRetPlan4data) == 0
        ? ""
        : fmtCurrency(spaneeRetPlan4data, 0);
    document.getElementById("spanerRetPlan4").innerHTML =
      parseFloat(spanerRetPlan4data) == 0
        ? ""
        : fmtCurrency(spanerRetPlan4data, 0);
  }
  document.getElementById("subtotal_RetPlan").style.display = "none";
  document.getElementById("subtotal_RetPlan_1").innerHTML =
    parseFloat(spansubtot_eeRetPlandata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeRetPlandata, 0);
  document.getElementById("subtotal_RetPlan_2").innerHTML =
    parseFloat(spansubtot_erRetPlandata) == 0
      ? ""
      : fmtCurrency(spansubtot_erRetPlandata, 0);
  if (!test) {
    if (
      parseFloat(spansubtot_eeReservedata) +
        parseFloat(spansubtot_erReservedata) ==
      0
    ) {
      document.getElementById("tbl_Reservehead").style.display = "none";
    }
  }
  if (
    parseFloat(spaneeReserve1data) == 0 &&
    parseFloat(spanerReserve1data) == 0
  ) {
    document.getElementById("row53").style.display = "none";
  } else {
    document.getElementById("spaneeReserve1").innerHTML =
      parseFloat(spaneeReserve1data) == 0
        ? ""
        : fmtCurrency(spaneeReserve1data, 0);
    document.getElementById("spanerReserve1").innerHTML =
      parseFloat(spanerReserve1data) == 0
        ? ""
        : fmtCurrency(spanerReserve1data, 0);
  }
  document.getElementById("subtotal_Reserve").style.display = "none";
  document.getElementById("subtotal_Reserve_1").innerHTML =
    parseFloat(spansubtot_eeReservedata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeReservedata, 0);
  document.getElementById("subtotal_Reserve_2").innerHTML =
    parseFloat(spansubtot_erReservedata) == 0
      ? ""
      : fmtCurrency(spansubtot_erReservedata, 0);
  if (
    parseFloat(spansubtot_eeSavPlandata) +
      parseFloat(spansubtot_erSavPlandata) ==
    0
  ) {
    document.getElementById("tbl_SavPlanhead").style.display = "none";
  }
  if (
    parseFloat(spaneeSavPlan1data) == 0 &&
    parseFloat(spanerSavPlan1data) == 0
  ) {
    document.getElementById("row54").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan1").innerHTML =
      parseFloat(spaneeSavPlan1data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan1data, 0);
    document.getElementById("spanerSavPlan1").innerHTML =
      parseFloat(spanerSavPlan1data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan1data, 0);
  }
  if (
    parseFloat(spaneeSavPlan2data) == 0 &&
    parseFloat(spanerSavPlan2data) == 0
  ) {
    document.getElementById("row55").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan2").innerHTML =
      parseFloat(spaneeSavPlan2data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan2data, 0);
    document.getElementById("spanerSavPlan2").innerHTML =
      parseFloat(spanerSavPlan2data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan2data, 0);
  }
  if (
    parseFloat(spaneeSavPlan3data) == 0 &&
    parseFloat(spanerSavPlan3data) == 0
  ) {
    document.getElementById("row57").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan3").innerHTML =
      parseFloat(spaneeSavPlan3data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan3data, 0);
    document.getElementById("spanerSavPlan3").innerHTML =
      parseFloat(spanerSavPlan3data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan3data, 0);
  }
  if (
    parseFloat(spaneeSavPlan4data) == 0 &&
    parseFloat(spanerSavPlan4data) == 0
  ) {
    document.getElementById("row58").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan4").innerHTML =
      parseFloat(spaneeSavPlan4data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan4data, 0);
    document.getElementById("spanerSavPlan4").innerHTML =
      parseFloat(spanerSavPlan4data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan4data, 0);
  }
  if (
    parseFloat(spaneeSavPlan5data) == 0 &&
    parseFloat(spanerSavPlan5data) == 0
  ) {
    document.getElementById("row59").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan5").innerHTML =
      parseFloat(spaneeSavPlan5data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan5data, 0);
    document.getElementById("spanerSavPlan5").innerHTML =
      parseFloat(spanerSavPlan5data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan5data, 0);
  }
  if (
    parseFloat(spaneeSavPlan6data) == 0 &&
    parseFloat(spanerSavPlan6data) == 0
  ) {
    document.getElementById("row60").style.display = "none";
  } else {
    document.getElementById("spaneeSavPlan6").innerHTML =
      parseFloat(spaneeSavPlan6data) == 0
        ? ""
        : fmtCurrency(spaneeSavPlan6data, 0);
    document.getElementById("spanerSavPlan6").innerHTML =
      parseFloat(spanerSavPlan6data) == 0
        ? ""
        : fmtCurrency(spanerSavPlan6data, 0);
  }
  document.getElementById("subtotal_SavPlan").style.display = "none";
  document.getElementById("subtotal_SavPlan_1").innerHTML =
    parseFloat(spansubtot_eeSavPlandata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeSavPlandata, 0);
  document.getElementById("subtotal_SavPlan_2").innerHTML =
    parseFloat(spansubtot_erSavPlandata) == 0
      ? ""
      : fmtCurrency(spansubtot_erSavPlandata, 0);
  if (
    parseFloat(spansubtot_eeCashdata) + parseFloat(spansubtot_erCashdata) ==
    0
  ) {
    document.getElementById("tbl_Cashhead").style.display = "none";
  }
  document.getElementById("row61").style.display = "none";
  document.getElementById("subtotal_Cash").style.display = "none";
  document.getElementById("subtotal_Cash_1").innerHTML =
    parseFloat(spansubtot_eeCashdata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeCashdata, 0);
  document.getElementById("subtotal_Cash_2").innerHTML =
    parseFloat(spansubtot_erCashdata) == 0
      ? ""
      : fmtCurrency(spansubtot_erCashdata, 0);
  if (
    parseFloat(spansubtot_eeGovBendata) + parseFloat(spansubtot_erGovBendata) ==
    0
  ) {
    document.getElementById("tbl_GovBenhead").style.display = "none";
  }
  document.getElementById("row62").style.display = "none";
  document.getElementById("row63").style.display = "none";
  document.getElementById("row64").style.display = "none";
  document.getElementById("row65").style.display = "none";
  document.getElementById("row66").style.display = "none";
  document.getElementById("subtotal_GovBen").style.display = "none";
  document.getElementById("subtotal_GovBen_1").innerHTML =
    parseFloat(spansubtot_eeGovBendata) == 0
      ? ""
      : fmtCurrency(spansubtot_eeGovBendata, 0);
  document.getElementById("subtotal_GovBen_2").innerHTML =
    parseFloat(spansubtot_erGovBendata) == 0
      ? ""
      : fmtCurrency(spansubtot_erGovBendata, 0);
  document.getElementById("spantot_eeCost").innerHTML =
    parseFloat(spantot_eeCostdata) == 0
      ? ""
      : fmtCurrency(spantot_eeCostdata, 0);
  document.getElementById("spantot_erCost").innerHTML =
    parseFloat(spantot_erCostdata) == 0
      ? ""
      : fmtCurrency(spantot_erCostdata, 0);

  //if(parseFloat(spaneeRetPlan4data)+parseFloat(spanerRetPlan4data)+parseFloat(spaneeRetPlan5data)+parseFloat(spanerRetPlan5data)+parseFloat(spaneeRetPlan6data)+parseFloat(spanerRetPlan6data)==0){document.getElementById('row46').style.display='none';}if(parseFloat(spaneeRetPlan7data)+parseFloat(spanerRetPlan7data)+parseFloat(spaneeRetPlan8data)+parseFloat(spanerRetPlan8data)+parseFloat(spaneeRetPlan9data)+parseFloat(spanerRetPlan9data)==0){document.getElementById('row50').style.display='none';}if(parseFloat(spaneeRetPlan10data)+parseFloat(spanerRetPlan10data)+parseFloat(spaneeRetPlan11data)+parseFloat(spanerRetPlan11data)+parseFloat(spaneeRetPlan12data)+parseFloat(spanerRetPlan12data)==0){document.getElementById('row54').style.display='none';}
}
