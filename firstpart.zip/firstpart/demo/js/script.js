$(document).ready(function(){
	$('.hamburger').click(function(){
		$('header nav').addClass('open');
	});
	$('.close-button').click(function(){
		$('header nav').removeClass('open');
	});
	
});
