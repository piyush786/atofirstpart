function RedirectOnCancel() {
    window.location = 'https://' + window.location.host + '/take-survey.html';
    return false;
}

function ConfirmOnSubmit(item) {
    //if (confirm(item) == true)
        alert(item);
        return true;
//    else
//        return false;
}

function ShowValue(form) {
    var listOfObjects = [];
    var UserSecurityInfo = null;
  //  debugger;

    //FeedbackValidator();

    //validator check to show msg for selecting subject for feedback
    var ddlfeedback_subject = $("[id^=feedbacksubject_]");    // $('#feedbacksubject');

    if (ddlfeedback_subject != null && ddlfeedback_subject.length > 0)    
    {
        var selectedopt = $(ddlfeedback_subject).val();  //get seleted option '#feedbacksubject_38_0'
        var validate_subject = document.getElementById('validate_subject'); //asterik
        var validate_comments = document.getElementById('validate_comments'); //warning msg
        var feedbackComments = $('*[id^="feedback_textlong_"]');

        if ($(feedbackComments).val().trim().length > 0) {
            if (selectedopt.indexOf('-1') > -1) {
                validate_subject.style.display = "inline-block";
                validate_comments.style.display = "block";
                return false;
            }
            else {
                var result = selectedopt.toString().split("_", 2)
                QuestionId = result[0];
                FeedbackOptionId = result[1];
                validate_subject.style.display = "none";
               validate_comments.style.display = "none";
            }
        }
    }

    $('*').each(
                    function (index) {
                        var input = $(this);

                        if (input.attr('type') == 'radio' || input.attr('type') == 'checkbox' || input.attr('type') == 'text' || input.attr('type') == 'select' || input.attr('type') == 'multiple') {

                            var QuestionId = 0;
                            var OptionId = 0
                            var OptionAnswer = "";
                            var id = input.attr('id'); // new change for feedback control

                            //Textbox
                            if (input.attr('type') == 'text' && id.indexOf('feedback_textlong') < 0) {
                                // debugger;
                                var cntrlId = input.attr('id')
                                var txtId = document.getElementById(cntrlId);
                                var result = cntrlId.toString().split("_", 3)

                                OptionAnswer = document.getElementById(cntrlId).value.toString().trim();
                                QuestionId = result[1];
                                OptionId = result[2];

                                //if (OptionAnswer != "") {
                                var a = { "QuestionId": QuestionId.toString(), "OptionId": OptionId.toString(), "OptionAnswer": OptionAnswer.toString() };
                                listOfObjects.push(a);
                                //}
                            }

                            //CheckBox
                            if (input.attr('type') == 'checkbox') {
                                // debugger;
                                var cntrlId = input.attr('id')
                                var chkBoxId = document.getElementById(cntrlId);

                                if (chkBoxId.checked) {
                                    //debugger;
                                    var result = cntrlId.toString().split("_", 3)

                                    QuestionId = result[1];
                                    OptionId = result[2];
                                    OptionAnswer = document.getElementById(cntrlId).nextSibling.nodeValue;

                                    var a = { "QuestionId": QuestionId.toString(), "OptionId": OptionId.toString(), "OptionAnswer": OptionAnswer.toString() };
                                    listOfObjects.push(a);
                                }
                            }

                            //Radio Button
                            if (input.attr('type') == 'radio') {
                                //debugger;
                                var cntrlId = input.attr('id')
                                var radioId = document.getElementById(cntrlId);

                                if (radioId.checked) {
                                    //debugger;
                                    var result = cntrlId.toString().split("_", 3)
                                    QuestionId = result[1];
                                    OptionId = result[2];
                                    
                                  //  OptionAnswer = document.getElementById(cntrlId).nextSibling.nodeValue;
                                    OptionAnswer = document.getElementById(cntrlId).nextSibling.textContent;
                                      
                                    var a = { "QuestionId": QuestionId.toString(), "OptionId": OptionId.toString(), "OptionAnswer": OptionAnswer.toString() };
                                    listOfObjects.push(a);
                                }
                            }

                            //Drop Down List & feedback control Comments
                            if (input.attr('type') == 'select') {
                                // debugger;
                                var cntrlId = input.attr('id')
                                var varOption = document.getElementById(cntrlId);
                                var OptionId = 0;

                                var result = cntrlId.toString().split("_", 3)
                                QuestionId = result[1];
                                OptionId = result[2];

                                if (OptionId == 0) {
                                    OptionId = varOption.options.value;
                                }

                                //for feedback control comments
                                var flagsave = 0;
                                var feedbackComments = $('*[id^="feedback_textlong_"]');

                                if (feedbackComments == null) {
                                    OptionAnswer = varOption.options[varOption.selectedIndex].text;
                                    flagsave = 1;
                                   }
                                else if ($(feedbackComments).val().trim().length > 0) {
                                    OptionAnswer = feedbackComments.val();
                                    OptionId = FeedbackOptionId;
                                    flagsave = 1;
                                   }
                                //save in case feedback ctrl or dropdown ctrl has data
                                if (flagsave == 1) {
                                   var a = { "QuestionId": QuestionId.toString(), "OptionId": OptionId.toString(), "OptionAnswer": OptionAnswer.toString() };
                                   listOfObjects.push(a);
                                }
                            }


                            //List Box 
                            if (input.attr('type') == 'multiple') {
                                //debugger;
                                var cntrlId = input.attr('id')
                                var lstBox = document.getElementById(cntrlId);

                                var result = cntrlId.toString().split("_", 3)
                                QuestionId = result[1];
                                OptionId = result[2];

                                for (var i = 0; i < lstBox.options.length; i++) {
                                    if (lstBox.options[i].selected == true) {
                                        //debugger;
                                        if (OptionId == 0) {
                                            OptionId = lstBox.options[i].value;
                                        }
                                        OptionAnswer = lstBox.options[i].innerText;

                                        var a = { "QuestionId": QuestionId.toString(), "OptionId": OptionId.toString(), "OptionAnswer": OptionAnswer.toString() };
                                        listOfObjects.push(a);
                                        OptionId = result[2];
                                    }
                                }
                            }
                            //End of Each section
                        }
                    }
           ) // end of each fundciton

    if (listOfObjects.length > 0) {        

        if (ConfirmOnSubmit(form)) {
          //  console.log(listOfObjects);
            SaveSurveyAnswerModel(listOfObjects, onSuccess, onError);
           // alert(listOfObjects);

            

        }
        else {
            RedirectOnCancel();
        }
    }
    else {
        onError('There is no item to save');
    }
}

function onSuccess(msg) {
    window.location.href = 'take-survey.html';    
    console.log(msg);
    //console.log(listOfObjects);
}

function onError(msg) {
    window.location.href = 'take-survey.html';
    console.log("Error");
}


function FeedbackValidator() {
    //validator check to show msg for selecting subject for feedback
    var ddlfeedback_subject = $("[id^=feedbacksubject_]");    // $('#feedbacksubject');

    if (ddlfeedback_subject != null) {

        var selectedopt = $(ddlfeedback_subject).val();  //get seleted option '#feedbacksubject_38_0'
        var validate_subject = document.getElementById('validate_subject'); //asterik
        var validate_comments = document.getElementById('validate_comments'); //warning msg
        var feedbackComments = $('*[id^="feedback_textlong_"]');

        if (!$(this).text().trim().length)

            if (feedbackComments != null) {
                alert($(feedbackComments).val().trim().length);

                if ($(feedbackComments).val().trim().length > 0) {
                    alert('length > 0');
                    if (selectedopt.indexOf('-1') > -1) {
                        alert(selectedopt + '');
                        //if (validate_subject != null && validate_comments != null) {
                        validate_subject.style.display = "inline-block";
                        validate_comments.style.display = "block";
                        //}
                        return false;
                    }
                    else {
                        // if (validate_subject != null && validate_comments != null) {
                        var result = selectedopt.toString().split("_", 2)
                        QuestionId = result[0];
                        FeedbackOptionId = result[1];

                        validate_subject.style.display = "none";
                        validate_comments.style.display = "none";
                        // }
                    }
                }
                else {
                    alert('returning true');
                    return true;
                }
            }
    }
}