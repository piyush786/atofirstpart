var environmentString = location.hostname;
var webApiRootUrl, environment;

var isRecruit = "";
var weAreComingFromAddNewScreen = "";

var langCode = {
  eng: "en",
  french: "fr",
};
var selectedUICultureCode = {
  eng: "en-US",
  french: "fr-CA",
};
var sessionKey = {
  LangCode: "langCode",
  Token: "token",
  RefreshToken: "refreshToken",
  ScenarioIsSaved: "scenarioIsSaved",
};

var selectedUICulture;

/********************* Reference **********************/

if (environmentString.indexOf("qa") >= 0) {
  webApiRootUrl = "https://ceservice.qa.alight.com/AonCanada/api";
  //        "https://cawiqapp0030.hewitt.com:8088/AonCanada/api";
  environment = "qa";
} else if (environmentString.indexOf("qc") >= 0) {
  webApiRootUrl = "https://ceservice.qc.alight.com/AonCanada/api";
  environment = "qc";
} else if (environmentString.indexOf("127.0.0.1") >= 0) {
  webApiRootUrl = "http://localhost:5055/api";
  //"https://ceservice.qa.alight.com/AonCanada/api";
  // "https://cetadmin.qa.alight.com/api/Bayer";

  //webApiRootUrl =  "http://localhost:5055/api";
  environment = "localhost";
} else if (environmentString.indexOf("localhost") >= 0) {
  webApiRootUrl = "http://localhost:5055/api";
  environment = "localhost";
} else {
  webApiRootUrl = "https://ceservice.alight.com/AonCanada/api";
  environment = "production";
}

/************************************Common JS Starts*****************************************/

function HRPIndividualizedStamenetDownload() {
  var token = sessionStorage.getItem(sessionKey.Token);

  fetch(webApiRootUrl + "/Login/GetIndividualizedStatement", {
    method: "GET",
    headers: {
      Authorization: "Bearer " + token,
      responseType: "blob",
    },
  })
    .then((response) => {
      if (response.status == 404) {
        alert(
          "Your Individualized statement is not available. Please connect with administrator.",
        );
      } else if (response.status == 401) {
        //alert("Unauthorized");
        window.location.href = "session-timeout.html";
      } else {
        response.blob().then((blob) => {
          console.log(blob);
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "IndividualizedStatement.pdf";
          a.click();
          URL.revokeObjectURL(url);
          RefreshToken(false);
        });
      }
    })
    .catch((error) => {
      console.error(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    });
}

function SetCommonVar() {
  if (document.getElementById("BusUnit")) {
    //console.log("BusUnit")
    isRecruit = document.getElementById("BusUnit").innerHTML == "XXX" ? 1 : 0;
    //console.log("isRecruit: " + isRecruit)
  } else {
    isRecruit = location.href.indexOf("params=") >= 0 ? 1 : 0;
  }

  //2022
  if ($("#EmpID").html() == "99999999" || $("#EmpID").html() == "88888888") {
    isRecruit = 1;
  }

  if (
    (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
      !document.getElementById("EmpID")) ||
    location.search.indexOf("params=") >= 0
  ) {
    weAreComingFromAddNewScreen = true;
  } else {
    weAreComingFromAddNewScreen = false;
  }
  // console.log("weAreComingFromAddNewScreen: " + weAreComingFromAddNewScreen)

  existingSS = location.search.indexOf("ssId") >= 0 ? true : false;
  newSS = location.search.indexOf("params=") >= 0 ? true : false;

  if (location.href.toLowerCase().indexOf("/print") < 0) {
    if (
      (location.search.indexOf("params=") >= 0 &&
        document.getElementById("pageID")) ||
      isRecruit == 1
    ) {
      console.log("common");
      if (document.getElementById("pageID")) {
        if (document.getElementById("pageID").value != "100") {
          if (weAreComingFromAddNewScreen == true) {
            qsparams = location.href.substring(
              location.href.indexOf("?params="),
              location.href.length,
            );

            ssid = qsparams.substring(
              qsparams.indexOf("=") + 1,
              qsparams.indexOf(";"),
            );
            document.getElementById("link1").href += qsparams;
            document.getElementById("link2").href += qsparams;
            document.getElementById("link3").href += qsparams;
            document.getElementById("link4").href += qsparams;
            document.getElementById("link5").href += qsparams;
            document.getElementById("link6").href += qsparams;
            document.getElementById("printLink").href =
              `javascript:window.open('print.html${encodeURIComponent(qsparams)}', '_blank')`;

            document.getElementById("returnToSS").href =
              ssid == 0
                ? "recruiting.html" + qsparams
                : "recruiting.html?ssId=" + ssid;
            document.getElementById("returnToSS").style.display = "";
            document.getElementById("saveSS").style.display = "";
            document.getElementById("lnkEngLang").style.display = "none";
            document.getElementById("lnkFRLang").style.display = "none";
          } else {
            document.getElementById("lnkEngLang").style.display = "none";
            document.getElementById("lnkFRLang").style.display = "none";
          }
          if (document.getElementById("pageID").value != 9) {
            document.getElementById(
              "link" + document.getElementById("pageID").value,
            ).style.color = "#db0011";
          }
        }
      }
    }
  }
}

function LogoutEmployee() {
  var token = sessionStorage.getItem(sessionKey.Token);
  var status = false;
  jQuery.ajax({
    type: "POST",
    headers: {
      Authorization: "Bearer " + token,
    },
    url: webApiRootUrl + "/Login/LogoutEmployee",
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      sessionStorage.clear();
      status = true;
    },
    error: function (error) {
      status = false;
      if ((error.status = 401)) {
        window.location.href = "session-timeout.html";
      } else {
        console.error(
          "state: " + error.state,
          "; Status:" + error.status,
          "; Response Text: " + error.responseText,
        );
      }
    },
  });
  return status;
}

function Logout(showMsg = false) {
  LogoutEmployee();
  if (showMsg) {
    $("#logoutMsg").show();
    $("#beforeLogoutMsg").hide();
  }
}

function GetSetLangFromURL() {
  const urlParam = new URLSearchParams(window.location.search);
  let lang = urlParam.get("lang");
  if (lang != null) {
    if (lang == "en") {
      sessionStorage.setItem(sessionKey.LangCode, langCode.eng);
    } else {
      sessionStorage.setItem(sessionKey.LangCode, langCode.french);
    }
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

function ChangeLang(element, changeWinOpenerLangCode = false) {
  console.log($(element).attr("lang"));
  var lang = $(element).attr("lang");
  if (lang == "E") {
    sessionStorage.setItem(sessionKey.LangCode, langCode.eng);
    selectedUICulture = selectedUICultureCode.eng;
  } else {
    sessionStorage.setItem(sessionKey.LangCode, langCode.french);
    selectedUICulture = selectedUICultureCode.french;
  }

  if (changeWinOpenerLangCode == true) {
    if (lang == "E") {
      window.opener.sessionStorage.langCode = langCode.eng;
      window.opener.selectedUICulture = selectedUICultureCode.eng;
    } else {
      window.opener.sessionStorage.langCode = langCode.french;
      window.opener.selectedUICulture = selectedUICultureCode.french;
    }
  }
  window.location.reload();
}

function IsTokenExpired(token) {
  const tokenPart = token.split(".");
  const payload = JSON.parse(atob(tokenPart[1]));
  const exp = new Date(payload.exp * 1000);
  const currentTime = Math.floor(Date.now() / 1000);
  console.log(payload.exp, "-", exp, "-", Date.now(), "-", currentTime);
  console.log("token expired", payload.exp < currentTime);
  return payload.exp < currentTime;
}

function GetServiceData() {
  console.log("called inside GetServiceData");
  var serviceData;
  var token = sessionStorage.getItem(sessionKey.Token);
  if (token != null && token != "") {
    if (IsTokenExpired(token)) {
      if (RefreshToken(false)) {
        token = sessionStorage.getItem(sessionKey.Token);
      }
    }
    jQuery.ajax({
      type: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
      url: webApiRootUrl + "/Login/GetEmpServiceData",
      data: {},
      contentType: "application/json; charset=utf-8",
      dataType: "text",
      cache: false,
      async: false,
      success: function (result) {
        console.log(result);
        serviceData = result;
        //if (serviceData != null) {
        //    RefreshToken(false);
        //}
      },
      error: function (error) {
        if ((error.status = 401)) {
          window.location.href = "session-timeout.html";
        } else {
          console.error(
            "state: " + error.state,
            "; Status:" + error.status,
            "; Response Text: " + error.responseText,
          );
        }
      },
    });
  } else {
    console.error("Empty token");
    window.location.href = "session-timeout.html";
  }
  $("#InputData_nwsdbd").html(serviceData);
  console.log("GetServiceData completed");
  return serviceData;
}

function RefreshToken(asyncFlag = false) {
  var IsTokenRefreshed = false;
  var accessToken = sessionStorage.getItem(sessionKey.Token);
  var refreshToken = sessionStorage.getItem(sessionKey.RefreshToken);
  console.log("refresh token called.");
  jQuery.ajax({
    type: "POST",
    url: webApiRootUrl + "/Login/RefreshToken",
    headers: {
      Authorization: "Bearer " + accessToken,
      refreshToken: refreshToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: asyncFlag,
    success: function (result) {
      //accessToken=newToken,refreshToken
      console.log(result);
      if (result.accessToken != null && result.refreshToken != null) {
        sessionStorage.setItem(sessionKey.Token, result.accessToken);
        sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);
        IsTokenRefreshed = true;
      } else {
        window.location.href = "session-timeout.html";
      }
    },
    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });

  return IsTokenRefreshed;
}

function SetVariable() {
  if (document.getElementById("BusUnit")) {
    //console.log("BusUnit")
    isRecruit = document.getElementById("BusUnit").innerHTML == "XXX" ? 1 : 0;
    //console.log("isRecruit: " + isRecruit)
  } else {
    isRecruit = location.href.indexOf("params=") >= 0 ? 1 : 0;
  }

  //2022
  if ($("#EmpID").html() == "99999999" || $("#EmpID").html() == "88888888") {
    isRecruit = 1;
  }
}

function ValidateInboundSSORequest() {
  var status = false;
  const queryString = window.location.search;
  console.log(queryString);
  const urlParams = new URLSearchParams(queryString);
  var requestToken = urlParams.get("request");
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Login/VerifyInboundSSO",
    data: {},
    headers: {
      "X-Host-Name": window.location.hostname,
      requestToken: requestToken,
    },
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      if (result != null) {
        console.log("HrpSSOResult " + result);
        if (result.loginToken != null) {
          sessionStorage.setItem(
            sessionKey.Token,
            result.loginToken.accessToken,
          );
          sessionStorage.setItem(
            sessionKey.RefreshToken,
            result.loginToken.refreshToken,
          );
          var lang = result.lang == "E" ? langCode.eng : langCode.french;
          sessionStorage.setItem(sessionKey.LangCode, lang);
          status = true;
        } else {
          console.error("ISSOResult result.logintoken is null");
        }
      } else {
        console.error("ISSOResult result is null");
      }
    },

    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });
  if (status == true) {
    window.location.href = "welcome.html";
  } else {
    $("#error").text("Connection error. Please contact your administrator.");
  }
}

/************************************common JS End*****************************************/

/************************************hrpsso.html JS Starts*****************************************/

function ValidateHRPSSORequest() {
  var status = false;
  const queryString = window.location.search;
  console.log(queryString);

  const urlParams = new URLSearchParams(queryString);
  var requestToken = urlParams.get("request");

  //alert("request Token " + requestToken);
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Login/VerifyHRPSSO",
    data: {},
    headers: {
      "X-Host-Name": window.location.hostname,
      requestToken: requestToken,
    },
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    async: false,
    success: function (result) {
      console.log(result);
      if (result != null) {
        console.log("HrpSSOResult " + result);
        if (result.loginToken != null) {
          sessionStorage.setItem(
            sessionKey.Token,
            result.loginToken.accessToken,
          );
          sessionStorage.setItem(
            sessionKey.RefreshToken,
            result.loginToken.refreshToken,
          );
          var lang = result.lang == "E" ? langCode.eng : langCode.french;
          sessionStorage.setItem(sessionKey.LangCode, lang);
          status = true;
        } else {
          console.error("HrpSSOResult result.logintoken is null");
        }
      } else {
        console.error("HrpSSOResult result is null");
      }
    },

    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });
  if (status == true) {
    window.location.href = "welcome.html";
  } else {
    //$("#error").text(GetResourceStringVal("Enrollment.LoginFromAdmin.Message"));
    $("#error").show();
  }
}

/************************************hrpsso.html JS end*****************************************/

/************************************print.html JS Start*****************************************/

function GetServiceDataForWindowOpener() {
  console.log("called inside GetServiceDataForWindowOpener");
  var serviceData;
  var token = window.opener.sessionStorage.token;
  if (token != null && token != "") {
    if (IsTokenExpired(token)) {
      if (RefreshTokenForWindowOpener()) {
        token = window.opener.sessionStorage.token;
      }
    }
    jQuery.ajax({
      type: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
      url: webApiRootUrl + "/Login/GetEmpServiceData",
      data: {},
      contentType: "application/json; charset=utf-8",
      dataType: "text",
      cache: false,
      async: false,
      success: function (result) {
        console.log(result);
        serviceData = result;
        if (serviceData != null) {
          RefreshTokenForWindowOpener();
        }
      },
      error: function (error) {
        if ((error.status = 401)) {
          window.location.href = "session-timeout.html";
        } else {
          console.error(
            "state: " + error.state,
            "; Status:" + error.status,
            "; Response Text: " + error.responseText,
          );
        }
      },
    });
  } else {
    console.error("Empty token");
    window.location.href = "session-timeout.html";
  }
  $("#InputData_nwsdbd").html(serviceData);
  console.log("GetServiceData completed");
  return serviceData;
}

function RefreshTokenForWindowOpener(asyncFlag = false) {
  var IsTokenRefreshed = false;
  var accessToken = window.opener.sessionStorage.token;
  var refreshToken = window.opener.sessionStorage.refreshToken;
  console.log("refresh token called.");
  jQuery.ajax({
    type: "POST",
    url: webApiRootUrl + "/Login/RefreshToken",
    headers: {
      Authorization: "Bearer " + accessToken,
      refreshToken: refreshToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: asyncFlag,
    success: function (result) {
      //accessToken=newToken,refreshToken
      console.log(result);
      if (result.accessToken != null && result.refreshToken != null) {
        window.opener.sessionStorage.token = result.accessToken;
        window.opener.sessionStorage.refreshToken = result.refreshToken;
        // sessionStorage.setItem(sessionKey.Token,result.accessToken);
        // sessionStorage.setItem(sessionKey.RefreshToken,result.refreshToken);
        IsTokenRefreshed = true;
      } else {
        window.location.href = "session-timeout.html";
      }
    },
    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });

  return IsTokenRefreshed;
}

function CheckPrintData() {
  if (
    (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
      !document.getElementById("EmpID")) ||
    location.search.indexOf("params=") >= 0 ||
    sessionStorage.getItem("data")
  ) {
    weAreComingFromAddNewScreen = true;
  } else {
    weAreComingFromAddNewScreen = false;
  }
  document.getElementById("nav").style.display = "none";
  //document.getElementById('footer').style.display = 'none';

  if (
    document.getElementById("EmpID").innerHTML == "99999999" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777"
  ) {
    document.getElementById("regtables").innerHTML = "";
    robSwitches();
    document.getElementById("estLabel").innerHTML =
      selectedUICulture == "fr-CA" ? "&nbsp;estimative" : "Estimated";
    //GetResourceStringVal(
    //    "CED.AonCanada.Rewards.estLabel"
    //);

    loadPageRecruiting();
    //document.getElementById("lifeworks").style.visibility = "hidden";
  } else if (document.getElementById("optGlance20") != null) {
    document.getElementById("recruitingtables").innerHTML = "";
    //document.getElementById("bluebox").style.border = "2px solid #0183a9";
    document.getElementById("article1").style.border = "1px solid #CCCCCC";
    //document.getElementById("recruitbanner").style.display = "none";
    //document.getElementById("spacer1").style.display = "none";
    //document.getElementById("spacer2").style.display = "none";
    //document.getElementById("center1").style.marginTop = "120px";
    //document.getElementById("article1").style.marginTop = "80px";

    if (isRecruit == 1) {
      robSwitches();
      document.getElementById("tagLine2").innerHTML =
        "Group insurance benefit costs shown are annualized values based on your elections, and employment information as of time of hire. All other values are annual estimates for the calendar year based on your elections and status.";
    }
    loadPage();
    if ($("#Glance9").text() == "0") {
      $("#shortterm").hide();
    }
  }

  if (selectedUICulture == "fr-CA") {
    $("#article8").css("height", "460px");
    $("#article8 h2.twoline").css("max-width", "66%");
    $("#article8 h2.twoline").css("margin-bottom", "2rem");
    if ($("#pageID").val() != "P") {
      $("#article11").css("margin-top", "-122px");
    }
    $("#article1 h2, #article3 h2").css("line-height", "18px");
    // $("article p.callout img").css("margin-top","-1rem")
    $("#article8 p.callout img").css("margin-top", "-2rem");
    $(
      "#article10 p.callout img,#article22 p.callout img,#article24 p.callout img",
    ).css("margin-top", "0rem");
  }

  //    eval(GetResourceStringVal("CED.AonCanada.Print.Pay65"));
}

function initCoverageTable() {
  // Guard: if data not yet loaded, do nothing
  if (
    !document.getElementById("optGlance4") ||
    (document.getElementById("optGlance4") || { innerHTML: "" }).innerHTML ===
      ""
  ) {
    return;
  }

  if (selectedUICulture != "fr-CA") {
    // ── Extended Health Coverage ──────────────────────────────────────
    var optG4 = $("#optGlance4").html();
    var comG4 = $("#comGlance4").html();
    if (comG4 == "") {
        $("#coveragetext1").html(
            "Your group benefits, retirement and savings elections are not displayed here as enrolment was not complete as of May 31, 2026. Visit <a href = 'http://manulife.ca/signin' target = '_blank'>manulife.ca/signin</a> and login or access the Plan Member site from <a href='https://upoint.aon.com/' target = '_blank'>UPoint</a> to review your up-to-date coverage elections.",
        );
      $(".coveragetable").hide();
      return;
      }else {
          $("#coveragetext1").html(
              "The group benefits coverage statement below is based on your elections, and employment information as of May 31, 2026. Updates to coverage made after May 31, 2026 are not reflected below. Visit <a href = 'http://manulife.ca/signin' target = '_blank'>manulife.ca/signin</a> and login or access the Plan Member site from <a href ='https://upoint.aon.com/' target = '_blank'>UPoint</a> to review your up-to-date coverage elections.",
          );
      }

    $("#ExtendedHealthCoverage td")
      .eq(1)
      .text($("#optGlance4").html().split("|")[0]);
    $("#ExtendedHealthCoverage td")
      .eq(2)
      .text($("#comGlance4").html().split("|")[0]);

    // ── Dental ───────────────────────────────────────────────────────
    $("#Dental td").eq(1).text($("#optGlance5").html().split("|")[0]);
    $("#Dental td").eq(2).text($("#comGlance5").html().split("|")[0]);

    // ── Long Term Disability Taxable ──────────────────────────────────
    $("#LongTermDisabilityTaxable td")
      .eq(1)
      .text($("#optGlance6").html().split("|")[0]);
    $("#LongTermDisabilityTaxable td")
      .eq(2)
      .text(fmtCurrency($("#comGlance6").html(), 0));

    // ── Long Term Disability Non-Taxable ──────────────────────────────
    $("#LongTermDisabilityNonTaxable td")
      .eq(1)
      .text($("#optGlance7").html().split("|")[0]);
    $("#LongTermDisabilityNonTaxable td")
      .eq(2)
      .text(fmtCurrency($("#comGlance7").html(), 0));

    // ── Life Insurance ────────────────────────────────────────────────
    $("#BasicLifeCovered").text(
      fmtCurrency(document.getElementById("comGlance9").innerHTML, 0),
    );

    if (document.getElementById("optGlance10").innerHTML.split(";")[0] != "0") {
      $("#OptionalEmployeeLife td").eq(1).text("Covered");
    } else {
      $("#OptionalEmployeeLife td").eq(1).text(" – ");
    }
    $("#OptionalEmployeeLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[0],
          0,
        ),
      );

    if (document.getElementById("optGlance10").innerHTML.split(";")[1] != "0") {
      $("#OptionalSpousalLife td").eq(1).text("Covered");
    } else {
      $("#OptionalSpousalLife td").eq(1).text(" – ");
    }
    $("#OptionalSpousalLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[1],
          0,
        ),
      );

    if (document.getElementById("optGlance10").innerHTML.split(";")[2] != "0") {
      $("#OptionalChildLife td").eq(1).text("Covered");
    } else {
      $("#OptionalChildLife td").eq(1).text(" – ");
    }
    $("#OptionalChildLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[2],
          0,
        ),
      );

    // ── AD&D ──────────────────────────────────────────────────────────
    $("#EmployeeCovered td")
      .eq(2)
      .text(fmtCurrency(document.getElementById("comGlance11").innerHTML, 0));

    if (document.getElementById("optGlance12").innerHTML.split(";")[0] != "0") {
      $("#OptionalEmployee td").eq(1).text("Covered");
    } else {
      $("#OptionalEmployee td").eq(1).text(" – ");
    }
    $("#OptionalEmployee td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[0],
          0,
        ),
      );

    if (document.getElementById("optGlance12").innerHTML.split(";")[1] != "0") {
      $("#OptionalSpousal td").eq(1).text("Covered");
    } else {
      $("#OptionalSpousal td").eq(1).text(" – ");
    }
    $("#OptionalSpousal td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[1],
          0,
        ),
      );

    console.log(document.getElementById("optGlance12").innerHTML);
    if (document.getElementById("optGlance12").innerHTML.split(";")[2] != "0") {
      $("#OptionalChild td").eq(1).text("Covered");
    } else {
      $("#OptionalChild td").eq(1).text(" – ");
    }
    $("#OptionalChild td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[2],
          0,
        ),
      );

    if (document.getElementById("optGlance12").innerHTML.split(";")[3] == "1") {
      $("#OptionalAD td").eq(1).text("Single");
    } else if (
      document.getElementById("optGlance12").innerHTML.split(";")[3] == "2"
    ) {
      $("#OptionalAD td").eq(1).text("Family");
    } else {
      $("#OptionalAD td").eq(1).text(" – ");
    }

    $("#OptionalAD td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[3],
          0,
        ),
      );

    // ── Critical Illness ──────────────────────────────────────────────

    if (document.getElementById("optGlance8").innerHTML.split(";")[0] != "0") {
      $("#EmployeeCriticalIllness td").eq(1).text("Covered");
    } else {
      $("#EmployeeCriticalIllness td").eq(1).text(" – ");
    }
    $("#EmployeeCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[0],
          0,
        ),
      );

    if (document.getElementById("optGlance8").innerHTML.split(";")[1] != "0") {
      $("#SpousalCriticalIllness td").eq(1).text("Covered");
    } else {
      $("#SpousalCriticalIllness td").eq(1).text(" – ");
    }
    $("#SpousalCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[1],
          0,
        ),
      );

    if (document.getElementById("optGlance8").innerHTML.split(";")[2] != "0") {
      $("#ChildrenCriticalIllness td").eq(1).text("Covered");
    } else {
      $("#ChildrenCriticalIllness td").eq(1).text(" – ");
    }
    $("#ChildrenCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[2],
          0,
        ),
      );

    // ── OGPEL ─────────────────────────────────────────────────────────
    if (document.getElementById("optGlance18").innerHTML != "0") {
      $("#OGPEL_Cov td").eq(1).text("Covered");
    } else {
      $("#OGPEL_Cov td").eq(1).text("Not Covered");
    }

    // ── DC Pension ────────────────────────────────────────────────────
    if (document.getElementById("Glance13").innerHTML != "1") {
      $("#DCPension td")
        .eq(2)
        .text(document.getElementById("Glance13").innerHTML + "%");
    }
    $("#penrow1 td")
      .eq(2)
      .text(
        document.getElementById("comGlance13").innerHTML.split(";")[0] + "%",
      );
    $("#penrow2 td")
      .eq(2)
      .text(
        document.getElementById("comGlance13").innerHTML.split(";")[1] + "%",
      );

    // ── RRSP ──────────────────────────────────────────────────────────
    $("#trVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[0] + "%",
      );
    $("#trOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[1] + "%",
      );
    $("#trRRSPVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[2] + "%",
      );
    $("#trRRSPOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[3] + "%",
      );

    // ── Company Share Save ────────────────────────────────────────────
    $("#CompanyShareVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance15").innerHTML.split(";")[0] + "%",
      );
    $("#CompanyShareOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance15").innerHTML.split(";")[1] + "%",
      );

    // ── Non-Registered Savings ────────────────────────────────────────
    $("#NonRegSavingsPlan_Optional td")
      .eq(2)
      .text(document.getElementById("comGlance16").innerHTML + "%");

    // ── TFSA ──────────────────────────────────────────────────────────
    $("#TFSA td")
      .eq(1)
      .text(
        document.getElementById("optGlance17").innerHTML == 1
          ? "Contributing"
          : "Not Contributing",
      );
    var comText =
      document.getElementById("comGlance17").innerHTML == "0"
        ? "n/a"
        : fmtCurrency(document.getElementById("comGlance17").innerHTML, 0) +
          "/pay";
    $("#TFSA td").eq(2).text(comText);

    // ── Hide zero rows ────────────────────────────────────────────────
    if (parseFloat($("#Glance6").html()) == 0 || $("#Glance6").html() == "") {
      $(".coveragetable tbody tr:nth-child(3)").hide();
    }
    if (parseFloat($("#Glance7").html()) == 0 || $("#Glance7").html() == "") {
      $(".coveragetable tbody tr:nth-child(4)").hide();
    }
    if (parseFloat($("#Glance8").html()) == 0 || $("#Glance8").html() == "") {
      $(".coveragetable tbody tr:nth-child(16)").hide();
      $(".coveragetable tbody tr:nth-child(17)").hide();
      $(".coveragetable tbody tr:nth-child(18)").hide();
      $(".coveragetable tbody tr:nth-child(19)").hide();
    }
    if (parseFloat($("#Glance9").html()) == 0 || $("#Glance9").html() == "") {
      $(".coveragetable tbody tr:nth-child(6)").hide();
    }
    if (parseFloat($("#Glance10").html()) == 0 || $("#Glance10").html() == "") {
      $(".coveragetable tbody tr:nth-child(5)").hide();
      $(".coveragetable tbody tr:nth-child(6)").hide();
      $(".coveragetable tbody tr:nth-child(7)").hide();
      $(".coveragetable tbody tr:nth-child(8)").hide();
      $(".coveragetable tbody tr:nth-child(9)").hide();
    }
    if (parseFloat($("#Glance11").html()) == 0 || $("#Glance11").html() == "") {
      $(".coveragetable tbody tr:nth-child(11)").hide();
    }
    var tmp = $("#Glance12").html().split(";");
    if (parseInt(tmp[0]) == 0) {
      $(".coveragetable tbody tr:nth-child(12)").hide();
    }
    if (parseInt(tmp[1]) == 0) {
      $(".coveragetable tbody tr:nth-child(13)").hide();
    }
    if (parseInt(tmp[2]) == 0) {
      $(".coveragetable tbody tr:nth-child(14)").hide();
    }
    if (parseInt(tmp[3]) == 0) {
      $(".coveragetable tbody tr:nth-child(15)").hide();
    }
    if (document.getElementById("Glance12").innerHTML == "0;0;0;0") {
      $(".coveragetable tbody tr:nth-child(10)").hide();
    }
    if (
      document.getElementById("Glance13").innerHTML == "0" ||
      document.getElementById("Glance13").innerHTML == ""
    ) {
      document.getElementById("penrow1").style.display = "none";
      document.getElementById("penrow2").style.display = "none";
        //$(".coveragetable tbody tr:nth-child(20)").hide();
        document.getElementById("DCPension").style.display = "none";
      document.getElementById("rrsprow").style.borderTop = "1px solid black";
    } else if (document.getElementById("Glance13").innerHTML == "4") {
      document.getElementById("penrow1").style.display = "none";
      document.getElementById("penrow2").style.display = "none";
    }

    var tmp = $("#Glance14").html().split(";");
    if (parseInt(tmp[0]) == 0) {
      $("#trVoluntary").hide();
    }
    if (parseInt(tmp[1]) == 0) {
      $("#trOptional").hide();
    }
    if (parseInt(tmp[2]) == 0) {
      $("#trRRSPVoluntary").hide();
    }
    if (parseInt(tmp[3]) == 0) {
      $("#trRRSPOptional").hide();
    }
    if (document.getElementById("Glance14").innerHTML == "0;0;0;0") {
        document.getElementById("rrsprow").style.display = "none";
        //$(".coveragetable tbody tr:nth-child(23)").hide();
    }
    $(
      ".coveragetable tbody tr:nth-child(5) td,.coveragetable tbody tr:nth-child(10) td,.coveragetable tbody tr:nth-child(16) td,.coveragetable tbody tr:nth-child(20) td,.coveragetable tbody tr:nth-child(23) td,.coveragetable tbody tr:nth-child(28) td",
    ).css("border", "0px none");
    $(".coveragetable tbody").css("border-top", "0px none");
  } else {
    $("#ExtendedHealthCoverage td")
      .eq(1)
      .text($("#optGlance4").html().split("|")[1]);
    $("#ExtendedHealthCoverage td")
      .eq(2)
      .text($("#comGlance4").html().split("|")[1]);

    $("#Dental td").eq(1).text($("#optGlance5").html().split("|")[1]);
    $("#Dental td").eq(2).text($("#comGlance5").html().split("|")[1]);

    $("#LongTermDisabilityTaxable td")
      .eq(1)
      .text($("#optGlance6").html().split("|")[1]);
    $("#LongTermDisabilityTaxable td")
      .eq(2)
      .text(fmtCurrency($("#comGlance6").html(), 0));
    $("#LongTermDisabilityNonTaxable td")
      .eq(1)
      .text($("#optGlance7").html().split("|")[1]);
    $("#LongTermDisabilityNonTaxable td")
      .eq(2)
      .text(fmtCurrency($("#comGlance7").html(), 0));

    $("#BasicLifeCovered").text(
      fmtCurrency(document.getElementById("comGlance9").innerHTML, 0),
    );

    if (document.getElementById("optGlance10").innerHTML.split(";")[0] != "0") {
      $("#OptionalEmployeeLife td").eq(1).text("Couverte");
    } else {
      $("#OptionalEmployeeLife td").eq(1).text(" – ");
    }

    $("#OptionalEmployeeLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[0],
          0,
        ),
      );

    if (document.getElementById("optGlance10").innerHTML.split(";")[1] != "0") {
      $("#OptionalSpousalLife td").eq(1).text("Couverte");
    } else {
      $("#OptionalSpousalLife td").eq(1).text(" – ");
    }

    $("#OptionalSpousalLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[1],
          0,
        ),
      );

    if (document.getElementById("optGlance10").innerHTML.split(";")[2] != "0") {
      $("#OptionalChildLife td").eq(1).text("Couverte");
    } else {
      $("#OptionalChildLife td").eq(1).text(" – ");
    }
    $("#OptionalChildLife td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance10").innerHTML.split(";")[2],
          0,
        ),
      );
    $("#EmployeeCovered td")
      .eq(2)
      .text(fmtCurrency(document.getElementById("comGlance11").innerHTML, 0));
    if (document.getElementById("optGlance12").innerHTML.split(";")[0] != "0") {
      $("#OptionalEmployee td").eq(1).text("Couverte");
    } else {
      $("#OptionalEmployee td").eq(1).text(" – ");
    }
    $("#OptionalEmployee td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[0],
          0,
        ),
      );

    if (document.getElementById("optGlance12").innerHTML.split(";")[1] != "0") {
      $("#OptionalSpousal td").eq(1).text("Couverte");
    } else {
      $("#OptionalSpousal td").eq(1).text(" – ");
    }
    $("#OptionalSpousal td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[1],
          0,
        ),
      );

    console.log(document.getElementById("optGlance12").innerHTML);
    if (document.getElementById("optGlance12").innerHTML.split(";")[2] != "0") {
      $("#OptionalChild td").eq(1).text("Couverte");
    } else {
      $("#OptionalChild td").eq(1).text(" – ");
    }
    $("#OptionalChild td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[2],
          0,
        ),
      );
    if (document.getElementById("optGlance12").innerHTML.split(";")[3] != "0") {
      $("#OptionalAD td").eq(1).text("Couverte");
    } else {
      $("#OptionalAD td").eq(1).text(" – ");
    }
    $("#OptionalAD td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance12").innerHTML.split(";")[3],
          0,
        ),
      );

    if (document.getElementById("optGlance8").innerHTML.split(";")[0] != "0") {
      $("#EmployeeCriticalIllness td").eq(1).text("Couverte");
    } else {
      $("#EmployeeCriticalIllness td").eq(1).text(" – ");
    }
    $("#EmployeeCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[0],
          0,
        ),
      );
    if (document.getElementById("optGlance8").innerHTML.split(";")[1] != "0") {
      $("#SpousalCriticalIllness td").eq(1).text("Couverte");
    } else {
      $("#SpousalCriticalIllness td").eq(1).text(" – ");
    }
    $("#SpousalCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[1],
          0,
        ),
      );
    if (document.getElementById("optGlance8").innerHTML.split(";")[2] != "0") {
      $("#ChildrenCriticalIllness td").eq(1).text("Couverte");
    } else {
      $("#ChildrenCriticalIllness td").eq(1).text(" – ");
    }
    $("#ChildrenCriticalIllness td")
      .eq(2)
      .text(
        fmtCurrency(
          document.getElementById("comGlance8").innerHTML.split(";")[2],
          0,
        ),
      );
    if (document.getElementById("optGlance18").innerHTML != "0") {
      $("#OGPEL_Cov td").eq(1).text("Couverte");
    } else {
      $("#OGPEL_Cov td").eq(1).text("Non couverte");
    }
    if (document.getElementById("Glance13").innerHTML != "1") {
      $("#DCPension td")
        .eq(2)
        .text(document.getElementById("Glance13").innerHTML + " %");
    }
    $("#penrow1 td")
      .eq(2)
      .text(
        document.getElementById("comGlance13").innerHTML.split(";")[0] + " %",
      );
    $("#penrow2 td")
      .eq(2)
      .text(
        document.getElementById("comGlance13").innerHTML.split(";")[1] + " %",
      );
    $("#trVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[0] + " %",
      );
    $("#trOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[1] + " %",
      );
    $("#trRRSPVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[2] + " %",
      );
    $("#trRRSPOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance14").innerHTML.split(";")[3] + " %",
      );
    $("#CompanyShareVoluntary td")
      .eq(2)
      .text(
        document.getElementById("comGlance15").innerHTML.split(";")[0] + " %",
      );
    $("#CompanyShareOptional td")
      .eq(2)
      .text(
        document.getElementById("comGlance15").innerHTML.split(";")[1] + " %",
      );
    $("#NonRegSavingsPlan_Optional td")
      .eq(2)
      .text(document.getElementById("comGlance16").innerHTML + " %");

    $("#TFSA td")
      .eq(1)
      .text(
        document.getElementById("optGlance17").innerHTML == 1
          ? "Cotisant"
          : "Non cotisant",
      );

    var comText =
      document.getElementById("comGlance17").innerHTML == "0"
        ? "s/o"
        : fmtCurrency(document.getElementById("comGlance17").innerHTML, 0) +
          "/paie";
    $("#TFSA td").eq(2).text(comText);

    if (parseFloat($("#Glance6").html()) == 0 || $("#Glance6").html() == "") {
      $(".coveragetable tbody tr:nth-child(3)").hide();
    }
    if (parseFloat($("#Glance7").html()) == 0 || $("#Glance7").html() == "") {
      $(".coveragetable tbody tr:nth-child(4)").hide();
    }
    if (parseFloat($("#Glance8").html()) == 0 || $("#Glance8").html() == "") {
      $(".coveragetable tbody tr:nth-child(16)").hide();
      $(".coveragetable tbody tr:nth-child(17)").hide();
      $(".coveragetable tbody tr:nth-child(18)").hide();
      $(".coveragetable tbody tr:nth-child(19)").hide();
    }
    if (parseFloat($("#Glance9").html()) == 0 || $("#Glance9").html() == "") {
      $(".coveragetable tbody tr:nth-child(6)").hide();
    }
    if (parseFloat($("#Glance10").html()) == 0 || $("#Glance10").html() == "") {
      $(".coveragetable tbody tr:nth-child(5)").hide();
      $(".coveragetable tbody tr:nth-child(6)").hide();
      $(".coveragetable tbody tr:nth-child(7)").hide();
      $(".coveragetable tbody tr:nth-child(8)").hide();
      $(".coveragetable tbody tr:nth-child(9)").hide();
    }
    if (parseFloat($("#Glance11").html()) == 0 || $("#Glance11").html() == "") {
      $(".coveragetable tbody tr:nth-child(11)").hide();
    }
    var tmp = $("#Glance12").html().split(";");
    if (parseInt(tmp[0]) == 0) {
      $(".coveragetable tbody tr:nth-child(12)").hide();
    }
    if (parseInt(tmp[1]) == 0) {
      $(".coveragetable tbody tr:nth-child(13)").hide();
    }
    if (parseInt(tmp[2]) == 0) {
      $(".coveragetable tbody tr:nth-child(14)").hide();
    }
    if (parseInt(tmp[3]) == 0) {
      $(".coveragetable tbody tr:nth-child(15)").hide();
    }
    if (document.getElementById("Glance12").innerHTML == "0;0;0;0") {
      $(".coveragetable tbody tr:nth-child(10)").hide();
    }
    if (
      document.getElementById("Glance13").innerHTML == "0" ||
      document.getElementById("Glance13").innerHTML == ""
    ) {
      document.getElementById("penrow1").style.display = "none";
      document.getElementById("penrow2").style.display = "none";
      $(".coveragetable tbody tr:nth-child(20)").hide();
      document.getElementById("rrsprow").style.borderTop = "1px solid black";
    } else if (document.getElementById("Glance13").innerHTML == "4") {
      document.getElementById("penrow1").style.display = "none";
      document.getElementById("penrow2").style.display = "none";
    }
    var tmp = $("#Glance14").html().split(";");
    if (parseInt(tmp[0]) == 0) {
      $("#trVoluntary").hide();
    }
    if (parseInt(tmp[1]) == 0) {
      $("#trOptional").hide();
    }
    if (parseInt(tmp[2]) == 0) {
      $("#trRRSPVoluntary").hide();
    }
    if (parseInt(tmp[3]) == 0) {
      $("#trRRSPOptional").hide();
    }
    if (document.getElementById("Glance14").innerHTML == "0;0;0;0") {
      $(".coveragetable tbody tr:nth-child(23)").hide();
    }
    $(
      ".coveragetable tbody tr:nth-child(5) td,.coveragetable tbody tr:nth-child(10) td,.coveragetable tbody tr:nth-child(16) td,.coveragetable tbody tr:nth-child(20) td,.coveragetable tbody tr:nth-child(23) td,.coveragetable tbody tr:nth-child(28) td",
    ).css("border", "0px none");
    $(".coveragetable tbody").css("border-top", "0px none");
      if ($("#comGlance4").html() == "") {
          $("#coveragetext1").html(
              "Vos choix au titre des régimes d’avantages sociaux, de retraite et d’épargne n’apparaissent pas ici, car l’adhésion n’était pas terminée au 31 mai 2026. Allez à <a href='https://wwwec7.manulife.com/signin/fr' target='_blank'>manulife.ca/signin</a> et ouvrez une session, ou accédez au site des participants à partir de <a href='https://upoint.aon.com/' target='_blank'>UPoint</a>, pour passer en revue vos choix les plus récents. ",
          );
          $(".coveragetable").hide();
      } else {
          $("#coveragetext1").html(
              "Le relevé de vos assurances collectives ci-dessous est établi d’après vos garanties et données d’emploi au 31 mai 2026. Les modifications apportées à votre couverture après cette date n’apparaissent pas ici. Allez à <a href='https://wwwec7.manulife.com/signin/fr' target='_blank'>manulife.ca/signin</a> et ouvrez une session, ou accédez au site des participants à partir de <a href='https://upoint.aon.com/' target='_blank'>UPoint</a>, pour passer en revue vos choix les plus récents.",
          );
      }
  }
}

function OnPrintPageLoad() {
  if (sessionStorage.getItem(sessionKey.LangCode) == "fr") {
    selectedUICulture = selectedUICultureCode.french;
  } else {
    selectedUICulture = selectedUICultureCode.eng;
  }

  GetServiceData();

  SetCommonVar();
  initCoverageTable();
  document.getElementById("row22").style.display = "none";
  if (document.getElementById("tbl_Reserveheadz")) {
    document.getElementById("tbl_Reserveheadz").style.display = "none";
  }
  if (document.getElementById("tbl_Reservehead")) {
    // document.getElementById("tbl_Reservehead").style.display = "none";
  }

  document.getElementById("row56").style.display = "none";
  //document.getElementById("tbl_Reservehead2").style.display=document.getElementById("tbl_Reservehead").style.display;

  //document.getElementById("greeting2").innerHTML = document.getElementById("greeting").innerHTML;
  document.getElementById("printButton").style.display = "block";
  document.getElementById("greeting").style.display = "none";

  showReferalAward();
  $("#OGPEL_Cov td:last a").hide();

  if (parseInt(document.getElementById("PData22").innerHTML) == 0) {
    $(".growthcallout").removeClass("d-flex");
    $(".growthcallout").addClass("d-none");
  }
  if (isRecruit == 1) {
    $("#article1, .coveragesummary, .welldate").hide();
    $(".growthcallout,#addressbox").removeClass("d-flex");
    $(".growthcallout,#addressbox").addClass("d-none");
    $("#article2,#article3").css("width", "38%");
    // $("#addressbox").css("visibility","hidden");
    $(
      "#article1 p.callout,#article2 p.callout,#article3 p.callout",
    ).removeClass("px-0");
    $(
      "#article1 p.callout img,#article2 p.callout img,#article3 p.callout img",
    ).addClass("mt-2");
    $(
      ".active_1, .active_2, .active_3, .active_4, .active_5, .active_6, .active_7, .active_8, .active_9, .active_10, .active_11, .recruit_2",
    ).remove();
    $("#tbl_Reservehead,#tbl_Reserve").hide();
    if (selectedUICulture == "en-US") {
      $("#bpintro").html(
        "Premier continually explores ways to bring meaningful colleague offerings and creative partnerships to our colleagues. Discover all the programs and local discounts that would be available to you as being part of a global organization.",
      );
    } else {
      $("#bpintro").html(
        "Premier s'efforce constamment de soumettre à ses collègues des propositions intéressantes et des partenariats novateurs. Découvrez tous les programmes et rabais locaux dont vous pourriez profiter en tant que membre d'une organisation mondiale.",
      );
    }
    $("#covtable,#covtablebreak").hide();
  } else {
    $(".recruit_1,.recruit_3,.recruit_4,.recruit_5").remove();
  }
  $("#mednote").parent("p").remove();
  //console.log($( "#mednote" ).parent().get( 0 ).tagName)
  if (selectedUICulture == "en-US") {
    document.getElementById("vacf1").innerHTML = format(
      document.getElementById("PData17").innerHTML,
      2,
    );
  } else {
    document.getElementById("vacf1").innerHTML = format(
      document.getElementById("PData17").innerHTML,
      2,
    ).replace(".", ",");
  }
  document.getElementById("vacf2").innerHTML =
    document.getElementById("PData18").innerHTML;
  document.getElementById("spanFlex3").style.visibility = "hidden";
  // document.getElementById("vacblock1").style.display =
  //   parseInt(document.getElementById("PData18").innerHTML) > 0
  //     ? ""
  //     : "none";
  //   document.getElementById("vacblock2").style.display =
  //     parseInt(document.getElementById("PData19").innerHTML) > 0 &&
  //     document.getElementById("Province").innerHTML == "QC"
  //       ? ""
  //       : "none";

  //   document.getElementById("refblock1").style.display =
  //     parseFloat(document.getElementById("PData10").innerHTML) > 0
  //       ? "inline"
  //       : "none";
  //   document.getElementById("reff1").innerHTML = fmtCurrency(
  //     document.getElementById("PData10").innerHTML,
  //     0
  //   );

  if ($("#PData26").text() == "Y") {
    if (selectedUICulture == "en-US") {
      $(".message1").text(
        "You are missing out on the maximum company match by contributing less than 4% of your annual base salary to the Basic Defined Contribution Pension Plan. To accumulate more toward your retirement, consider increasing your Basic Defined Contribution Pension Plan contribution at your next enrolment.",
      );
    } else {
      $(".message1").text(
        "Vous ne profitez pas de la contrepartie maximale de l’entreprise, car vous cotisez moins de 4 % de votre salaire de base annuel au régime de retraite à cotisations déterminées de base. Pour accumuler plus d’argent pour votre retraite, à votre prochaine adhésion, songez à augmenter votre cotisation au régime de retraite à cotisations déterminées de base.",
      );
    }
  } else {
    $(".message1").hide();
  }

  if ($("#PData25").text() == "Y") {
    if (selectedUICulture == "en-US") {
      $(".message2").text(
        "Because you’re contributing less than 3% of your annual base salary to the Voluntary Plans, you are not receiving the full company match. By increasing your contribution to 3% you’ll get your maximum match from Aon.",
      );
    } else {
      $(".message2").text(
        "Parce que vous cotisez moins de 3 % de votre salaire de base annuel au(x) régime(s) à cotisations facultatives, vous ne recevez pas la totalité de la contrepartie de l’entreprise. En augmentant votre cotisation à 3 %, vous obtiendrez la contrepartie maximale d’Aon.",
      );
    }
    $(".cool-box p").css("font-size", "9px");
  } else {
    $(".message2").hide();
  }

  if ($("#PData25").text() != "Y" && $("#PData26").text() != "Y") {
    $("#coveragemsgs").hide();
  }

  //   if ($("#PData23").text() == "0") {
  //     $("#row3a,#row3b").hide();
  //   }

  if ($("#PData17").text() == "0") {
    $("#paidvacation").hide();
  }

  if ($("#Glance9").text() == "0") {
    $("#businesstravel").hide();
    $("#shortterm").hide();
  }

  if (parseFloat(document.getElementById("Sav6").innerHTML) > 0) {
    if (selectedUICulture == "en-US") {
      $("#spanlabel51").html("Optional Life Insurance");
      $("#spanlabel51").attr("qtip-title", "Optional Life Insurance");
    } else {
      $("#spanlabel51").html("Assurance-vie facultative ");
      $("#spanlabel51").attr("qtip-title", "Assurance-vie facultative ");
    }
  }

  $("a:not(#printButton)").removeAttr("href");
  $("a:not(#printButton)").css("text-decoration", "none");
  $("a:not(#printButton)").css("pointer-events", "none");
  //$("a").css("color","black");
  $("a:not(#printButton)").css("cursor", "text");

  CheckPrintData();
  //})
  //.catch((error) => {
  //    console.error(
  //        "Method: OnPrintPageLoad:: Error loading one or more contents:",
  //        error
  //    );
  //});
}

/************************************print.html JS End*****************************************/
