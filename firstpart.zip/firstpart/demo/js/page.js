var environmentString = location.hostname;
var webApiRootUrl, environment;

var isRecruit = "";
var weAreComingFromAddNewScreen = "";

var langCode = {
  eng: "en",
  french: "fr",
};
var selectedUICultureCode = {
  eng: "en-US",
  french: "fr-CA",
};
var sessionKey = {
  LangCode: "langCode",
  Token: "token",
  RefreshToken: "refreshToken",
  ScenarioIsSaved: "scenarioIsSaved",
};

var selectedUICulture;
if (sessionStorage.getItem(sessionKey.LangCode) == "fr") {
  selectedUICulture = selectedUICultureCode.french;
} else {
  selectedUICulture = selectedUICultureCode.eng;
}

/********************* Reference **********************/

if (environmentString.indexOf("qa") >= 0) {
  webApiRootUrl = "https://ceservice.qa.alight.com/Demo/api";
  //        "https://cawiqapp0030.hewitt.com:8088/Demo/api";
  environment = "qa";
} else if (environmentString.indexOf("qc") >= 0) {
  webApiRootUrl = "https://ceservice.qc.alight.com/Demo/api";
  environment = "qc";
} else if (environmentString.indexOf("127.0.0.1") >= 0) {
  webApiRootUrl = "http://localhost:5055/api";
  //"https://ceservice.qa.alight.com/Demo/api";
  // "https://cetadmin.qa.alight.com/api/Bayer";

  //webApiRootUrl =  "http://localhost:5055/api";
  environment = "localhost";
} else if (environmentString.indexOf("localhost") >= 0) {
  webApiRootUrl = "http://localhost:5055/api";
  environment = "localhost";
} else {
  webApiRootUrl = "https://ceservice.alight.com/Demo/api";
  environment = "production";
}

/************************************recruiting.html JS Starts*****************************************/

function GetSSData() {
  var token = sessionStorage.getItem(sessionKey.Token);
  var urlParam = new URLSearchParams(window.location.search);
  var ssId = urlParam.get("ssId");
  jQuery.ajax({
    type: "GET",
    headers: {
      Authorization: "Bearer " + token,
    },
    url: webApiRootUrl + "/SavedScenario/GetSaveScenariosById?ssId=" + ssId,
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "text",
    cache: false,
    async: false,
    success: function (result) {
      console.log("ssdata:" + result);
      if (result != null) {
        $("#InputData").html(result);
      }
    },
    error: function (error) {
      if ((error.status = 401)) {
        window.location.href = "session-timeout.html";
      } else {
        console.error(
          "state: " + error.state,
          "; Status:" + error.status,
          "; Response Text: " + error.responseText,
        );
      }
    },
  });
}

function OnRecruitingPageLoad() {
  GetSSData();
  //var scriptSrc = GetResourceStringVal("CED.AonCanada.FormatsJS");
  //console.log("scriptSrc", scriptSrc);
  //var loadAllContents = [loadScript(scriptSrc)];
  //Promise.all(loadAllContents).then((message) => {
  //console.log("called inside promise");
  // eval(GetResourceStringVal("CED.AonCanada.Months"));
  loadResourceString();
  SetCommonVar();
  // eval(GetResourceStringVal("CED.AonCanada.Months"));
  loadData();
  $("#sitecover").show();
  document.getElementById("fname").focus();
  document.getElementById("fname").select();
  //});
}

/************************************recruiting.html JS Ends*****************************************/

/************************************recruiting-entry.html JS Starts*****************************************/

function BindSaveScenarioDD() {
  var token = sessionStorage.getItem(sessionKey.Token);
  jQuery.ajax({
    type: "POST",
    headers: {
      Authorization: "Bearer " + token,
    },
    url: webApiRootUrl + "/SavedScenario/GetAllSaveScenarios",
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      if (result.length > 0) {
        defaultOtpTxt = GetResourceStringVal(
          "AON.HRP.ESS.Recruiting.SelectScenario.AonCanada",
        );
        $("#ddSaveScenarioDest").append(
          $("<option>").prop("value", -1).text(defaultOtpTxt),
        );
        var id = 0;
        result.forEach((item) => {
          console.log(
            "item:" + item + " " + item.dDtextField + "-->" + item.indx,
          );
          var option = $("<option>")
            .prop("value", item.indx)
            .text(item.dDtextField);
          $("#ddSaveScenarioDest").append(option);

          var row = `<tr><td>
                                <input id="deleteScenarioschkbx_${id}" type="checkbox" value=${item.indx}>
                                <label for="deleteScenarioschkbx_${id}">${item.dDtextField}</label>
                            </td></tr>`;
          id += 1;
          $("#deleteScenarioschkbx tbody").append(row);
        });
      } else {
        defaultOtpTxt = GetResourceStringVal(
          "AON.HRP.ESS.Recruiting.NoSavedScenario",
        );
        $("#ddSaveScenarioDest").append(
          $("<option>").prop("value", -1).text(defaultOtpTxt),
        );
      }
    },
    error: function (error) {
      if ((error.status = 401)) {
        window.location.href = "session-timeout.html";
      } else {
        console.error(
          "state: " + error.state,
          "; Status:" + error.status,
          "; Response Text: " + error.responseText,
        );
      }
    },
  });
}

function btnDeleteScenario_Click() {
  var token = sessionStorage.getItem(sessionKey.Token);

  if (ValidateCheckBoxList()) {
    var ssItemToDelete = "";
    $("[id^='deleteScenarioschkbx_']:checked").each(function () {
      ssItemToDelete += $(this).val() + ",";
    });
    console.log("ssItemToDelete:", ssItemToDelete);

    jQuery.ajax({
      type: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
      url: webApiRootUrl + "/SavedScenario/DeleteSaveScenarios",
      data: JSON.stringify(ssItemToDelete),
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      cache: false,
      async: false,
      success: function (result) {
        console.log(result);
        window.location.reload();
      },
      error: function (error) {
        if ((error.status = 401)) {
          window.location.href = "session-timeout.html";
        } else {
          console.error(
            "state: " + error.state,
            "; Status:" + error.status,
            "; Response Text: " + error.responseText,
          );
        }
      },
    });
  }
}

/************************************recruiting-entry JS ends*****************************************/

/************************************Common JS Starts*****************************************/

function HRPIndividualizedStamenetDownload() {
  var token = sessionStorage.getItem(sessionKey.Token);

  fetch(webApiRootUrl + "/Login/GetIndividualizedStatement", {
    method: "GET",
    headers: {
      Authorization: "Bearer " + token,
      responseType: "blob",
    },
  })
    .then((response) => {
      if (response.status == 404) {
        alert(
          "Your Individualized statement is not available. Please connect with administrator.",
        );
      } else if (response.status == 401) {
        //alert("Unauthorized");
        window.location.href = "session-timeout.html";
      } else {
        response.blob().then((blob) => {
          console.log(blob);
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "IndividualizedStatement.pdf";
          a.click();
          URL.revokeObjectURL(url);
          RefreshToken(false);
        });
      }
    })
    .catch((error) => {
      console.error(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    });
}

function OpenSurvey() {
  if (RefreshToken(false)) {
    token = sessionStorage.getItem(sessionKey.Token);
  }
  sessionStorage.setItem("SurveyFromExit", 0);
  // const v = window.open('', '_survey');
  // v.close();
  window.open("take-survey.html", "_survey");
}

function SetCommonVar() {
  if (document.getElementById("BusUnit")) {
    //console.log("BusUnit")
    isRecruit = document.getElementById("BusUnit").innerHTML == "XXX" ? 1 : 0;
    //console.log("isRecruit: " + isRecruit)
  } else {
    isRecruit = location.href.indexOf("params=") >= 0 ? 1 : 0;
  }

  //2022
  if ($("#EmpID").html() == "99999999" || $("#EmpID").html() == "88888888") {
    isRecruit = 1;
  }

  if (
    (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
      !document.getElementById("EmpID")) ||
    location.search.indexOf("params=") >= 0
  ) {
    weAreComingFromAddNewScreen = true;
  } else {
    weAreComingFromAddNewScreen = false;
  }
  // console.log("weAreComingFromAddNewScreen: " + weAreComingFromAddNewScreen)

  existingSS = location.search.indexOf("ssId") >= 0 ? true : false;
  newSS = location.search.indexOf("params=") >= 0 ? true : false;

  if (location.href.toLowerCase().indexOf("/print") < 0) {
    if (
      (location.search.indexOf("params=") >= 0 &&
        document.getElementById("pageID")) ||
      isRecruit == 1
    ) {
      console.log("common");
      if (document.getElementById("pageID")) {
        if (document.getElementById("pageID").value != "100") {
          if (weAreComingFromAddNewScreen == true) {
            qsparams = location.href.substring(
              location.href.indexOf("?params="),
              location.href.length,
            );

            ssid = qsparams.substring(
              qsparams.indexOf("=") + 1,
              qsparams.indexOf(";"),
            );
            document.getElementById("link1").href += qsparams;
            document.getElementById("link2").href += qsparams;
            document.getElementById("link3").href += qsparams;
            document.getElementById("link4").href += qsparams;
            document.getElementById("link5").href += qsparams;
            document.getElementById("link6").href += qsparams;
            document.getElementById("printLink").href =
              `javascript:window.open('print.html${encodeURIComponent(qsparams)}', '_blank')`;

            document.getElementById("returnToSS").href =
              ssid == 0
                ? "recruiting.html" + qsparams
                : "recruiting.html?ssId=" + ssid;
            document.getElementById("returnToSS").style.display = "";
            document.getElementById("saveSS").style.display = "";
            document.getElementById("lnkEngLang").style.display = "none";
            document.getElementById("lnkFRLang").style.display = "none";
          } else {
            document.getElementById("lnkEngLang").style.display = "none";
            document.getElementById("lnkFRLang").style.display = "none";
          }
          if (document.getElementById("pageID").value != 9) {
            document.getElementById(
              "link" + document.getElementById("pageID").value,
            ).style.color = "#db0011";
          }
        }
        // document.getElementById("link1").href+=location.search;
        // document.getElementById("link2").href+=location.search;
        //document.getElementById("link3").href+=location.search;
        //document.getElementById("link4").href+=location.search;
        // document.getElementById("link5").href+=location.search;
        /* document.getElementById("printLink").href+=location.search;
                  document.getElementById("returnToSS").href+=location.search;
                  document.getElementById("returnToSS").style.display="";
                  document.getElementById("saveSS").style.display="";
                  document.getElementById("lnkEngLang").style.display="none";
                  document.getElementById("lnkFRLang").style.display="none";
                  document.getElementById("logoff").href="javascript:close_window()";*/
      }
    }

    //if(document.getElementById('pageID')){
    // document.getElementById("link" + document.getElementById('pageID').value).style.color="#db0011"
    //   ;    }
  }
}

function LogoutEmployee() {
  var token = sessionStorage.getItem(sessionKey.Token);
  var status = false;
  jQuery.ajax({
    type: "POST",
    headers: {
      Authorization: "Bearer " + token,
    },
    url: webApiRootUrl + "/Login/LogoutEmployee",
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      sessionStorage.clear();
      status = true;
    },
    error: function (error) {
      status = false;
      if ((error.status = 401)) {
        window.location.href = "session-timeout.html";
      } else {
        console.error(
          "state: " + error.state,
          "; Status:" + error.status,
          "; Response Text: " + error.responseText,
        );
      }
    },
  });
  return status;
}

function Logout(showMsg = false) {
  LogoutEmployee();
  if (showMsg) {
    $("#logoutMsg").show();
    $("#beforeLogoutMsg").hide();
  }
}

function GetSetLangFromURL() {
  const urlParam = new URLSearchParams(window.location.search);
  let lang = urlParam.get("lang");
  if (lang != null) {
    if (lang == "en") {
      sessionStorage.setItem(sessionKey.LangCode, langCode.eng);
    } else {
      sessionStorage.setItem(sessionKey.LangCode, langCode.french);
    }
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

function ChangeLang(element, changeWinOpenerLangCode = false) {
  console.log($(element).attr("lang"));
  var lang = $(element).attr("lang");
  if (lang == "E") {
    sessionStorage.setItem(sessionKey.LangCode, langCode.eng);
    selectedUICulture = selectedUICultureCode.eng;
  } else {
    sessionStorage.setItem(sessionKey.LangCode, langCode.french);
    selectedUICulture = selectedUICultureCode.french;
  }

  if (changeWinOpenerLangCode == true) {
    if (lang == "E") {
      window.opener.sessionStorage.langCode = langCode.eng;
      window.opener.selectedUICulture = selectedUICultureCode.eng;
    } else {
      window.opener.sessionStorage.langCode = langCode.french;
      window.opener.selectedUICulture = selectedUICultureCode.french;
    }
  }
  window.location.reload();
}

function IsTokenExpired(token) {
  const tokenPart = token.split(".");
  const payload = JSON.parse(atob(tokenPart[1]));
  const exp = new Date(payload.exp * 1000);
  const currentTime = Math.floor(Date.now() / 1000);
  console.log(payload.exp, "-", exp, "-", Date.now(), "-", currentTime);
  console.log("token expired", payload.exp < currentTime);
  return payload.exp < currentTime;
}

function GetServiceData() {
  console.log("called inside GetServiceData");
  var serviceData;
  var token = sessionStorage.getItem(sessionKey.Token);
  if (token != null && token != "") {
    if (IsTokenExpired(token)) {
      if (RefreshToken(false)) {
        token = sessionStorage.getItem(sessionKey.Token);
      }
    }
    jQuery.ajax({
      type: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
      url: webApiRootUrl + "/Login/GetEmpServiceData",
      data: {},
      contentType: "application/json; charset=utf-8",
      dataType: "text",
      cache: false,
      async: false,
      success: function (result) {
        console.log(result);
        serviceData = result;
        if (serviceData != null) {
          RefreshToken(false);
        }
      },
      error: function (error) {
        if ((error.status = 401)) {
          window.location.href = "session-timeout.html";
        } else {
          console.error(
            "state: " + error.state,
            "; Status:" + error.status,
            "; Response Text: " + error.responseText,
          );
        }
      },
    });
  } else {
    console.error("Empty token");
    window.location.href = "session-timeout.html";
  }
  $("#InputData_nwsdbd").html(serviceData);
  console.log("GetServiceData completed");
  return serviceData;
}

function RefreshToken(asyncFlag = false) {
  var IsTokenRefreshed = false;
  var accessToken = sessionStorage.getItem(sessionKey.Token);
  var refreshToken = sessionStorage.getItem(sessionKey.RefreshToken);
  console.log("refresh token called.");
  jQuery.ajax({
    type: "POST",
    url: webApiRootUrl + "/Login/RefreshToken",
    headers: {
      Authorization: "Bearer " + accessToken,
      refreshToken: refreshToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: asyncFlag,
    success: function (result) {
      //accessToken=newToken,refreshToken
      console.log(result);
      if (result.accessToken != null && result.refreshToken != null) {
        sessionStorage.setItem(sessionKey.Token, result.accessToken);
        sessionStorage.setItem(sessionKey.RefreshToken, result.refreshToken);
        IsTokenRefreshed = true;
      } else {
        window.location.href = "session-timeout.html";
      }
    },
    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });

  return IsTokenRefreshed;
}

function SetVariable() {
  if (document.getElementById("BusUnit")) {
    //console.log("BusUnit")
    isRecruit = document.getElementById("BusUnit").innerHTML == "XXX" ? 1 : 0;
    //console.log("isRecruit: " + isRecruit)
  } else {
    isRecruit = location.href.indexOf("params=") >= 0 ? 1 : 0;
  }

  //2022
  if ($("#EmpID").html() == "99999999" || $("#EmpID").html() == "88888888") {
    isRecruit = 1;
  }
}

function RecruitingSaveSuccess(result) {
  var lang = document.getElementById("userlang").value;
  if (lang == "E") {
    alert("Scenario saved successfully.");
    //sessionStorage.setItem(sessionKey.ScenarioIsSaved,true);
    if (result != null) {
      console.log(result);
      url = UpdateSSIdInURL(result);
      if (url != null || url != "") {
        location.href = url;
      }
    }
  } else {
    alert("Scénario enregistré avec succès.");
  }
}

function RecruitingSaveError() {
  var lang = document.getElementById("userlang").value;
  if (lang == "E") {
    alert("Scenario save failed.");
  } else {
    alert("Scénario Échec de l'enregistrement.");
  }
}

function HRP_SaveUpdateSaveScenarios(ssData) {
  if (sessionStorage.getItem(sessionKey.ScenarioIsSaved) == "true") {
    var msg =
      sessionStorage.langCode == langCode.eng
        ? "Scenario is already saved."
        : "Le scénario est déjà enregistré.";
    alert(msg);
  } else {
    var token = sessionStorage.getItem(sessionKey.Token);
    console.log(ssData);
    jQuery.ajax({
      cache: false,
      asynch: false,
      contentType: "application/json; charset=utf-8",
      type: "POST",
      dataType: "json",
      data: JSON.stringify(ssData),
      url: webApiRootUrl + "/SavedScenario/SaveUpdateScenarios",
      headers: {
        Authorization: "Bearer " + token,
      },
      success: function (result) {
        RecruitingSaveSuccess(result);
      },
      error: RecruitingSaveError,
    });
  }
}

function UpdateSSIdInURL(newSSId) {
  var url = "";
  qsparams = location.href.substring(
    location.href.indexOf("?params="),
    location.href.length,
  );
  //exisitngSSid=qsparams.substring(qsparams.indexOf("=")+1,qsparams.indexOf(";"))
  qsparams = qsparams.substring(qsparams.indexOf(";"), qsparams.length);
  url = new URL(location.href).pathname + "?params=" + newSSId + qsparams;

  return url;
}

function ValidateInboundSSORequest() {
  var status = false;
  const queryString = window.location.search;
  console.log(queryString);
  const urlParams = new URLSearchParams(queryString);
  var requestToken = urlParams.get("request");
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Login/VerifyInboundSSO",
    data: {},
    headers: {
      "X-Host-Name": window.location.hostname,
      requestToken: requestToken,
    },
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      if (result != null) {
        console.log("HrpSSOResult " + result);
        if (result.loginToken != null) {
          sessionStorage.setItem(
            sessionKey.Token,
            result.loginToken.accessToken,
          );
          sessionStorage.setItem(
            sessionKey.RefreshToken,
            result.loginToken.refreshToken,
          );
          var lang = result.lang == "E" ? langCode.eng : langCode.french;
          sessionStorage.setItem(sessionKey.LangCode, lang);
          status = true;
        } else {
          console.error("ISSOResult result.logintoken is null");
        }
      } else {
        console.error("ISSOResult result is null");
      }
    },

    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });
  if (status == true) {
    window.location.href = "welcome.html";
  } else {
    $("#error").text("Connection error. Please contact your administrator.");
  }
}

/************************************common JS End*****************************************/

/************************************take-survey.html JS start *****************************************/

function Save() {
  window.name = "_survey";
}

function TakeSurvey() {
  var SurveyId = $("#btnTakeSurvey").attr("survey-id");

  if (SurveyId > 0 || SurveyId != undefined) {
    var url = window.location.href.split("/").slice(1, -1).join("/");
    url = "http:/" + url + "/survey.html?id=" + SurveyId.toString();
    window.location.href = url;
    //window.location = 'https://' + window.location.host + '/Survey?ID=' + SurveyId.toString();
    return false;
  }
}

function GetSurveyList() {
  //var accessToken = sessionStorage.getItem(sessionKey.Token);
  var accessToken = window.opener.sessionStorage.token;
  //sessionStorage.setItem(sessionKey.LangCode, "fr");

  var langCode = sessionStorage.getItem(sessionKey.LangCode);
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Survey/GetSurveyList?langCode=" + langCode,
    headers: {
      Authorization: "Bearer " + accessToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: false,
    success: function (result) {
      //accessToken=newToken,refreshToken
      console.log(result);
      if (result != null) {
        $("#SurveyDetail td:eq(0) span").text(result.surveyName);
        $("#SurveyDetail td:eq(1) a").attr("survey-id", result.surveyID);
        $("#DivNoSurveyList").hide();
        $("#SurveyTable").show();
        RefreshTokenForWindowOpener();
      } else {
        $("#DivNoSurveyList").show();
        $("#SurveyTable").hide();
      }
      $("#surveyDiv").show();
    },
    error: function (error) {
      if ((error.status = 401)) {
        window.location.href = "session-timeout.html";
      } else {
        $("#DivNoSurveyList").hide();
        $("#SurveyTable").hide();
        console.log(
          "state: " + error.state,
          "; Status:" + error.status,
          "; Response Text: " + error.responseText,
        );
      }
    },
  });
}

/************************************take-survey.html JS end*****************************************/

/************************************survey.html JS start*****************************************/

function SaveSurveyAnswerModel(data) {
  var accessToken = sessionStorage.getItem(sessionKey.Token);
  jQuery.ajax({
    cache: false,
    asynch: true,
    contentType: "application/json; charset=utf-8",
    type: "POST",
    dataType: "json",
    data: JSON.stringify(data),
    url: webApiRootUrl + "/Survey/SaveEmployeeSurveyResponse",
    headers: {
      Authorization: "Bearer " + accessToken,
    },
    success: onSuccess,
    error: onError,
  });
}

function close_window() {
  top.window.opener = top;
  top.window.open("", "_parent", "");
  top.window.close();
}
function ConfirmOnEXIT(item) {
  if (confirm(item) == true) {
    close_window();
    return true;
  } else return false;
}

function SurveyOnPageLoad() {
  sessionStorage.clear();
  sessionStorage.setItem(
    sessionKey.LangCode,
    window.opener.sessionStorage.langCode,
  );
  locale = {
    ConfirmOnSumitSurveyMsg: GetResourceStringVal(
      "SURVEY.ConfirmOnSubmitMessage",
    ),
  };
  loadResourceString();
  GetSurveyView();

  var text_max = 500;
  var controlid = $("[id^=feedback_textlong_]"); //'#textlong_42_0';
  eval(GetResourceStringVal("CED.AonCanada.Survey.CharacterCounter1"));

  $(controlid).keyup(function () {
    var text_length = $(controlid).val().length;
    var text_remaining = text_max - text_length;
    $("#feedback-textarea_counter").css({ color: "#045fb4" });
    eval(GetResourceStringVal("CED.AonCanada.Survey.CharacterCounter"));

    if (text_length == text_max) {
      $("#feedback-textarea_counter").css({ color: "red" });
      $("#feedback-textarea_counter").html(
        "Feedback cannot exceed 500 characters",
      );
    }
  });

  jQuery("#btnCancel").removeAttr("href");
  jQuery("#btnCancel").attr(
    "onclick",
    eval(GetResourceStringVal("CED.AonCanada.Survey.Exit")),
  );

  //$("textarea").resizable();
  // $(function () {
  //     $("textarea").resizable({
  //         handles: "se"
  //     });
  // });
}

function GetSurveyView() {
  //var accessToken = sessionStorage.getItem(sessionKey.Token);
  var accessToken = window.opener.sessionStorage.token;
  var urlParam = new URLSearchParams(window.location.search);
  var surveyId = urlParam.get("id");
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Survey/GetSurveyControl?surveyId=" + surveyId,
    headers: {
      Authorization: "Bearer " + accessToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "text",
    cache: false,
    async: false,
    success: function (result) {
      console.log(result);
      if (result != null) {
        RefreshTokenForWindowOpener();
        $("#ViewSurveyControls").html(result);
        $("#FeedbackComments").text(GetResourceStringVal("Feedback.Comments"));
        $("#ValidateFeedbackComments").text(
          GetResourceStringVal("Validate.Feedback.Comments"),
        );
        $("#btnSave").show();
        $("#surveyDiv").show();
      } else {
        $("#btnSave").hide();
      }
    },
    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });
}

/************************************survey.html JS end*****************************************/

/************************************hrpsso.html JS Starts*****************************************/

function ValidateHRPSSORequest() {
  var status = false;
  const queryString = window.location.search;
  console.log(queryString);

  const urlParams = new URLSearchParams(queryString);
  var requestToken = urlParams.get("request");
  if (requestToken == "test1") {
    //88888888 : fr recuirter
    requestToken =
      "r4uN5rDatTQeOIlR09Zxka2ZsRlOADb+SfGvo7VglrczEl/1wq6Y175XQqyIvUhNDXLa4Q+7gXQecRhATGfqKob4M9jc0tSUgf1+0cl/76PLjh0LMWP+PZO9l+VS6yrkvSTWeeO2hIEF1XoEF9WSE+x75QyE9Of4j5SUpIWm+w3fQ7ek6XCiHnxy5SbjZqZNfZAdBD+86isz23gAbHL/gQ==";
  } else if (requestToken == "test2") {
    //99999  : en -recruiter
    requestToken =
      "r4uN5rDatTRL48DABbLER+drCwYkGNfQjLKqFkQO1FhPJ9CLQLJLVU/2hHELA6dvmf/xxYl9XOzhKO5cbXA+izZSeXP3xTi5Vo6JlOc4jUNt2BkUVCB10CdAgr/gtLqZDSeiK/otx6bkfx9538q7N5lxhCLY2NpNDQjbh2aCE5KyHHe/ml/seMtSfMYK/zteFwmhMoHp/cRoIOWcDn124g==";
  } else if (requestToken == "test3") {
    //0594141  : candidate
    requestToken =
      "r4uN5rDatTRIFLiqG6x2DHytVVZ9LVE54D99IYBEXPKMMIKADkwSkasnO0t09clzVDCI1W9V12COVrzgYe5zdgVnb3dRmoEHa1YBAeCUzimMe5VVscrD7KYB6MmBxDzXQAmiRKZuzCefhyNFpqUFK6b/OWZbP/nUIOsB8OJNkzcpf/qVncD+SnfFnd9F7R0/e7ao5AFpqnTyzmEdZ7M6ow==";
  } else {
    console.log("no test request token found");
  }
  //alert("request Token " + requestToken);
  jQuery.ajax({
    type: "GET",
    url: webApiRootUrl + "/Login/VerifyHRPSSO",
    data: {},
    headers: {
      "X-Host-Name": window.location.hostname,
      requestToken: requestToken,
    },
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    async: false,
    success: function (result) {
      console.log(result);
      if (result != null) {
        console.log("HrpSSOResult " + result);
        if (result.loginToken != null) {
          sessionStorage.setItem(
            sessionKey.Token,
            result.loginToken.accessToken,
          );
          sessionStorage.setItem(
            sessionKey.RefreshToken,
            result.loginToken.refreshToken,
          );
          var lang = result.lang == "E" ? langCode.eng : langCode.french;
          sessionStorage.setItem(sessionKey.LangCode, lang);
          status = true;
        } else {
          console.error("HrpSSOResult result.logintoken is null");
        }
      } else {
        console.error("HrpSSOResult result is null");
      }
    },

    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });
  if (status == true) {
    window.location.href = "welcome.html";
  } else {
    //$("#error").text(GetResourceStringVal("Enrollment.LoginFromAdmin.Message"));
    $("#error").show();
  }
}

/************************************hrpsso.html JS end*****************************************/

/************************************welcome.html JS Starts*****************************************/

function CheckWelcomeData() {
  loadflag = 0;

  $(".recruiterText").hide();

  if (
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "99999999"
  ) {
    if (location.href.toLowerCase().indexOf("params=") < 0) {
      location.replace("recruiting-entry.html");
    } else {
      robSwitches();
      loadPageRecruiting();
    }
  } else if (document.getElementById("optGlance20") != null) {
    var empname = document.getElementById("FirstName").innerHTML;
    if (
      (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
        !document.getElementById("EmpID")) ||
      location.search.indexOf("params=") >= 0 ||
      sessionStorage.getItem("data")
    ) {
      weAreComingFromAddNewScreen = true;
    } else {
      weAreComingFromAddNewScreen = false;
    }
    if (isRecruit == 1) {
      robSwitches();
    }
    loadPage();
    loadflag = 1;
  }
  //Custom
  //alert(document.getElementById("PData10").innerHTML)
  // document.getElementById("refblock1").style.display = (parseFloat(document.getElementById("PData10").innerHTML) > 0) ? "inline" : "none";
  //document.getElementById("reff1").innerHTML = fmtCurrency(document.getElementById("PData10").innerHTML, 0);

  if (document.getElementById("optGlance20") == null) {
    if (location.href.toLowerCase().indexOf("params=") < 0) {
      //   location.replace("/Help/Exception");  // Dan Sept 2021 to match QC Premier
    }
  }

  if (parseInt(document.getElementById("PData22").innerHTML) == 0) {
    $(".growthcallout").removeClass("d-flex");
    $(".growthcallout").addClass("d-none");
    $("#surveycallout").css("margin-top", "0px");
  }
}

function OnWelcomePageLoad() {
  //alert(sessionStorage.getItem(sessionKey.Token));
  GetServiceData();
  // var scriptSrc = GetResourceStringVal("CED.AonCanada.FormatsJS");
  //console.log("scriptSrc", scriptSrc);
  var loadAllContents = [
    loadContent("header", "header.html"),
    //loadScript(scriptSrc),
  ];
  Promise.all(loadAllContents)
    .then((message) => {
      console.log("called inside promise");

      loadResourceString();
      SetCommonVar();
      //SetVariable();

      document.getElementById("nav1").className = "selected";
      document.getElementById("nav2").className = "";
      document.getElementById("nav3").className = "";
      document.getElementById("nav4").className = "";
      document.getElementById("nav5").className = "";

      if (selectedUICulture == "fr-CA") {
        $("#surveycallout").css("margin-top", "0px");
        $("#surveyhead").css("height", "43px");
        $("#surveyhead").css("padding-top", "3px");
        $("#surveyhead, #article1 h2, #article3 h2").css("line-height", "18px");
        $("#surveyhead").css("background-image", "url(../media/3dbg2.png)");
        $("#surveyhead").css("background-image", "url(../media/3dbg2.png)");
      }

      CheckWelcomeData();
      showReferalAward();
      if (new Date() > new Date("2022-09-19")) {
        $(".welldate").hide();
      }
      if (isRecruit == 1) {
        $(".hideInRecruiterVer").hide();
        $(".box a").removeAttr("href");
        // $("#article1,.welldate,#article1").hide();
        $(".welldate,#referralProgramm").hide();
        $(".growthcallout").removeClass("d-flex");
        $(".growthcallout").addClass("d-none");
        $("#article2,#article3").css("width", "37%");
        $(".active_1, .recruit_2").remove();
      } else {
        $(".recruit_1,.recruit_3,.recruit_4").remove();
      }
      $("#sitecover").css("visibility", "visible");
    })
    .catch((error) => {
      console.error(
        "Method : OnWelcomePageLoad :: Error loading one or more contents:",
        error,
      );
    });
}

/************************************welcome.html JS End*****************************************/

/************************************rewards.html JS Start*****************************************/

function OnRewardsPageLoad() {
  GetServiceData();
  var loadAllContents = [loadContent("header", "header.html")];
  Promise.all(loadAllContents)
    .then((message) => {
      console.log("called inside rewards promise");
      loadResourceString();
      SetCommonVar();
      //SetVariable();
      $("#sitecover").css("visibility", "visible");
      CheckRewardsData();
    })
    .catch((error) => {
      console.error(
        "Method: OnRewardsPageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

function CheckRewardsData() {
  var pData28data = parseInt($("#PData28").text());
  var EGIB_qContent = "";
  if (pData28data < 70) {
    EGIB_qContent =
      selectedUICulture == "en-US"
        ? "This includes Medical, Dental, Basic Employee Life Insurance, Basic Accidental Death and Dismemberment and Long-Term Disability."
        : "Comprennent les garanties soins médicaux et soins dentaires, l’assurance-vie de base, l’assurance en cas de décès et mutilation accidentels (DMA), ainsi que l’assurance invalidité de longue durée.";
  } else {
    EGIB_qContent =
      selectedUICulture == "en-US"
        ? "This includes your Medical, and Dental plans."
        : "Comprennent les garanties soins médicaux et soins dentaires, l’assurance vie de base, ainsi que l’assurance en cas de décès et mutilation accidentels (DMA).";
  }
  $("#spanlabel18").attr("qtipcontent", EGIB_qContent);

  if (
    !document.getElementById("EmpID") ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "99999999"
  ) {
    // if (document.getElementById("EmpID").innerHTML == "99999999" || document.getElementById("EmpID").innerHTML == "88888888") {
    $(".cool-box a").removeAttr("href");

    document.getElementById("regtables").innerHTML = "";
    robSwitches();
    if (robPaidvac > 0) {
      $("#vacWeek").html(robPaidvac);
      $("#vacWeekText").show();
    } else {
      $("#vacWeekText").hide();
    }
     

    if (selectedUICulture == "en-US") {
      document.getElementById("estLabel").innerHTML = "Estimated";
      document.getElementById("vac2").innerHTML =
        "<br><br>Your first year’s estimated vacation is " +
        robPaidvac +
        " weeks for eligible vacation and 3 personal days. This assumes that you remain an active employee for the year.";
    } else {
      document.getElementById("estLabel").innerHTML = "estimative";
      document.getElementById("vac2").innerHTML =
        "<br><br>1)	Votre première année, vous aurez droit à " +
        robPaidvac +
        " semaine(s) de vacances (estimation) et à 3 jours de congé personnels, à condition de rester en service actif toute l'année.";
    }
    loadPageRecruiting();
  } else if (document.getElementById("optGlance20") != null) {
    if (
      (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
        !document.getElementById("EmpID")) ||
      location.search.indexOf("params=") >= 0
    ) {
      weAreComingFromAddNewScreen = true;
    } else {
      weAreComingFromAddNewScreen = false;
    }
    if (isRecruit == 1) {
      robSwitches();
    }

    document.getElementById("recruitingtables").innerHTML = "";

    loadPage();

    if ($("#Glance9").text() == "0") {
      $("#shortterm").hide();
    }

    if (isRecruit == 1) {
      document.getElementById("estLabel").innerHTML = "Estimated";
      $("#nav5").hide();

      // var tmp = $("#spanlabel1").html().replace(" as at April 30, 2023", "");
      // $("#spanlabel1").html(tmp);

      // var tmp = $("#spanlabel1").html().replace(" as of April 30, 2023", "");
      // $("#spanlabel1").html(tmp);
      var tmp = $("#spanlabel1").html().replace(" as at April 30, 2023", "");
      $("#spanlabel1").html(tmp);
 
    }

    //Custom
    if (selectedUICulture == "en-US") {
      document.getElementById("vacf1").innerHTML = format(
        document.getElementById("PData17").innerHTML,
        2,
      );
    } else {
      document.getElementById("vacf1").innerHTML = format(
        document.getElementById("PData17").innerHTML,
        2,
      ).replace(".", ",");
    }
    document.getElementById("vacf2").innerHTML =
      document.getElementById("PData18").innerHTML;
    // document.getElementById("f3").innerHTML =  fmtCurrency(document.getElementById("PData12").innerHTML,2);
    document.getElementById("spanFlex3").style.visibility = "hidden";
    // document.getElementById("f4").innerHTML =  fmtCurrency(document.getElementById("PData13").innerHTML,2);
    // document.getElementById("f5").innerHTML =  document.getElementById("PData14").innerHTML;
    //document.getElementById("vacblock1").style.display=(parseInt(document.getElementById("PData18").innerHTML)>0)?"":"none";
    // document.getElementById("vacblock2").style.display =
    //   parseInt(document.getElementById("PData19").innerHTML) > 0 &&
    //   document.getElementById("Province").innerHTML == "QC"
    //     ? ""
    //     : "none";

    document.getElementById("row22").style.display =
      parseInt(document.getElementById("PData20").innerHTML) > 0 ? "" : "none";

    // document.getElementById("vac2").style.display=(parseFloat(document.getElementById("PData17").innerHTML)>0)?"":"none";

    if (parseFloat(document.getElementById("Glance15").innerHTML) == 1) {
      document.getElementById("spanlabel26").qtipcontent +=
        " You are entitled to a Defined Benefit pension for prior service. Premier Canada has not valued this prior DB benefit.";
    }
  }

  $("span[qtipcontent]").qtip({
    content: {
      text: function (event, api) {
        if (isRecruit == 1) {
          var tmp = $(this).html().replace(" as of April 30, 2023", "");
          $(this).html(tmp);
          var tmp = $(this).html().replace(" as at April 30, 2023", "");
          $(this).html(tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" as of April 30, 2023", "");
          $(this).attr("qtipcontent", tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" as at April 30, 2023", "");
          $(this).attr("qtipcontent", tmp);
          var tmp = $(this)
            .attr("qtip-title")
            .replace(" as of April 30, 2023", "");
          $(this).attr("qtip-title", tmp);
          var tmp = $(this)
            .attr("qtip-title")
            .replace(" as at April 30, 2023", "");
          $(this).attr("qtip-title", tmp);

          var tmp = $(this)
            .attr("qtip-title")
            .replace(" on your April 30, 2023", " on your");
          $(this).attr("qtip-title", tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" on your April 30, 2023", " on your");
          $(this).attr("qtipcontent", tmp);

          var tmp = $(this)
            .attr("qtipcontent")
            .replace("2023 contributions", "contributions");
          $(this).attr("qtipcontent", tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace("performance in 2023", "performance");
          $(this).attr("qtipcontent", tmp);
        }

        if ($(this).attr("id") == "spanlabel10") {
          if (selectedUICulture == "en-US") {
            return (
              "You were granted a Restricted Stock Unit (RSU) award under the Incentive Stock Program. These RSUs represent 35% of your annual incentive award and vest 33.3% per year over three years. The value shown is based on a stock price of " +
              fmtCurrency(document.getElementById("PData12").innerHTML, 2) +
              /*" at " + monthArr[parseInt(document.getElementById('PData11').innerHTML.split("-")[1]) - 1] + " " + parseInt(document.getElementById('PData11').innerHTML.split("-")[2]) + ", " + document.getElementById('PData11').innerHTML.split("-")[0] +*/ " and converted to Canadian dollars. <a href='https://www.netbenefits.com' target=&quot;_blank&quot;>Log in to your Fidelity account</a> for more information."
            );
          } else {
            return (
              "Vous avez reçu une récompense en unités d’actions subalternes (UAS) assujettie à des restrictions au titre du Régime d’actionnariat incitatif d’Aon. Ces unités représentent 35 % de votre rémunération incitative annuelle, et 33 % d’entre elles vous seront acquises chaque année au fil des trois prochaines années. La valeur indiquée est basée sur un cours de l’action de " +
              fmtCurrency(document.getElementById("PData12").innerHTML, 2) +
              " (montant converti en dollars canadiens). <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir"
            );
          }
        } else if ($(this).attr("id") == "spanlabel11") {
          var multi_rsudata = document.getElementById("PData21").innerHTML;
          var rsudata1 = null;
          var rsudata2 = null;
          if (multi_rsudata != "0") {
            multi_rsudata = multi_rsudata.split("|");
            rsudata1 = multi_rsudata[0].split(";");
            rsudata2 = multi_rsudata[1].split(";");

 
            rsudata1[0] = new Date(rsudata1[0]);
            rsudata1[0] =
              selectedUICulture == "en-US"
                ? monthArr[rsudata1[0].getMonth()] +
                  " " +
                  rsudata1[0].getUTCDate() +
                  ", " +
                  rsudata1[0].getFullYear()
                : rsudata1[0].getUTCDate() +
                  "&nbsp;" +
                  monthArrFR[rsudata1[0].getMonth()] +
                  "&nbsp;" +
                  rsudata1[0].getFullYear();
            rsudata2[0] = new Date(rsudata2[0]);
            rsudata2[0] =
              selectedUICulture == "en-US"
                ? monthArr[rsudata2[0].getMonth()] +
                  " " +
                  rsudata2[0].getUTCDate() +
                  ", " +
                  rsudata2[0].getFullYear()
                : rsudata2[0].getUTCDate() +
                  "&nbsp;" +
                  monthArrFR[rsudata2[0].getMonth()] +
                  "&nbsp;" +
                      rsudata2[0].getFullYear();


              var sspText = "";

              if (multi_rsudata.length > 2) {
                  rsudata3 = multi_rsudata[2].split(";");


                  rsudata3[0] = new Date(rsudata3[0]);
                  rsudata3[0] =
                      selectedUICulture == "en-US"
                          ? monthArr[rsudata3[0].getMonth()] +
                          " " +
                          rsudata3[0].getUTCDate() +
                          ", " +
                          rsudata3[0].getFullYear()
                          : rsudata3[0].getUTCDate() +
                          "&nbsp;" +
                          monthArrFR[rsudata3[0].getMonth()] +
                          "&nbsp;" +
                          rsudata3[0].getFullYear();


                  sspText =
                      selectedUICulture == "en-US" ?
                          "The value shown is based on three sets of share grants: " +
                          rsudata1[2] + " shares at a grant price of " + fmtCurrency(rsudata1[1], 2) + " on " + rsudata1[0] + ", "
                          + rsudata2[2] + " shares at a grant price of " + fmtCurrency(rsudata2[1], 2) + " on " + rsudata2[0] + " and "
                          + rsudata3[2] + " shares at a grant price of " + fmtCurrency(rsudata3[1], 2) + " on " + rsudata3[0] + "."
                          : "La valeur indiquée est calculée sur la base de trois octrois  : " +
                          rsudata1[2] + " actions au cours de l’action de " + fmtCurrency(rsudata1[1], 2) + " au " + rsudata1[0] + ", "
                          + rsudata2[2] + " actions au cours de l’action de " + fmtCurrency(rsudata2[1], 2) + " au " + rsudata2[0] + " et "
                          + rsudata3[2] + " actions au cours de l’action de " + fmtCurrency(rsudata3[1], 2) + " au " + rsudata3[0] + "."
              }
              else {
                  sspText = selectedUICulture == "en-US" ? "The value shown is based on two sets of share grants: " +
                      rsudata1[2] + " shares at a grant price of " + fmtCurrency(rsudata1[1], 2) +  " on " + rsudata1[0] + " and " +
                      rsudata2[2] + " shares at a grant price of " + fmtCurrency(rsudata2[1], 2) + " on " + rsudata2[0] + "."
                      : "La valeur indiquée est calculée sur la base de deux octrois : " +
                      rsudata1[2] + " actions au cours de l’action de " + fmtCurrency(rsudata1[1], 2) +" au " + rsudata1[0] + " et " +
                      rsudata2[2] + " actions au cours de l’action de " + fmtCurrency(rsudata2[1], 2) + " au " + rsudata2[0] +"."
               }





            if (selectedUICulture == "en-US") {
              return (
                  "You were granted Restricted Stock Unit (RSU) awards under the Special Stock Program." +
                  sspText +
                "The values have been converted to Canadian dollars and combined for this statement. <a href='https://www.netbenefits.com' target=&quot;_blank&quot;>Log in to your Fidelity account</a> for more information."
              );
            } else {
                return (
                "Vous avez reçu une récompense en unités d’actions subalternes (UAS) assujettie à des restrictions dans le cadre du Régime d’actionnariat spécial." + sspText +
                "les montants ont été convertis en dollars canadiens et combinés sur le présent relevé. <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir plus."
              );
            }
          } else {
            var single_rsudata = document.getElementById("Glance2").innerHTML;
            if (single_rsudata != "0") {
              if (selectedUICulture == "en-US") {
                return (
                  "You were granted a Restricted Stock Unit (RSU) award under the Special Stock Program. The value shown is based on a stock price of " +
                  fmtCurrency(document.getElementById("PData13").innerHTML, 2) +
                  " on " +
                  monthArr[
                    parseInt(
                      document
                        .getElementById("PData14")
                        .innerHTML.split("-")[1],
                    ) - 1
                  ] +
                  " " +
                  parseInt(
                    document.getElementById("PData14").innerHTML.split("-")[2],
                  ) +
                  ", " +
                  document.getElementById("PData14").innerHTML.split("-")[0] +
                  " and converted to Canadian dollars. <a href='https://www.netbenefits.com' target=&quot;_blank&quot;>Log in to your Fidelity account</a> for more information."
                );
              } else {
                return (
                  "Vous avez reçu une récompense en unités d’actions subalternes (UAS) assujettie à des restrictions dans le cadre du régime d’actionnariat spécial. Ces unités vous sont acquises à raison de 20 % par année pendant cinq ans. La valeur indiquée est basée sur le prix de l’action de " +
                  fmtCurrency(document.getElementById("PData13").innerHTML, 2) +
                  " au " +
                  parseInt(
                    document.getElementById("PData14").innerHTML.split("-")[2],
                  ) +
                  "&nbsp;" +
                  monthArrFR[
                    parseInt(
                      document
                        .getElementById("PData14")
                        .innerHTML.split("-")[1],
                    ) - 1
                  ] +
                  "&nbsp;" +
                  document.getElementById("PData14").innerHTML.split("-")[0] +
                  " (converti en dollars canadiens)" +
                  ". <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir plus."
                );
              }
            }
          }
        } else if ($(this).attr("id") == "spanlabel11a") {
          if (selectedUICulture == "en-US") {
            return (
              "You were granted a Restricted Stock Unit (RSU) award under the Enhanced Vesting Special Stock Program. The value shown is based on a stock price of " +
              fmtCurrency($("#PData27").text(), 2) +
              " and converted to Canadian dollars. <a href=https://www.netbenefits.com target=_blank>Log in to your Fidelity account</a> for more information."
            );
          } else {
            return (
              "Vous avez reçu une récompense en unités d’action assujetties à des restrictions (RSU) dans le cadre du Régime d’actionnariat spécial à acquisition bonifiée. La valeur indiquée est basée sur un cours de l’action de " +
              fmtCurrency($("#PData27").text(), 2) +
              " (montant converti en dollars canadiens).<a href=https://www.netbenefits.com target=_blank>Consultez votre compte Fidelity en ligne</a> pour en savoir plus."
            );
          }
        } else if ($(this).attr("id") == "spanlabel12") {
          if (selectedUICulture == "en-US") {
            return (
              "You were allocated " +
              document.getElementById("Glance3").innerHTML +
              " Performance Share Units (PSUs) under the Leadership Performance Program. The final amount of PSUs earned will be based on cumulative earnings per share over the three-year performance period and can range from 0% to 200% of the award amount. <a href='https://www.netbenefits.com' target='_blank'>Log in to your Fidelity account</a> for more information."
            );
          } else {
            return (
              "Vous avez reçu " +
              document.getElementById("Glance3").innerHTML +
              " unités d’actions subalternes (UAS) dans le cadre du Programme de rendement des dirigeants. La valeur définitive de cet octroi dépendra des gains par action réalisés durant la période de rendement de trois ans; elle peut varier de 0 % à 200 % du montant octroyé. <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir plus."
            );
          }
        } else if ($(this).attr("id") == "spanlabel3a") {
          if (selectedUICulture == "en-US") {
            return (
              "<p class='QII'>Your most recent quarterly incentive award of " +
              fmtCurrency($("#PData23").text(), 0) +
              " for your valued contributions and your continued commitment to our clients, our colleagues and our firm (paid in cash) is included in Variable pay above.</p>"
            );
          } else {
            return (
              "<p class='QII'>Votre plus récente prime incitative trimestrielle liée " +
              fmtCurrency($("#PData23").text(), 0) +
              " à votre précieuse contribution et à votre engagement continu envers nos clients, nos collègues et notre entreprise (payée en espèces).</p>"
            ); //"Vous avez reçu une récompense en unités d’actions subalternes (UAS) assujettie à des restrictions au titre du Régime d’actionnariat incitatif d’Aon. Ces unités remplacent une partie de votre rémunération incitative annuelle, et vous sont acquises à raison de 33 % par année pendant trois ans. La valeur indiquée est basée sur le prix de l’action de " + fmtCurrency(document.getElementById('PData12').innerHTML,2) + " (converti en dollars CA) au " + parseInt(document.getElementById('PData11').innerHTML.split("-")[2]) + "&nbsp;" + monthArrFR[parseInt(document.getElementById('PData11').innerHTML.split("-")[1]) - 1] + "&nbsp;" + document.getElementById('PData11').innerHTML.split("-")[0] + ". <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir plus.";
          }
        } else if ($(this).attr("id") == "spanlabel3b") {
          if (selectedUICulture == "en-US") {
            return (
              "<p class='QII2'>Future quarterly incentive award through the installment period ending in January 2025 is valued at " +
              fmtCurrency($("#PData24").text()) +
              "."
            );
          } else {
            return (
              "<p class='QII2'>Valeur future de la prime incitative trimestrielle d’ici la fin de la période de versement, soit d’ici janvier 2025 " +
              fmtCurrency($("#PData24").text()) +
              "."
            ); //"Vous avez reçu une récompense en unités d’actions subalternes (UAS) assujettie à des restrictions au titre du Régime d’actionnariat incitatif d’Aon. Ces unités remplacent une partie de votre rémunération incitative annuelle, et vous sont acquises à raison de 33 % par année pendant trois ans. La valeur indiquée est basée sur le prix de l’action de " + fmtCurrency(document.getElementById('PData12').innerHTML,2) + " (converti en dollars CA) au " + parseInt(document.getElementById('PData11').innerHTML.split("-")[2]) + "&nbsp;" + monthArrFR[parseInt(document.getElementById('PData11').innerHTML.split("-")[1]) - 1] + "&nbsp;" + document.getElementById('PData11').innerHTML.split("-")[0] + ". <a href='https://www.netbenefits.com' target='_blank'>Consultez votre compte Fidelity en ligne</a> pour en savoir plus.";
          }
        } else {
          return $(this).attr("qtipcontent");
        }
      },
      title: function (event, api) {
        return $(this).attr("qtip-title");
      },
      button: "Close",
    },
    show: {
      solo: $(".container"),
    },
    style: {
      classes: "qtip-rounded",
    },
    position: {
      my: "left center", // Position my top left...
      at: "center right", // at the bottom right of...
      adjust: {
        x: 20,
      },
    },
    hide: false,
    show: "click",
  });
  $(".PData24").text($("#PData24").text());
  $(".PData23").text($("#PData23").text());
  //   if ($("#PData23").text() == "0") {
  //     $("#row3a,#row3b").hide();
  //   }
   
  // if(isRecruit==0){document.getElementById("clicktext").innerHTML = (selectedUICulture=="en-US")?  " (click for more details)" : " (cliquez pour en savoir plus)" }
  // }

  // if(document.getElementById("userlang").value=="F")
  // {document.getElementById("A1").style.display="none";document.getElementById("space").style.display="block";}
}

/************************************rewards.html JS End*****************************************/

/************************************cost-sharing.html JS Start*****************************************/

function OnCostSharingPageLoad() {
  GetServiceData();
  // var scriptSrc = GetResourceStringVal("CED.AonCanada.FormatsJS");
  // console.log("scriptSrc", scriptSrc);

  var loadAllContents = [
    loadContent("header", "header.html"),
    //    loadScript(scriptSrc),
  ];
  Promise.all(loadAllContents)
    .then((message) => {
      loadResourceString();
      SetCommonVar();

      if (parseInt($("#Sav5").text()) > 0) {
        //var sav6data = parseInt($("#Sav6").text());
        var pData28data = parseInt($("#PData28").text());
        var subtot_erCoreData =
          parseFloat($("#subtot_erCore").text()) == 0
            ? ""
            : fmtCurrency($("#subtot_erCore").text(), 0);
        var EGIB_qContent = "";

        if (pData28data < 70) {
          EGIB_qContent =
            selectedUICulture == "en-US"
              ? "This includes Medical, Dental, Basic Employee Life Insurance, Basic Accidental Death and Dismemberment and Long-Term Disability."
              : "Comprennent les garanties soins médicaux et soins dentaires, l’assurance-vie de base, l’assurance en cas de décès et mutilation accidentels (DMA), ainsi que l’assurance invalidité de longue durée.";
        } else {
          EGIB_qContent =
            selectedUICulture == "en-US"
              ? "This includes your Medical, and Dental plans."
              : "Comprennent vos garanties soins médicaux et soins dentaires.";
        }

        $("#subtot_erCore_2").text(subtot_erCoreData);
        //$("#ExecGpInsBen").attr("qtipcontent",EGIB_qContent)
        $("#spanlabel45").attr("qtipcontent", EGIB_qContent);
        //$("#Tbl_ExecGpInsBen_head").show();
        $("#row45").show();
      } else {
        $("#row45").hide();
        //$("#Tbl_ExecGpInsBen_head").hide();
      }

       
      if (isRecruit == 0) {
        if (parseFloat(document.getElementById("Sav6").innerHTML) > 0) {
          if (selectedUICulture == "en-US") {
            $("#spanlabel51").html("Optional Life Insurance");
            $("#spanlabel51").attr("qtip-title", "Optional Life Insurance");
          } else {
            $("#spanlabel51").html("Assurance-vie facultative ");
            $("#spanlabel51").attr("qtip-title", "Assurance-vie facultative ");
          }
        }
      }
      if (isRecruit == 1) {
        $("#spanlabel50,#spanlabel51,#spanlabel52").removeAttr("qtipcontent");
        $("#spanlabel50,#spanlabel51,#spanlabel52").removeAttr("qtip-title");
        $("#spanlabel50,#spanlabel51,#spanlabel52").css(
          "text-decoration",
          "none",
        );
        $("#spanlabel50,#spanlabel51,#spanlabel52").css("cursor", "text");
        $("#tbl_Reservehead,#tbl_Reserve").hide();
        $(".active_2,.active_3,.recruit_2").remove();
      } else {
        $(".recruit_5").remove();
      }

      if ($("#Glance9").text() == "0") {
        $("#businesstravel").hide();
      }
      $("#sitecover").css("visibility", "visible");
      CheckCostSharingData();
    })
    .catch((error) => {
      console.error(
        "Method: OnCostSharingPageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

function CheckCostSharingData() {
  //  if (document.getElementById("EmpID").innerHTML == "99999999" || document.getElementById("EmpID").innerHTML == "88888888") {

  if (
    !document.getElementById("EmpID") ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "99999999"
  ) {
    //document.getElementById("regtables").innerHTML="";
    robSwitches();
    loadPageRecruiting();
  } else if (document.getElementById("optGlance20") != null) {
    //Custom

    if (isRecruit == 1) {
      robSwitches();
      document.getElementById("tagLine2").innerHTML =
        "Group insurance benefit costs shown are annualized values based on your elections, and employment information as of time of hire. All other values are annual estimates for the calendar year based on your elections and status.";
    }
    loadPage();

    document.getElementById("row56").style.display =
      parseInt(document.getElementById("PData20").innerHTML) > 0 ? "" : "none";

    var critcov = document.getElementById("BusUnit").innerHTML;
    var lifecov = document.getElementById("EmpGroup").innerHTML; //formerly EmpGroup
    var addcov = document.getElementById("EmpType").innerHTML; //formerly EmpType
    var crittext = "";
    var lifetext = "";
    var addtext = "";

    eval(
      "switch(critcov){ " +
        GetResourceStringVal("CED.AonCanada.CostSharing.SwitchCritCov") +
        ";}",
    );

    eval(
      "switch(lifecov){ " +
        GetResourceStringVal("CED.AonCanada.CostSharing.SwitchLifeCov") +
        ";}",
    );

    eval(
      "switch(addcov){ " +
        GetResourceStringVal("CED.AonCanada.CostSharing.AddCov") +
        ";}",
    );

    loadflag = 1;
  }

  // if(newSS==false){
  $("span[qtipcontent]").qtip({
    content: {
      text: function (event, api) {
        if (isRecruit == 1) {
          var tmp = $(this).html().replace(" as of April 30, 2022", "");
          $(this).html(tmp);
          var tmp = $(this).html().replace(" as at April 30, 2022", "");
          $(this).html(tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" as of April 30, 2022", "");
          $(this).attr("qtipcontent", tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" as at April 30, 2022", "");
          $(this).attr("qtipcontent", tmp);
          var tmp = $(this)
            .attr("qtip-title")
            .replace(" as of April 30, 2022", "");
          $(this).attr("qtip-title", tmp);
          var tmp = $(this)
            .attr("qtip-title")
            .replace(" as at April 30, 2022", "");
          $(this).attr("qtip-title", tmp);

          var tmp = $(this)
            .attr("qtip-title")
            .replace(" on your April 30, 2022", " on your");
          $(this).attr("qtip-title", tmp);
          var tmp = $(this)
            .attr("qtipcontent")
            .replace(" on your April 30, 2022", " on your");
          $(this).attr("qtipcontent", tmp);

          var tmp = $(this)
            .attr("qtipcontent")
            .replace("2022 contributions", "contributions");
          $(this).attr("qtipcontent", tmp);
        }
        // console.log("lifetext",lifetext)
        // if ($(this).attr("id") == "spanlabel50") {
        //   return GetResourceStringVal(
        //     "CED.AonCanada.CostSharing.spanlabel50.Qtip",
        //   ); //+
          //crittext +
          //"."
        //  } else 
        if($(this).attr("id") == "spanlabel51") {
          return (
            GetResourceStringVal("CED.AonCanada.CostSharing.spanlabel50.Qtip") +
            lifetext +
            "."
          );
        } else if ($(this).attr("id") == "spanlabel52") {
          return (
            GetResourceStringVal("CED.AonCanada.CostSharing.spanlabel52.Qtip") +
            addtext +
            "."
          );
        } else {
          return $(this).attr("qtipcontent");
        }
      },
      title: function (event, api) {
        return $(this).attr("qtip-title");
      },
      button: "Close",
    },
    show: {
      solo: $(".container"),
    },
    style: {
      classes: "qtip-rounded",
    },
    position: {
      my: "left center", // Position my top left...
      at: "center right", // at the bottom right of...
      adjust: {
        x: 20,
      },
    },
    hide: false,
    show: "click",
  });
}
/************************************cost-sharing.html JS End*****************************************/

/************************************coverage.html JS Start*****************************************/

function OnCoveragePageLoad() {
  GetServiceData();
  // var scriptSrc = GetResourceStringVal("CED.AonCanada.FormatsJS");
  // console.log("scriptSrc", scriptSrc);

  var loadAllContents = [
    loadContent("header", "header.html"),
    //    loadScript(scriptSrc),
  ];
  Promise.all(loadAllContents)
    .then((message) => {
      loadResourceString();
      SetCommonVar();
      //SetVariable();
      $("#sitecover").css("visibility", "visible");
      CheckCoverageData();
    })
    .catch((error) => {
      console.error(
        "Method: OnCoveragePageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

function CheckCoverageData() {
  //  if (document.getElementById("EmpID").innerHTML == "99999999" || document.getElementById("EmpID").innerHTML == "88888888") {

  if (
    !document.getElementById("EmpID") ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "99999999"
  ) {
    robSwitches();
    loadPageRecruiting();
  } else if (document.getElementById("optGlance20") != null) {
    //Custom

    if (isRecruit == 1) {
      robSwitches();
      document.getElementById("tagLine2").innerHTML =
        "Group insurance benefit costs shown are annualized values based on your elections, and employment information as of time of hire. All other values are annual estimates for the calendar year based on your elections and status.";
    }
    loadPage();

    if ($("#PData26").text() == "Y") {
      $(".message1").text(GetResourceStringVal("CED.AONCANADA.Message1"));
      // if (selectedUICulture == "en-US") {
      //     $(".message1").text("You are missing out on the maximum company match by contributing less than 4% of your annual base salary to the Basic Defined Contribution Pension Plan. To accumulate more toward your retirement, consider increasing your Basic Defined Contribution Pension Plan contribution at your next enrolment.")
      // } else {
      //     $(".message1").text("Vous ne profitez pas de la contrepartie maximale de l’entreprise, car vous cotisez moins de 4 % de votre salaire de base annuel au régime de retraite à cotisations déterminées de base. Pour accumuler plus d’argent pour votre retraite, à votre prochaine adhésion, songez à augmenter votre cotisation au régime de retraite à cotisations déterminées de base.")
      // }
    } else {
      $(".message1").hide();
    }

    if ($("#PData25").text() == "Y") {
      $(".message2").text(GetResourceStringVal("CED.AONCANADA.Message2"));
      // if (selectedUICulture == "en-US") {
      //     $(".message2").text("Because you’re contributing less than 3% of your annual base salary to the Voluntary Plan(s), you are not receiving the full company match. By increasing your contribution to 3% you’ll get your maximum match from Aon.")
      // } else {
      // $(".message2").text("Parce que vous cotisez moins de 3 % de votre salaire de base annuel au(x) régime(s) à cotisations facultatives, vous ne recevez pas la totalité de la contrepartie de l’entreprise. En augmentant votre cotisation à 3 %, vous obtiendrez la contrepartie maximale d’Aon.")
      // }
    } else {
      $(".message2").hide();
    }

    if ($("#PData25").text() != "Y" && $("#PData26").text() != "Y") {
      $("#coveragemsgs").hide();
    }

    loadflag = 1;
  }
}

/************************************coverage.html JS End*****************************************/

/************************************print.html JS Start*****************************************/

function GetServiceDataForWindowOpener() {
  console.log("called inside GetServiceDataForWindowOpener");
  var serviceData;
  var token = window.opener.sessionStorage.token;
  if (token != null && token != "") {
    if (IsTokenExpired(token)) {
      if (RefreshTokenForWindowOpener()) {
        token = window.opener.sessionStorage.token;
      }
    }
    jQuery.ajax({
      type: "POST",
      headers: {
        Authorization: "Bearer " + token,
      },
      url: webApiRootUrl + "/Login/GetEmpServiceData",
      data: {},
      contentType: "application/json; charset=utf-8",
      dataType: "text",
      cache: false,
      async: false,
      success: function (result) {
        console.log(result);
        serviceData = result;
        if (serviceData != null) {
          RefreshTokenForWindowOpener();
        }
      },
      error: function (error) {
        if ((error.status = 401)) {
          window.location.href = "session-timeout.html";
        } else {
          console.error(
            "state: " + error.state,
            "; Status:" + error.status,
            "; Response Text: " + error.responseText,
          );
        }
      },
    });
  } else {
    console.error("Empty token");
    window.location.href = "session-timeout.html";
  }
  $("#InputData_nwsdbd").html(serviceData);
  console.log("GetServiceData completed");
  return serviceData;
}

function RefreshTokenForWindowOpener(asyncFlag = false) {
  var IsTokenRefreshed = false;
  var accessToken = window.opener.sessionStorage.token;
  var refreshToken = window.opener.sessionStorage.refreshToken;
  console.log("refresh token called.");
  jQuery.ajax({
    type: "POST",
    url: webApiRootUrl + "/Login/RefreshToken",
    headers: {
      Authorization: "Bearer " + accessToken,
      refreshToken: refreshToken,
    },
    data: {},
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    cache: false,
    async: asyncFlag,
    success: function (result) {
      //accessToken=newToken,refreshToken
      console.log(result);
      if (result.accessToken != null && result.refreshToken != null) {
        window.opener.sessionStorage.token = result.accessToken;
        window.opener.sessionStorage.refreshToken = result.refreshToken;
        // sessionStorage.setItem(sessionKey.Token,result.accessToken);
        // sessionStorage.setItem(sessionKey.RefreshToken,result.refreshToken);
        IsTokenRefreshed = true;
      } else {
        window.location.href = "session-timeout.html";
      }
    },
    error: function (error) {
      console.log(
        "state: " + error.state,
        "; Status:" + error.status,
        "; Response Text: " + error.responseText,
      );
    },
  });

  return IsTokenRefreshed;
}

function CheckPrintData() {
  if (
    (document.referrer.toLowerCase().indexOf("disclaimer") >= 0 &&
      !document.getElementById("EmpID")) ||
    location.search.indexOf("params=") >= 0 ||
    sessionStorage.getItem("data")
  ) {
    weAreComingFromAddNewScreen = true;
  } else {
    weAreComingFromAddNewScreen = false;
  }
  document.getElementById("nav").style.display = "none";
  //document.getElementById('footer').style.display = 'none';

  if (
    document.getElementById("EmpID").innerHTML == "99999999" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777"
  ) {
    document.getElementById("regtables").innerHTML = "";
    robSwitches();
    if (robPaidvac > 0) {
      $("#vacWeek").html(robPaidvac);
      $("#vacWeekText").show();
    } else {
      $("#vacWeekText").hide();
    } 

    document.getElementById("estLabel").innerHTML = GetResourceStringVal(
      "CED.AonCanada.Rewards.estLabel",
    );

    loadPageRecruiting();
    //document.getElementById("lifeworks").style.visibility = "hidden";
  } else if (document.getElementById("optGlance20") != null) {
    document.getElementById("recruitingtables").innerHTML = "";
    //document.getElementById("bluebox").style.border = "2px solid #0183a9";
    document.getElementById("article1").style.border = "1px solid #CCCCCC";
    //document.getElementById("recruitbanner").style.display = "none";
    //document.getElementById("spacer1").style.display = "none";
    //document.getElementById("spacer2").style.display = "none";
    //document.getElementById("center1").style.marginTop = "120px";
    //document.getElementById("article1").style.marginTop = "80px";

    if (isRecruit == 1) {
      robSwitches();
      document.getElementById("tagLine2").innerHTML =
        "Group insurance benefit costs shown are annualized values based on your elections, and employment information as of time of hire. All other values are annual estimates for the calendar year based on your elections and status.";
    }
    loadPage();
    if ($("#Glance9").text() == "0") {
      $("#shortterm").hide();
    }
  }

  if (selectedUICulture == "fr-CA") {
    $("#article8").css("height", "460px");
    $("#article8 h2.twoline").css("max-width", "66%");
    $("#article8 h2.twoline").css("margin-bottom", "2rem");
    if ($("#pageID").val() != "P") {
      $("#article11").css("margin-top", "-122px");
    }
    $("#article1 h2, #article3 h2").css("line-height", "18px");
    // $("article p.callout img").css("margin-top","-1rem")
    $("#article8 p.callout img").css("margin-top", "-2rem");
    $(
      "#article10 p.callout img,#article22 p.callout img,#article24 p.callout img",
    ).css("margin-top", "0rem");
  }

  eval(GetResourceStringVal("CED.AonCanada.Print.Pay65"));
}

function OnPrintPageLoad() {
  sessionStorage.clear();
  GetServiceDataForWindowOpener();

  // var scriptSrc = GetResourceStringVal("CED.AonCanada.FormatsJS");
  // console.log("scriptSrc", scriptSrc);

  var loadAllContents = [
    loadContent("header", "header.html"),
    //    loadScript(scriptSrc),
  ];
  Promise.all(loadAllContents)
    .then((message) => {
      sessionStorage.setItem(
        sessionKey.LangCode,
        window.opener.sessionStorage.langCode,
      );
      loadResourceString();
      SetCommonVar();
      selectedUICulture = window.opener.selectedUICulture;
      document.getElementById("row22").style.display = "none";
      if (document.getElementById("tbl_Reserveheadz")) {
        document.getElementById("tbl_Reserveheadz").style.display = "none";
      }
      if (document.getElementById("tbl_Reservehead")) {
        // document.getElementById("tbl_Reservehead").style.display = "none";
      }

      document.getElementById("row56").style.display = "none";
      //document.getElementById("tbl_Reservehead2").style.display=document.getElementById("tbl_Reservehead").style.display;

      //document.getElementById("greeting2").innerHTML = document.getElementById("greeting").innerHTML;
      document.getElementById("printButton").style.display = "block";
      document.getElementById("greeting").style.display = "none";

      showReferalAward();
      $("#OGPEL_Cov td:last a").hide();

      if (parseInt(document.getElementById("PData22").innerHTML) == 0) {
        $(".growthcallout").removeClass("d-flex");
        $(".growthcallout").addClass("d-none");
      }
      if (isRecruit == 1) {
        $("#article1, .coveragesummary, .welldate").hide();
        $(".growthcallout,#addressbox").removeClass("d-flex");
        $(".growthcallout,#addressbox").addClass("d-none");
        $("#article2,#article3").css("width", "38%");
        // $("#addressbox").css("visibility","hidden");
        $(
          "#article1 p.callout,#article2 p.callout,#article3 p.callout",
        ).removeClass("px-0");
        $(
          "#article1 p.callout img,#article2 p.callout img,#article3 p.callout img",
        ).addClass("mt-2");
        $(
          ".active_1, .active_2, .active_3, .active_4, .active_5, .active_6, .active_7, .active_8, .active_10, .active_11, .recruit_2",
        ).remove();
        $("#tbl_Reservehead,#tbl_Reserve").hide();
        if (selectedUICulture == "en-US") {
          $("#bpintro").html(
            "Premier continually explores ways to bring meaningful colleague offerings and creative partnerships to our colleagues. Discover all the programs and local discounts that would be available to you as being part of a global organization.",
          );
        } else {
          $("#bpintro").html(
            "Premier s'efforce constamment de soumettre à ses collègues des propositions intéressantes et des partenariats novateurs. Découvrez tous les programmes et rabais locaux dont vous pourriez profiter en tant que membre d'une organisation mondiale.",
          );
        }
        $("#covtable,#covtablebreak").hide();
      } else {
        $(".recruit_1,.recruit_3,.recruit_4,.recruit_5").remove();
      }
      $("#mednote").parent("p").remove();
      //console.log($( "#mednote" ).parent().get( 0 ).tagName)
      if (selectedUICulture == "en-US") {
        document.getElementById("vacf1").innerHTML = format(
          document.getElementById("PData17").innerHTML,
          2,
        );
      } else {
        document.getElementById("vacf1").innerHTML = format(
          document.getElementById("PData17").innerHTML,
          2,
        ).replace(".", ",");
      }
      document.getElementById("vacf2").innerHTML =
        document.getElementById("PData18").innerHTML;
      document.getElementById("spanFlex3").style.visibility = "hidden";

      if ($("#PData26").text() == "Y") {
        if (selectedUICulture == "en-US") {
          $(".message1").text(
            "You are missing out on the maximum company match by contributing less than 4% of your annual base salary to the Basic Defined Contribution Pension Plan. To accumulate more toward your retirement, consider increasing your Basic Defined Contribution Pension Plan contribution at your next enrolment.",
          );
        } else {
          $(".message1").text(
            "Vous ne profitez pas de la contrepartie maximale de l’entreprise, car vous cotisez moins de 4 % de votre salaire de base annuel au régime de retraite à cotisations déterminées de base. Pour accumuler plus d’argent pour votre retraite, à votre prochaine adhésion, songez à augmenter votre cotisation au régime de retraite à cotisations déterminées de base.",
          );
        }
      } else {
        $(".message1").hide();
      }

      if ($("#PData25").text() == "Y") {
        if (selectedUICulture == "en-US") {
          $(".message2").text(
            "Because you’re contributing less than 3% of your annual base salary to the Voluntary Plans, you are not receiving the full company match. By increasing your contribution to 3% you’ll get your maximum match from Aon.",
          );
        } else {
          $(".message2").text(
            "Parce que vous cotisez moins de 3 % de votre salaire de base annuel au(x) régime(s) à cotisations facultatives, vous ne recevez pas la totalité de la contrepartie de l’entreprise. En augmentant votre cotisation à 3 %, vous obtiendrez la contrepartie maximale d’Aon.",
          );
        }
        $(".cool-box p").css("font-size", "9px");
      } else {
        $(".message2").hide();
      }

      if ($("#PData25").text() != "Y" && $("#PData26").text() != "Y") {
        $("#coveragemsgs").hide();
      }

      //   if ($("#PData23").text() == "0") {
      //     $("#row3a,#row3b").hide();
      //   }

      // if ($("#PData17").text() == "0") {
      //   $("#paidvacation").hide();
      // }

      if ($("#Glance9").text() == "0") {
        $("#businesstravel").hide();
        $("#shortterm").hide();
      }

      if (parseFloat(document.getElementById("Sav6").innerHTML) > 0) {
        if (selectedUICulture == "en-US") {
          $("#spanlabel51").html("Optional Life Insurance");
          $("#spanlabel51").attr("qtip-title", "Optional Life Insurance");
        } else {
          $("#spanlabel51").html("Assurance-vie facultative ");
          $("#spanlabel51").attr("qtip-title", "Assurance-vie facultative ");
        }
      }

      $("a:not(#printButton)").removeAttr("href");
      $("a:not(#printButton)").css("text-decoration", "none");
      $("a:not(#printButton)").css("pointer-events", "none");
      //$("a").css("color","black");
      $("a:not(#printButton)").css("cursor", "text");

      CheckPrintData();
    })
    .catch((error) => {
      console.error(
        "Method: OnPrintPageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

/************************************print.html JS End*****************************************/

/************************************bigger-picture.html JS Start*****************************************/

function OnBiggerPicturePageLoad() {
  GetServiceData();
  var loadAllContents = [loadContent("header", "header.html")];
  Promise.all(loadAllContents)
    .then((message) => {
      loadResourceString();
      SetCommonVar();
      CheckBiggerPictureData();
      if (isRecruit == 1) {
        $(".hideInRecruiterVer").hide();
        $("article a").removeAttr("href");

        $("#footer nav ul li:nth-child(3)").hide();
        $("#footer nav ul li:nth-child(5)").hide();
        $("#footer nav ul li:nth-child(6)").hide();
        $("#footer nav ul li:nth-child(7)").hide();
        $("#nav5").hide();
        $("#logoff").attr("href", "logout.html?isRecruiter=1");
        $(
          ".active_1, .active_2, .active_3, .active_4, .active_5, .active_6, .active_7, .active_8, .active_10, .active_11,.recruit_2",
        ).remove();

        if (selectedUICulture == "en-US") {
          $("#bpintro").html(
            "Premier continually explores ways to bring meaningful colleague offerings and creative partnerships to our colleagues. Discover all the programs and local discounts that would be available to you as being part of a global organization.",
          );
        } else {
          $("#bpintro").html(
            "Premier s'efforce constamment de soumettre à ses collègues des propositions intéressantes et des partenariats novateurs. Découvrez tous les programmes et rabais locaux dont vous pourriez profiter en tant que membre d'une organisation mondiale.",
          );
        }
      }

      if (selectedUICulture == "en-US") {
        //var h = isRecruit == 1 ? "1300px" : "1400px";
        $(".boxContainer").css("height", "1400px");
      } else {
        $(".boxContainer").css("height", "1800px");
      }
    })
    .catch((error) => {
      console.error(
        "Method: OnCoveragePageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

function CheckBiggerPictureData() {
  if (
    !document.getElementById("EmpID") ||
    document.getElementById("EmpID").innerHTML == "66666666" ||
    document.getElementById("EmpID").innerHTML == "77777777" ||
    document.getElementById("EmpID").innerHTML == "88888888" ||
    document.getElementById("EmpID").innerHTML == "99999999"
  ) {
    robSwitches();
    loadPageRecruiting();
    // document.getElementById("lifeworks").style.visibility="hidden";
  } else if (document.getElementById("optGlance20") != null) {
    if (isRecruit == 1) {
      robSwitches();
    }
    loadPage();
    $("#footerL1").css("display", "");
    $("#footerL2").css("border-right", "1px solid #626469");
  }
}

/************************************bigger-picture.html JS End*****************************************/

/************************************personal.html JS Start*****************************************/

function OnPersonalPageLoad() {
  GetServiceData();
  var loadAllContents = [loadContent("header", "header.html")];
  Promise.all(loadAllContents)
    .then((message) => {
      loadResourceString();
      SetCommonVar();
      $("#sitecover").css("visibility", "visible");
      CheckPersonalData();
    })
    .catch((error) => {
      console.error(
        "Method: OnPersonalPageLoad:: Error loading one or more contents:",
        error,
      );
    });
}

function CheckPersonalData() {
  if (
    !document.getElementById("EmpID") ||
    document.getElementById("EmpID").innerHTML == "99999999" ||
    document.getElementById("EmpID").innerHTML == "88888888"
  ) {
    robSwitches();
    loadPageRecruiting();
    console.log("recruiting code");
  } else if (document.getElementById("optGlance20") != null) {
    loadPage();

    var prov = "";
    switch (document.getElementById("Province").innerHTML) {
      case "AB":
        prov = "Alberta";
        break;
      case "BC":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.BC");
      case "MB":
        prov = "Manitoba";
        break;
      case "NB":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.NB");
      case "NL":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.NL");
      case "NS":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.NS");
      case "ON":
        prov = "Ontario";
        break;
      case "QC":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.QC");
      case "SK":
        prov = "Saskatchewan";
        break;
      case "YT":
        prov = GetResourceStringVal("CED.AonCanada.PersonalData.YT");
    }

    var dohdate = new Date(document.getElementById("DOH").innerHTML);
    var dohMonthFR = "";
    for (var i = 0; i < 12; i++) {
      if (monthArr[dohdate.getMonth()] == monthArr[i]) {
        dohMonthFR = monthArrFR[i];
      }
    }

    var dobdate = new Date(document.getElementById("DOB").innerHTML);
    var dobMonthFR = "";
    for (var i = 0; i < 12; i++) {
      if (monthArr[dobdate.getMonth()] == monthArr[i]) {
        dobMonthFR = monthArrFR[i];
      }
    }

    document.getElementById("pd1").innerHTML =
      document.getElementById("FirstName").innerHTML +
      " " +
      document.getElementById("LastName").innerHTML;
    document.getElementById("pd2").innerHTML =
      document.getElementById("EmpID").innerHTML;

    document.getElementById("pd3").innerHTML = $("#Province").text();
    document.getElementById("pd4").innerHTML = eval(
      GetResourceStringVal("CED.AonCanada.PersonalData.Pd4"),
    );
  }
}

/************************************personal.html JS End*****************************************/
