function formatAMPM(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? "pm" : "am";
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? "0" + minutes : minutes;
  var strTime = hours + ":" + minutes + " " + ampm;
  return strTime;
}
function SaveScenario() {
  var d = new Date();
  str =
    monthArr[d.getMonth()] +
    " " +
    d.getDate() +
    ", " +
    d.getFullYear() +
    " - " +
    formatAMPM(d);
  var indx = "";
  var field1 = "";
  var field2 = "";
  var field3 = "";
  var field4 = "";
  var field5 = "";
  var field6 = "";
  var field7 = "";
  var field8 = "";
  var field9 = "";
  var field10 = "";
  var field11 = "";
  var paidvac = "";
  var field12 = "";
  var field13 = "";
  var field14 = "";
  var field15 = "";
  var field16 = "";
  var field17 = "";
  var field18 = "";
  var field19 = "";
  var field20 = "";
  var field21 = "";
  var field22 = "";
  var field23 = "";
  var field24 = "";
  var field25 = "";
  var field26 = "";
  var field27 = "";
  var field28 = "";
  var field29 = "";
  var field30 = "";
  var field31 = "";
  var field32 = "";
  var field33 = "";
  var field34 = "";
  var field35 = "";
  var field36 = "";
  var field37 = "";
  var hrAdmin = "";
  var busUnit = "";
  var dateCreated = str;
  var field38 = "";
  var field39 = "";
  var field40 = "";
  var field41 = "";

  var SSdata = "";
  var separator = ";";
  var startpos = "";
  var loc = "";

  startpos = location.search.indexOf("params=");
  if (startpos < 0) {
  } else {
    //alert(location.search);
    //loc=location.search;
    loc = decodeURIComponent(location.search);
    //alert(loc)
    startpos = loc.indexOf("params=") + 7;
    loc = loc.substring(startpos, loc.length);
    //alert(loc)
    //alert(loc.substring(0, loc.indexOf(";")))
    indx = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field1 = loc.substring(0, loc.indexOf(";")); //alert("robFname: " + robFname)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field2 = loc.substring(0, loc.indexOf(";")); //alert("robLname: " + robLname)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field4 = parseFloat(loc.substring(0, loc.indexOf(";"))); //alert("robProvince: " + robProvince)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field5 = parseFloat(loc.substring(0, loc.indexOf(";"))); //alert("robBusUnit: " + robBusUnit)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field6 = parseFloat(loc.substring(0, loc.indexOf(";"))); //alert("robEmpclass: " + robEmpclass)
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field9 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field10 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    paidvac = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field13 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field14 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field15 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field16 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field17 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field18 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field19 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field20 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field21 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field22 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field23 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field24 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field25 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field26 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field27 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field28 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field29 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field30 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field31 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field32 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field33 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field34 = parseFloat(loc.substring(0, loc.indexOf(";")));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field35 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field36 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    hrAdmin = "3";
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    busUnit = "ACICO";
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field37 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field38 = loc.substring(0, loc.indexOf(";"));
    startpos = loc.indexOf(";") + 1;
    loc = loc.substring(startpos, loc.length);
    field39 = loc.substring(0, loc.length); //startpos=loc.indexOf(";")+1;
    //loc=loc.substring(startpos,loc.length);
    //SSdata+=parseFloat(loc.substring(0,loc.indexOf(";")))+separator;
    //startpos=loc.indexOf(";")+1;
    //loc=loc.substring(startpos,loc.length);
    //SSdata+=loc.substring(0,loc.length-1); //note no parseFloat...
    //alert(field39);
    //alert(indx+";"+field1+";"+field2+";"+field4+";"+field5+";"+field6+";"+field9+";"+field10+";"+paidvac+";"+field13+";"+field14+";"+field15+";"+field16+";"+field17+";"+field18+";"+field19+";"+field20+";"+field21+";"+field22+";"+field23+";"+field24+";"+field25+";"+field26+";"+field27+";"+field28+";"+field29+";"+field30+";"+field31+";"+field32+";"+field33+";"+field34+";"+field35+";"+field36+";"+hrAdmin+";"+busUnit+";"+field37+";"+field38+";"+field39)
  }
  //alert(indx+";"+field1+";"+field2+";"+field4+";"+field5+";"+field6+";"+field9+";"+field10+";"+paidvac+";"+field13+";"+field14+";"+field15+";"+field16+";"+field17+";"+field18+";"+field19+";"+field20+";"+field21+";"+field22+";"+field23+";"+field24+";"+field25+";"+field26+";"+field27+";"+field28+";"+field29+";"+field30+";"+field31+";"+field32+";"+field33+";"+field34+";"+field35+";"+field36+";"+hrAdmin+";"+busUnit+";"+field37+";"+field38+";"+field39+";"+dateCreated);
  //alert(field39)

  ssObj = {
    indx: indx,
    field1: field1,
    field2: field2,
    field3: "",
    field4: field4,
    field5: field5,
    field6: field6,
    field7: field7,
    field8: field8,
    field9: field9,
    field10: field10,
    field11: "",
    paidvac: paidvac,
    field12: field39,
    field13: field13,
    field14: field14,
    field15: field15,
    field16: field16,
    field17: field17,
    field18: field18,
    field19: field19,
    field20: field20,
    field21: field21,
    field22: field22,
    field23: field23,
    field24: field24,
    field25: field25,
    field26: field26,
    field27: field27,
    field28: field28,
    field29: field29,
    field30: field30,
    field31: field31,
    field32: field32,
    field33: field33,
    field34: field34,
    field35: field35,
    field36: field36,
    field37: field37,
    field38: field38,
    field39: field39,
    field40: "",
    field41: "",
    field42: "",
    field43: "",
    field44: "",
    field45: "",
    field46: "",
    field47: "",
    field48: "",
    field49: "",
    field50: "",
    field51: "",
    field0: "",
    dateCreated: dateCreated,
  };
  ssObj = Object.fromEntries(
    Object.entries(ssObj).map(([key, value]) => [key, String(value)]),
  );
  HRP_SaveUpdateSaveScenarios(ssObj);
}

//  recruiting page js start

function openSection(secID) {
  document.getElementById(secID).style.backgroundColor = "#EFEFEF";
  document.getElementById(secID + "input").style.display = "";
  if (secID == "lti") {
    document.getElementById(secID + "Text").style.display = "none";
  }
  document.getElementById(secID + "cell").style.textAlign = "left";
  document.getElementById(secID + "link").style.color = "#000";
  document.getElementById(secID + "link").style.textDecoration = "none";
  if (secID == "ob") {
    document.getElementById("otherben").style.display = "none";
  }
  if (secID == "otc") {
    document.getElementById("onetime").style.display = "none";
  }
  if (secID == "oth") {
    document.getElementById("othercomp").style.display = "none";
  }
}
function closeSection(secID) {
  switch (secID) {
    case "lti":
      document.getElementById(secID + "input").style.display = "none";
      document.getElementById(secID).style.backgroundColor = "#FFF";
      document.getElementById(secID + "Text").innerHTML =
        document.getElementById("specialstock").checked == true &&
        document.getElementById("leadership").checked == true
          ? "SSP + LPP"
          : document.getElementById("specialstock").checked == true
            ? "SSP"
            : document.getElementById("leadership").checked == true
              ? "LPP"
              : "(none selected)";
      document.getElementById(secID + "Text").style.fontStyle =
        document.getElementById(secID + "Text").innerHTML == "(none selected)"
          ? "italic"
          : "normal";
      document.getElementById(secID + "Text").style.display = "";
      document.getElementById(secID + "cell").style.textAlign = "right";
      document.getElementById(secID + "link").style.color = "";
      document.getElementById(secID + "link").style.textDecoration =
        "underline";
      break;

    case "ob":
      document.getElementById(secID + "input").style.display = "none";
      document.getElementById(secID).style.backgroundColor = "#FFF";
      document.getElementById(secID + "cell").style.textAlign = "right";
      document.getElementById(secID + "link").style.color = "";
      document.getElementById(secID + "link").style.textDecoration =
        "underline";
      document.getElementById("otherben").style.display = "";

      break;

    case "otc":
      document.getElementById(secID + "input").style.display = "none";
      document.getElementById(secID).style.backgroundColor = "#FFF";
      document.getElementById(secID + "cell").style.textAlign = "right";
      document.getElementById(secID + "link").style.color = "";
      document.getElementById(secID + "link").style.textDecoration =
        "underline";
      document.getElementById("onetime").style.display = "";

      break;

    case "oth":
      document.getElementById(secID + "input").style.display = "none";
      document.getElementById(secID).style.backgroundColor = "#FFF";
      document.getElementById(secID + "cell").style.textAlign = "right";
      document.getElementById(secID + "link").style.color = "";
      document.getElementById(secID + "link").style.textDecoration =
        "underline";
      document.getElementById("othercomp").style.display = "";

      break;
  }
}

function showValues2(fld) {
  document.getElementById(fld.id).value = document.getElementById(
    "hdn" + fld.id.toUpperCase(),
  ).value;

  fld.focus();
  fld.select();
}

function updateValues2(fld, hdnFld, secID) {
  if (isNaN(fld.value)) {
    fld.value = 0;
  }
  hdnFld.value = fld.value;
  fld.value = fmtCurrency(fld.value, 0);
  addTotals(secID);
}

function addTotals(secID) {
  switch (secID) {
    case "otc":
      if (document.getElementById("hdnO1").value == "") {
        document.getElementById("hdnO1").value = 0;
      }
      if (document.getElementById("hdnO2").value == "") {
        document.getElementById("hdnO2").value = 0;
      }
      if (document.getElementById("hdnO3").value == "") {
        document.getElementById("hdnO3").value = 0;
      }
      if (document.getElementById("hdnO4").value == "") {
        document.getElementById("hdnO4").value = 0;
      }
      if (document.getElementById("hdnO5").value == "") {
        document.getElementById("hdnO5").value = 0;
      }
      if (document.getElementById("hdnO6").value == "") {
        document.getElementById("hdnO6").value = 0;
      }
      otctot =
        parseFloat(document.getElementById("hdnO1").value) +
        parseFloat(document.getElementById("hdnO2").value) +
        parseFloat(document.getElementById("hdnO3").value) +
        parseFloat(document.getElementById("hdnO4").value) +
        parseFloat(document.getElementById("hdnO5").value) +
        parseFloat(document.getElementById("hdnO6").value);
      if (isNaN(otctot)) {
        otctot = 0;
      }
      document.getElementById("otctotal").innerHTML = fmtCurrency(otctot, 0);
      break;

    case "oth":
      if (document.getElementById("hdnO7").value == "") {
        document.getElementById("hdnO7").value = 0;
      }
      if (document.getElementById("hdnO8").value == "") {
        document.getElementById("hdnO8").value = 0;
      }
      if (document.getElementById("hdnO9").value == "") {
        document.getElementById("hdnO9").value = 0;
      }
      if (document.getElementById("hdnO10").value == "") {
        document.getElementById("hdnO10").value = 0;
      }
      if (document.getElementById("hdnO11").value == "") {
        document.getElementById("hdnO11").value = 0;
      }
      if (document.getElementById("hdnO12").value == "") {
        document.getElementById("hdnO12").value = 0;
      }
      othtot =
        parseFloat(document.getElementById("hdnO7").value) +
        parseFloat(document.getElementById("hdnO8").value) +
        parseFloat(document.getElementById("hdnO9").value) +
        parseFloat(document.getElementById("hdnO10").value) +
        parseFloat(document.getElementById("hdnO11").value) +
        parseFloat(document.getElementById("hdnO12").value);
      if (isNaN(othtot)) {
        othtot = 0;
      }
      document.getElementById("othtotal").innerHTML = fmtCurrency(othtot, 0);
      break;
    case "ob":
      if (document.getElementById("hdnO13").value == "") {
        document.getElementById("hdnO13").value = 0;
      }
      if (document.getElementById("hdnO14").value == "") {
        document.getElementById("hdnO14").value = 0;
      }
      if (document.getElementById("hdnO15").value == "") {
        document.getElementById("hdnO15").value = 0;
      }
      if (document.getElementById("hdnO16").value == "") {
        document.getElementById("hdnO16").value = 0;
      }
      if (document.getElementById("hdnO17").value == "") {
        document.getElementById("hdnO17").value = 0;
      }
      if (document.getElementById("hdnO18").value == "") {
        document.getElementById("hdnO18").value = 0;
      }
      obtot =
        parseFloat(document.getElementById("hdnO13").value) +
        parseFloat(document.getElementById("hdnO14").value) +
        parseFloat(document.getElementById("hdnO15").value) +
        parseFloat(document.getElementById("hdnO16").value) +
        parseFloat(document.getElementById("hdnO17").value) +
        parseFloat(document.getElementById("hdnO18").value);
      if (isNaN(obtot)) {
        obtot = 0;
      }
      document.getElementById("obtotal").innerHTML = fmtCurrency(obtot, 0);
      break;
  }
}

function windup() {
  /*        document.getElementById("other1").value = document.getElementById("hdnO1").value
        document.getElementById("other2").value = document.getElementById("hdnO2").value
        document.getElementById("other3").value = document.getElementById("hdnO3").value
        document.getElementById("other4").value = document.getElementById("hdnO4").value
        document.getElementById("other5").value = document.getElementById("hdnO5").value
        document.getElementById("other6").value = document.getElementById("hdnO6").value
        document.getElementById("other7").value = document.getElementById("hdnO7").value
        document.getElementById("other8").value = document.getElementById("hdnO8").value
        document.getElementById("other9").value = document.getElementById("hdnO9").value
        document.getElementById("other10").value = document.getElementById("hdnO10").value
        document.getElementById("other11").value = document.getElementById("hdnO11").value
        document.getElementById("other12").value = document.getElementById("hdnO12").value
        document.getElementById("other13").value = document.getElementById("hdnO13").value
        document.getElementById("other14").value = document.getElementById("hdnO14").value
        document.getElementById("other15").value = document.getElementById("hdnO15").value
        document.getElementById("other16").value = document.getElementById("hdnO16").value
        document.getElementById("other17").value = document.getElementById("hdnO17").value
        document.getElementById("other18").value = document.getElementById("hdnO18").value
  */
  addTotals("otc");
  addTotals("oth");
  addTotals("ob");
  document.getElementById("onetime").value = fmtCurrency(otctot, 0);
  document.getElementById("othercomp").value = fmtCurrency(othtot, 0);
  document.getElementById("otherben").value = fmtCurrency(obtot, 0);
  //document.getElementById("otherDesc").value = document.getElementById("hdnDesc").value
  //document.getElementById("otherDesc2").value = document.getElementById("hdnDesc2").value

  //document.getElementById("othercomp.focus()
  //document.getElementById("othercomp.select()
}

function validKey(el, k, dec) {
  if (dec == true) {
    if (
      (k > 45 && k < 58 && event.shiftKey == false) ||
      (k > 95 && k < 106) ||
      ((k == 110 || k == 190) && el.value.indexOf(".") == -1) ||
      k == 8 ||
      k == 9 ||
      (k > 34 && k < 41)
    ) {
      return true;
    } else {
      return false;
    }
  } else {
    if (
      (k > 45 && k < 58 && event.shiftKey == false) ||
      (k > 95 && k < 106) ||
      k == 8 ||
      k == 9 ||
      (k > 34 && k < 41)
    ) {
      return true;
    } else {
      return false;
    }
  }
}

function openWindow(file1, w, h, r, s) {
  var xc = screen.availWidth / 2;
  var yc = screen.availHeight / 2;
  window.open(
    file1,
    "",
    "left=" +
      (xc - w / 2) +
      ",top=" +
      (yc - h / 2) +
      ",width=" +
      w +
      ",height=" +
      h +
      ",resizable=" +
      r +
      ",scrollbars=" +
      s,
  );
}
function showValues(fld) {
  switch (fld.id) {
    case "salary":
      document.getElementById("salary").value =
        document.getElementById("hdnSal").value;
      break;
    case "bonus":
      document.getElementById("bonus").value =
        document.getElementById("hdnBonus").value;
      break;
  }
  fld.focus();
  fld.select();
}

function updateValues(fld, hdnFld) {
  hdnFld.value = fld.value;
  fld.value = fmtCurrency(fld.value, 0);
  document.getElementById("hdnDate").value = str;
}

/*  function storeData(){
document.getElementById("hdnOtherB1").value=document.getElementById("otherB1").value;

document.getElementById("hdnOtherB2").value=document.getElementById("otherB2").value;
document.getElementById("hdnOther1").value=document.getElementById("other1").value;
document.getElementById("hdnOther2").value=document.getElementById("other2").value;
document.getElementById("hdnOther3").value=document.getElementById("other3").value;
document.getElementById("hdnOther4").value=document.getElementById("other4").value;
document.getElementById("hdnOther5").value=document.getElementById("other5").value;
document.getElementById("hdnOther6").value=document.getElementById("other6").value;
document.getElementById("hdnOther7").value=document.getElementById("other7").value;
document.getElementById("hdnOther8").value=document.getElementById("other8").value;
document.getElementById("hdnOther9").value=document.getElementById("other9").value;
}
*/
function setBusUnit(param) {
  /* var sDisable=(document.getElementById("busUnit1").disabled==false)
  document.getElementById("busUnit1").disabled=false
  //debugger;
  param=param.toString()
  switch(param){
  case "ACICO": document.getElementById("busUnit1").selectedIndex=0;break;
  case "ADRCO": document.getElementById("busUnit1").selectedIndex=1;break;
  case "ARECO": document.getElementById("busUnit1").selectedIndex=0;break;
  case "ARSCO": document.getElementById("busUnit1").selectedIndex=3;break;
  case "ARSM1-PAR": document.getElementById("busUnit1").selectedIndex=4;break;
  case "KNKCO": document.getElementById("busUnit1").selectedIndex=5;break;
  case "MINET": document.getElementById("busUnit1").selectedIndex=6;break;
  case "HRTCO": document.getElementById("busUnit1").selectedIndex=7;break;
  case "HPCCO": document.getElementById("busUnit1").selectedIndex=8;break;
  case "IAOCO": document.getElementById("busUnit1").selectedIndex=9;break;
  case "USLCO": document.getElementById("busUnit1").selectedIndex=10;break;
  case "ARSM1": document.getElementById("busUnit1").selectedIndex=11;break;
  case "ARSM1-PAR": document.getElementById("busUnit1").selectedIndex=12;break;
  case "ARSM2": document.getElementById("busUnit1").selectedIndex=13;break;
  case "ARSOT": document.getElementById("busUnit1").selectedIndex=14;break;
  case "ARSPG": document.getElementById("busUnit1").selectedIndex=15;break;
  case "ARSRE": document.getElementById("busUnit1").selectedIndex=16;break;
  case "ARSSJ": document.getElementById("busUnit1").selectedIndex=17;break;
  case "ARSTB": document.getElementById("busUnit1").selectedIndex=18;break;
  case "ARSVI": document.getElementById("busUnit1").selectedIndex=19;break;
  case "ARSVR": document.getElementById("busUnit1").selectedIndex=20;break;
  case "ARSWG": document.getElementById("busUnit1").selectedIndex=21;break;
  case "ARSWH": document.getElementById("busUnit1").selectedIndex=22;break;
  case "CNWCO": document.getElementById("busUnit1").selectedIndex=23;break;
  case "KNKCO": document.getElementById("busUnit1").selectedIndex=24;break;
  case "MINET": document.getElementById("busUnit1").selectedIndex=25;break;
  case "HRTCO": document.getElementById("busUnit1").selectedIndex=26;break;
  case "HPCCO": document.getElementById("busUnit1").selectedIndex=27;break;
  }
  document.getElementById("busUnit1").disabled=!sDisable */
}

function loadData() {
  //alert(existingSS)
  //alert(document.getElementById("field9").innerHTML)
  //stored data, hidden
  //alert(newSS)
  if (newSS == true) {
    robSwitches();
  }

  document.getElementById("hdnSal").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robSal
        : parseInt(document.getElementById("field9").innerHTML);
  document.getElementById("hdnBonus").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robBonus
        : parseInt(document.getElementById("field10").innerHTML);
  document.getElementById("hdnO1").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther1
        : parseInt(document.getElementById("field13").innerHTML);
  document.getElementById("hdnO2").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther2
        : parseInt(document.getElementById("field14").innerHTML);
  document.getElementById("hdnO3").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther3
        : parseInt(document.getElementById("field15").innerHTML);
  document.getElementById("hdnO4").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther4
        : parseInt(document.getElementById("field16").innerHTML);
  document.getElementById("hdnO5").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther5
        : parseInt(document.getElementById("field17").innerHTML);
  document.getElementById("hdnO6").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther6
        : parseInt(document.getElementById("field18").innerHTML);
  document.getElementById("otcDesc1").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robOtcdesc1
        : document.getElementById("field19").innerHTML;
  document.getElementById("otcDesc2").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robOtcdesc2
        : document.getElementById("field20").innerHTML;
  document.getElementById("hdnO7").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther7
        : parseInt(document.getElementById("field21").innerHTML);
  document.getElementById("hdnO8").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther8
        : parseInt(document.getElementById("field22").innerHTML);
  document.getElementById("hdnO9").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther9
        : parseInt(document.getElementById("field23").innerHTML);
  document.getElementById("hdnO10").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther10
        : parseInt(document.getElementById("field24").innerHTML);
  document.getElementById("hdnO11").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther11
        : parseInt(document.getElementById("field25").innerHTML);
  document.getElementById("hdnO12").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther12
        : parseInt(document.getElementById("field26").innerHTML);
  document.getElementById("othDesc1").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robOthdesc1
        : document.getElementById("field27").innerHTML;
  document.getElementById("othDesc2").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robOthdesc2
        : document.getElementById("field28").innerHTML;
  document.getElementById("hdnO13").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther13
        : parseInt(document.getElementById("field29").innerHTML);
  document.getElementById("hdnO14").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther14
        : parseInt(document.getElementById("field30").innerHTML);
  document.getElementById("hdnO15").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther15
        : parseInt(document.getElementById("field31").innerHTML);
  document.getElementById("hdnO16").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther16
        : parseInt(document.getElementById("field32").innerHTML);
  document.getElementById("hdnO17").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther17
        : parseInt(document.getElementById("field33").innerHTML);
  document.getElementById("hdnO18").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robOther18
        : parseInt(document.getElementById("field34").innerHTML);
  document.getElementById("obDesc1").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robObdesc1
        : document.getElementById("field35").innerHTML;
  document.getElementById("obDesc2").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robObdesc2
        : document.getElementById("field36").innerHTML;

  document.getElementById("hdnCov").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? robSOF
        : parseInt(document.getElementById("field12").innerHTML);
  //alert(document.getElementById("hdnCov").value)
  //if(existingSS==true){alert(document.getElementById("field12").innerHTML);}

  //screen output
  var intProv;
  //alert(existingSS)

  document.getElementById("fname").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robFname
        : document.getElementById("field1").innerHTML;
  document.getElementById("lname").value =
    existingSS == false && newSS == false
      ? ""
      : newSS == true
        ? robLname
        : document.getElementById("field2").innerHTML;
  document.getElementById("provinceInput").selectedIndex =
    existingSS == false && newSS == false
      ? 4
      : newSS == true
        ? parseInt(robProvince)
        : parseInt(document.getElementById("field4").innerHTML);
  if (existingSS == false && newSS == false) {
    document.getElementById("busUnit1").selectedIndex = 0;
  } else {
    document.getElementById("busUnit1").selectedIndex =
      newSS == true
        ? parseInt(robBusUnit)
        : document.getElementById("field5").innerHTML;
  }
  //if("single"=="single"){document.getElementsByName("r4")[0].checked=true}else if("single"=="singlekid"){document.getElementsByName("r4")[1].checked=true}else{document.getElementsByName("r4")[2].checked=true}
  document.getElementById("empclass").selectedIndex =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? parseInt(robEmpclass)
        : parseInt(document.getElementById("field6").innerHTML);
  document.getElementById("salary").value =
    existingSS == false && newSS == false
      ? fmtCurrency("0", 0)
      : newSS == true
        ? fmtCurrency(robSal, 0)
        : fmtCurrency(parseInt(document.getElementById("field9").innerHTML), 0);
  document.getElementById("bonus").value =
    existingSS == false && newSS == false
      ? fmtCurrency("0", 0)
      : newSS == true
        ? fmtCurrency(robBonus, 0)
        : fmtCurrency(
            parseInt(document.getElementById("field10").innerHTML),
            0,
          );
  // document.getElementById("paidVac").selectedIndex =
  //   existingSS == false && newSS == false
  //     ? 0
  //     : newSS == true
  //       ? parseInt(robPaidvac) - 1
  //       : parseInt(document.getElementById("paidvac").innerHTML) - 1;

  document.getElementById("paidVac").value =
    existingSS == false && newSS == false
      ? 0
      : newSS == true
        ? parseInt(robPaidvac)
        : parseInt(document.getElementById("paidvac").innerHTML);

  document.getElementById("onetime").value =
    existingSS == false && newSS == false
      ? fmtCurrency("0", 0)
      : newSS == true
        ? fmtCurrency(robOnetime, 0)
        : fmtCurrency(
            parseFloat(document.getElementById("hdnO1").value) +
              parseFloat(document.getElementById("hdnO2").value) +
              parseFloat(document.getElementById("hdnO3").value) +
              parseFloat(document.getElementById("hdnO4").value) +
              parseFloat(document.getElementById("hdnO5").value) +
              parseFloat(document.getElementById("hdnO6").value),
            0,
          );
  document.getElementById("othercomp").value =
    existingSS == false && newSS == false
      ? fmtCurrency("0", 0)
      : newSS == true
        ? fmtCurrency(robOthercomp, 0)
        : fmtCurrency(
            parseFloat(document.getElementById("hdnO7").value) +
              parseFloat(document.getElementById("hdnO8").value) +
              parseFloat(document.getElementById("hdnO9").value) +
              parseFloat(document.getElementById("hdnO10").value) +
              parseFloat(document.getElementById("hdnO11").value) +
              parseFloat(document.getElementById("hdnO12").value),
            0,
          );
  document.getElementById("ltiText").innerHTML =
    existingSS == false && newSS == false
      ? "(none selected)"
      : newSS == true
        ? robLTI
        : document.getElementById("field37").innerHTML;
  document.getElementById("otherben").value =
    existingSS == false && newSS == false
      ? fmtCurrency("0", 0)
      : newSS == true
        ? fmtCurrency(robOtherben, 0)
        : fmtCurrency(
            parseFloat(document.getElementById("hdnO13").value) +
              parseFloat(document.getElementById("hdnO14").value) +
              parseFloat(document.getElementById("hdnO15").value) +
              parseFloat(document.getElementById("hdnO16").value) +
              parseFloat(document.getElementById("hdnO17").value) +
              parseFloat(document.getElementById("hdnO18").value),
            0,
          );
  document.getElementById("o1").value = fmtCurrency(
    document.getElementById("hdnO1").value,
    0,
  );
  document.getElementById("o2").value = fmtCurrency(
    document.getElementById("hdnO2").value,
    0,
  );
  document.getElementById("o3").value = fmtCurrency(
    document.getElementById("hdnO3").value,
    0,
  );
  document.getElementById("o4").value = fmtCurrency(
    document.getElementById("hdnO4").value,
    0,
  );
  document.getElementById("o5").value = fmtCurrency(
    document.getElementById("hdnO5").value,
    0,
  );
  document.getElementById("o6").value = fmtCurrency(
    document.getElementById("hdnO6").value,
    0,
  );
  document.getElementById("o7").value = fmtCurrency(
    document.getElementById("hdnO7").value,
    0,
  );
  document.getElementById("o8").value = fmtCurrency(
    document.getElementById("hdnO8").value,
    0,
  );
  document.getElementById("o9").value = fmtCurrency(
    document.getElementById("hdnO9").value,
    0,
  );
  document.getElementById("o10").value = fmtCurrency(
    document.getElementById("hdnO10").value,
    0,
  );
  document.getElementById("o11").value = fmtCurrency(
    document.getElementById("hdnO11").value,
    0,
  );
  document.getElementById("o12").value = fmtCurrency(
    document.getElementById("hdnO12").value,
    0,
  );
  document.getElementById("o13").value = fmtCurrency(
    document.getElementById("hdnO13").value,
    0,
  );
  document.getElementById("o14").value = fmtCurrency(
    document.getElementById("hdnO14").value,
    0,
  );
  document.getElementById("o15").value = fmtCurrency(
    document.getElementById("hdnO15").value,
    0,
  );
  document.getElementById("o16").value = fmtCurrency(
    document.getElementById("hdnO16").value,
    0,
  );
  document.getElementById("o17").value = fmtCurrency(
    document.getElementById("hdnO17").value,
    0,
  );
  document.getElementById("o18").value = fmtCurrency(
    document.getElementById("hdnO18").value,
    0,
  );

  addTotals("otc");
  addTotals("oth");
  addTotals("ob");

  if (document.getElementById("ltiText").innerHTML == "SSPLPP") {
    document.getElementById("ltiText").style.fontStyle = "normal";
    document.getElementById("ltiText").innerHTML = "SSP + LPP";
    document.getElementById("specialstock").checked = true;
    document.getElementById("leadership").checked = true;
  } else if (document.getElementById("ltiText").innerHTML != "") {
    document.getElementById("ltiText").style.fontStyle = "normal";
    if (document.getElementById("ltiText").innerHTML == "SSP") {
      document.getElementById("specialstock").checked = true;
    } else if (document.getElementById("ltiText").innerHTML == "LPP") {
      document.getElementById("leadership").checked = true;
    }
  }

  if (document.getElementById("empclass").selectedIndex == 3) {
    document.getElementById("lti").style.display = "";
    document.getElementById("execmed").style.display = "";
  }

  var tmp = document.getElementsByName("r4"); //gets the actual radio button collection

  tmp[parseInt(document.getElementById("hdnCov").value)].checked = true; //sets the (hopefully) proper one

  /*		if(parseInt(document.getElementById("hdnCov").value)==0){
  tmp[0].checked = true;
  }else if(parseInt(document.getElementById("hdnCov").value)==1){
  tmp[1].checked = true;
  }else{
  tmp[2].checked = true;
  }
  */
}

function SubmitForm() {
  addTotals("otc");
  addTotals("oth");
  addTotals("ob");

  if (
    isNaN(document.getElementById("hdnSal").value) ||
    parseFloat(document.getElementById("hdnSal").value) == 0
  ) {
    alert("Salary cannot be" + GetResourceStringVal("CED.AonCanada.Zero.do"));
    return false;
  }
  var busU = document.getElementById("busUnit1").selectedIndex;
  var empClass = document.getElementById("empclass").selectedIndex;

  var tmp = document.getElementsByName("r4");
  var sof = tmp[0].checked == true ? "0" : tmp[1].checked == true ? "1" : "2";

  str = "";
  if (document.getElementById("indx")) {
    str += document.getElementById("indx").innerHTML + ";";
  } else {
    if (location.search.indexOf("params=") >= 0) {
      // var loc=location.search;
      var loc = decodeURIComponent(location.search);
      // startpos=location.search.indexOf("params=")+7
      startpos = loc.indexOf("params=") + 7;

      loc = loc.substring(startpos, loc.indexOf(";"));
      str += loc + ";";
    } else {
      str += "0;";
    }
  }
  str += document.getElementById("fname").value + ";";
  str += document.getElementById("lname").value + ";";
  str += document.getElementById("provinceInput").selectedIndex + ";";

  str += document.getElementById("busUnit1").selectedIndex + ";";

  str += document.getElementById("empclass").selectedIndex + ";";

  str += document.getElementById("hdnSal").value + ";";
  str += document.getElementById("hdnBonus").value + ";";
  str += document.getElementById("paidVac").value + ";";
  str += document.getElementById("hdnO1").value + ";";
  str += document.getElementById("hdnO2").value + ";";
  str += document.getElementById("hdnO3").value + ";";
  str += document.getElementById("hdnO4").value + ";";
  str += document.getElementById("hdnO5").value + ";";
  str += document.getElementById("hdnO6").value + ";";
  str += document.getElementById("otcDesc1").value + ";";
  str += document.getElementById("otcDesc2").value + ";";
  str += document.getElementById("hdnO7").value + ";";
  str += document.getElementById("hdnO8").value + ";";
  str += document.getElementById("hdnO9").value + ";";
  str += document.getElementById("hdnO10").value + ";";
  str += document.getElementById("hdnO11").value + ";";
  str += document.getElementById("hdnO12").value + ";";
  str += document.getElementById("othDesc1").value + ";";
  str += document.getElementById("othDesc2").value + ";";
  str += document.getElementById("hdnO13").value + ";";
  str += document.getElementById("hdnO14").value + ";";
  str += document.getElementById("hdnO15").value + ";";
  str += document.getElementById("hdnO16").value + ";";
  str += document.getElementById("hdnO17").value + ";";
  str += document.getElementById("hdnO18").value + ";";
  str += document.getElementById("obDesc1").value + ";";
  str += document.getElementById("obDesc2").value + ";";
  str += otctot + ";";
  str += othtot + ";";
  str +=
    (document.getElementById("specialstock").checked == true ? "SSP" : "") +
    (document.getElementById("leadership").checked == true ? "LPP" : "") +
    ";";
  str += obtot + ";";
  str += sof;
  //alert(str);
  // str=encodeURIComponent(str);
  //var url = "https://" + window.location.host;

  window.location.href =
    GetResourceStringVal("CED.AonCanada.window") + "?params=" + str;
}
