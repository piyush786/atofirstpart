(function () {
    if (location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') return;
    window.ATO_LOCAL_MOCK = true;
    document.addEventListener('DOMContentLoaded', function () {
        var note = document.createElement('aside');
        note.setAttribute('aria-label', 'Local preview');
        note.textContent = 'LOCAL MOCK · Any username/password · Any 6-digit code · Synthetic data and sample calculations';
        note.style.cssText = 'background:#fff3cd;color:#533f03;padding:10px 16px;text-align:center;font:14px/1.5 system-ui;border-bottom:1px solid #e5cb75;';
        document.body.prepend(note);
    });
})();
