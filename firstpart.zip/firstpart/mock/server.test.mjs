import test from 'node:test';
import assert from 'node:assert/strict';
import { once } from 'node:events';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { createServer } from './server.mjs';
import { employee, calculate } from './data.mjs';

test('local login, rewards, reset, refresh and logout work without real services', async t => {
  const server = createServer().listen(0, '127.0.0.1');
  await once(server, 'listening');
  t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}`;
  let cookie = '';
  async function api(action, data, token) {
    const response = await fetch(base + '/api/' + action, {
      method: data === undefined ? 'GET' : 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: cookie, ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: data === undefined ? undefined : JSON.stringify(data)
    });
    if (response.headers.get('set-cookie')) cookie = response.headers.get('set-cookie').split(';')[0];
    return { status: response.status, body: await response.json() };
  }
  const page = await (await fetch(base + '/logon.html')).text();
  assert.ok(page.indexOf('/mock/local.js') < page.indexOf('js/logon/login.js'));
  assert.match(await (await fetch(base + '/mock/local.js')).text(), /ATO_LOCAL_MOCK = true/);
  assert.equal((await api('Login/GetRewardsData')).status, 401);
  assert.equal((await api('Login/ValidateUsername', 'not-an-email')).body.status, true);
  assert.equal((await api('Login/GetLoginFlags', 'not-an-email')).body.isProfileComplete, true);
  assert.equal((await api('Login/ValidatePassword', { Password: 'x' })).body.status, true);
  assert.equal((await api('Login/GetLoginFlags', 'not-an-email')).body.hasOTP, true);
  assert.equal((await api('Login/ValidateAuthCode', { Code: '12' })).body.status, false);
  let tokens = (await api('Login/ValidateAuthCode', { Code: '987654' })).body;
  const rewards = await api('Login/GetRewardsData', undefined, tokens.token);
  assert.equal(JSON.parse(rewards.body.ssoData).input_data.input_FNAME, 'not-an-email');
  const calculated = await api('calculate', employee());
  assert.ok(calculated.body.output_ctotrewards > 100000);
  assert.equal((await api('Login/ResendCode', 'not-an-email')).body.status, true);
  assert.equal((await api('Login/ForgotPassword', 'not-an-email')).body.status, true);
  assert.equal((await api('Login/GetLoginFlags', 'not-an-email')).body.isResetPassword, true);
  tokens = (await api('Login/ResetPassword', { Password: 'new password' })).body;
  const refreshed = await api('Login/RefreshToken', { accessToken: tokens.token, refreshToken: tokens.refreshToken });
  assert.ok(refreshed.body.accessToken);
  assert.equal((await api('Login/GetRewardsData', undefined, tokens.token)).status, 401);
  assert.equal((await api('Login/GetRewardsData', undefined, refreshed.body.accessToken)).status, 200);
  assert.equal((await api('Login/DoesNotExist')).status, 404);
  assert.equal((await fetch(base + '/mock/server.mjs')).status, 404);
  assert.equal((await api('Login/LogoutEmployee', {})).body, true);
  assert.equal((await api('Login/GetRewardsData', undefined, refreshed.body.accessToken)).status, 401);
});

test('calculator responds to plan, coverage, HSA and retirement changes', () => {
  const input = employee();
  const initial = calculate(input);
  const family = calculate({ ...input, input_dmedcov: 'You + Family' });
  assert.ok(family.output_ctotrewards > initial.output_ctotrewards);
  const premier = calculate({ ...input, input_dmedplan: 'Anthem PPO Premier' });
  assert.equal(premier.output_flag_chsacont, 'hide');
  assert.ok(premier.output_cmedcostco > initial.output_cmedcostco);
  assert.equal(calculate({ ...input, input_dhsacontee: 2500 }).output_dhsacontee, 2500);
  assert.equal(calculate({ ...input, input_deepesprate: 3 }).output_cerpesp, 3000);
  assert.equal(calculate({ ...input, input_dmedcov: 'No Coverage' }).output_cmedcostco, 0);
  assert.equal(calculate({ ...input, input_ddencov: 'No Coverage' }).output_cdencostco, 0);
  assert.equal(initial.output_ctotrewards, initial.output_ctotcomp + initial.output_ctothealth + initial.output_ctotinsur);
  assert.equal(initial.output_cbencostpctco + initial.output_cbencostpctee, 1);
});

test('mock bypasses are gated by both loopback hostname and server bootstrap', async () => {
  const login = await readFile(new URL('../js/logon/login.js', import.meta.url), 'utf8');
  const calculator = await readFile(new URL('../js/excelapi.js', import.meta.url), 'utf8');
  for (const [hostname, enabled, expected] of [
    ['127.0.0.1', true, '/api/Login'],
    ['localhost', true, '/api/Login'],
    ['localhost', false, 'http://localhost:57858/api/Login'],
    ['example.com', true, 'https://ceservice.alight.com/ato/api/Login']
  ]) {
    const context = { location: { hostname }, window: { ATO_LOCAL_MOCK: enabled }, console: { log() {} } };
    vm.createContext(context);
    vm.runInContext(login, context);
    assert.equal(context.webApiRootUrl, expected);
    assert.equal(context.isLocalMock, expected === '/api/Login');
  }
  const context = {
    location: { hostname: '127.0.0.1' }, window: { ATO_LOCAL_MOCK: true },
    sessionStorage: { getItem: () => JSON.stringify({ input_data: employee() }) },
    $: () => ({ val: () => 'Anthem PPO Premier' }),
    cleanInput: value => value
  };
  let url;
  context.$.ajax = options => { url = options.url; };
  vm.createContext(context);
  vm.runInContext(calculator, context);
  context.excel2api();
  assert.equal(url, '/api/calculate');
});
