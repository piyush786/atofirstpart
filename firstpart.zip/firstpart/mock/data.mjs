export function employee(username = 'Alex') {
  const name = username.split('@')[0].replace(/[^a-zA-Z0-9 ._-]/g, '').trim().slice(0, 30) || 'Alex';
  return {
    input_FNAME: name,
    input_LNAME: 'Sample',
    input_STATE: 'CA',
    input_DataAsOfDt: '2026-10-17T12:00:00Z',
    input_BASESAL: 100000,
    input_TARGBONUS: 10000,
    input_TBPCT: '10%',
    input_COMMTARG: 0,
    input_SIGNON: 5000,
    input_RELO: 0,
    input_CARALLOW: 1200,
    input_COMPCAR: 0,
    input_SHIFTDIFF: 0,
    input_CELLSUB: 600,
    input_TECHSUB: 300,
    input_NQDC: 0,
    input_partfullind: 'Full Time',
    input_dmedplan: 'Anthem PPO Consumer with HSA',
    input_dmedcov: 'You Only',
    input_ddenplan: 'DENTAL PLAN',
    input_ddencov: 'You Only',
    input_deepesprate: 10,
    input_dhsacontee: 0
  };
}

// Illustrative values only; this is not a reproduction of the benefits workbook.
export function calculate(input) {
  const number = key => Math.max(0, Number(input[key]) || 0);
  const coverage = value => ({
    'You Only': 1,
    'You + Spouse/Domestic Partner': 2,
    'You + Child(ren)': 1.8,
    'You + Family': 2.8,
    'No Coverage': 0
  })[value] ?? 1;
  const plan = input.input_dmedplan || 'Anthem PPO Consumer with HSA';
  const medicalBase = ({
    'Anthem PPO Premier': 9600,
    'Anthem PPO Choice': 8000,
    'Anthem PPO Consumer with HSA': 6400,
    'Kaiser HMO': 7200,
    'HMSA Hawaii PPO': 8800
  })[plan] ?? 6400;
  const medical = medicalBase * coverage(input.input_dmedcov);
  const dental = 600 * coverage(input.input_ddencov);
  const hsa = plan.includes('HSA') && medical > 0;
  const salary = number('input_BASESAL');
  const supplementalKeys = ['TARGBONUS', 'COMMTARG', 'SIGNON', 'RELO', 'CARALLOW', 'COMPCAR', 'SHIFTDIFF', 'CELLSUB', 'TECHSUB'];
  const supplemental = supplementalKeys.reduce((sum, key) => sum + number('input_' + key), 0);
  const retirement = salary * Math.min(number('input_deepesprate'), 10) / 100;
  const result = {
    output_csupppay: supplemental,
    output_ccbcont: salary + supplemental,
    output_ctotcomp: salary + supplemental,
    output_cmedcostco: medical * 0.8,
    output_cmedcostee: medical * 0.2,
    output_chsacontco: hsa ? 1000 : 0,
    output_dhsacontee: hsa ? number('input_dhsacontee') : 0,
    output_cdencostco: dental * 0.8,
    output_cdencostee: dental * 0.2,
    output_ceepesp: salary * Math.min(number('input_deepesprate'), 100) / 100,
    output_cerpesp: retirement,
    output_csocsecco: salary * 0.0765,
    output_csocsecee: salary * 0.0765,
    output_cbaslifaddco: 240,
    output_cbaslifeamt: salary * 2,
    output_cbasaddamt: salary * 2,
    output_cbtravcostco: 60,
    output_cbtravamt: salary * 3,
    output_cstdcostco: 300,
    output_cstd100: '6 weeks',
    output_cstd70: '20 weeks',
    output_cltdcostco: 480,
    output_cltdcostee: 0,
    output_cltdamttot: salary * 0.6 / 12,
    output_flag_chsacont: hsa ? 'show' : 'hide',
    output_flag_NQDC: number('input_NQDC') > 0 ? 'show' : 'hide'
  };
  for (const key of supplementalKeys) {
    result['output_flag_' + key.toLowerCase()] = number('input_' + key) > 0 ? 'show' : 'hide';
  }
  result.output_ctothealth = result.output_cmedcostco + result.output_chsacontco + result.output_cdencostco;
  result.output_ctotinsur = retirement + result.output_csocsecco + result.output_cbaslifaddco + result.output_cbtravcostco + result.output_cstdcostco + result.output_cltdcostco + number('input_NQDC');
  result.output_cbencostco = result.output_ctothealth + result.output_ctotinsur;
  const employeeCost = result.output_cmedcostee + result.output_cdencostee + result.output_dhsacontee + result.output_ceepesp + result.output_csocsecee;
  const combinedCost = result.output_cbencostco + employeeCost;
  result.output_cbencostpctco = combinedCost ? result.output_cbencostco / combinedCost : 0;
  result.output_cbencostpctee = combinedCost ? employeeCost / combinedCost : 0;
  result.output_ctotrewards = result.output_ctotcomp + result.output_cbencostco;
  return result;
}
