import http from 'node:http';
import { readFile, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import { employee, calculate } from './data.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const mime = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.svg': 'image/svg+xml', '.woff': 'font/woff',
  '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.eot': 'application/vnd.ms-fontobject',
  '.pdf': 'application/pdf', '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
};

export function createServer() {
  const sessions = new Map();
  const send = (res, status, value) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(value));
  };
  const issueTokens = session => {
    const encode = value => Buffer.from(JSON.stringify(value)).toString('base64');
    session.token = `${encode({ alg: 'none', typ: 'JWT' })}.${encode({ sub: 'local-mock', exp: Math.floor(Date.now() / 1000) + 3600, jti: randomUUID() })}.local`;
    session.refreshToken = randomUUID();
    return { token: session.token, accessToken: session.token, refreshToken: session.refreshToken };
  };

  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://127.0.0.1');
      if (url.pathname.startsWith('/api/')) {
        const cookie = (req.headers.cookie || '').split(';').map(item => item.trim()).find(item => item.startsWith('ato_mock='));
        const id = cookie?.slice('ato_mock='.length);
        let session = sessions.get(id);
        let body = '';
        for await (const chunk of req) {
          body += chunk;
          if (body.length > 65536) { send(res, 413, { error: 'Request too large' }); return; }
        }
        let data = {};
        if (body) {
          try { data = JSON.parse(body); } catch { send(res, 400, { error: 'Expected JSON' }); return; }
        }
        const action = url.pathname.replace('/api/Login/', '');
        const postActions = ['GetLoginFlags', 'ValidateUsername', 'ValidatePassword', 'ValidateAuthCode', 'ResendCode', 'ForgotPassword', 'ResetPassword', 'RefreshToken', 'LogoutEmployee', 'Exit', 'LoginAsEmployee'];
        const method = url.pathname === '/api/calculate' || postActions.includes(action) ? 'POST' : 'GET';
        if (req.method !== method) { send(res, 405, { error: 'Method not allowed' }); return; }

        if (action === 'GetRSAKeyData') { send(res, 200, { rsA_E: '010001', rsA_M: '01' }); return; }
        if (action === 'ValidateUsername' || action === 'LoginAsEmployee') {
          const username = action === 'LoginAsEmployee' ? 'Alex' : typeof data === 'string' ? data.trim() : '';
          if (!username) { send(res, 400, { status: false, errorMsg: 'Enter any username.' }); return; }
          // Replace the existing local session without retaining credentials.
          if (id) sessions.delete(id);
          const newId = randomUUID();
          session = { username, passwordChecked: false, otpValidated: false, reset: false };
          sessions.set(newId, session);
          res.setHeader('Set-Cookie', `ato_mock=${newId}; HttpOnly; SameSite=Strict; Path=/`);
          send(res, 200, action === 'LoginAsEmployee' ? issueTokens(session) : { status: true, isFirstTimeUser: false, errorMsg: '' });
          return;
        }
        if (!session) { send(res, 401, { status: false, errorMsg: 'Start at the local login page.' }); return; }
        if (action === 'GetLoginFlags') {
          send(res, 200, { isProfileComplete: true, isResetPassword: session.reset, isLoginPasswordCheck: session.passwordChecked, hasOTP: session.passwordChecked || session.reset, isOTPValidated: session.otpValidated }); return;
        }
        if (action === 'ValidatePassword') {
          if (typeof data.Password !== 'string' || !data.Password.length) { send(res, 400, { status: false, errorMsg: 'Enter any password.' }); return; }
          session.passwordChecked = true;
          send(res, 200, { status: true, isUserLocked: false, errorMsg: '' }); return;
        }
        if (action === 'ResendCode' || action === 'ForgotPassword') {
          if (action === 'ForgotPassword') session.reset = true;
          send(res, 200, { status: true, errorMsg: '' }); return;
        }
        if (action === 'ValidateAuthCode') {
          if ((!session.passwordChecked && !session.reset) || !/^\d{6}$/.test(data.Code || '')) {
            send(res, 200, { status: false, errorMsg: 'Use any 6-digit code, for example 123456.' }); return;
          }
          session.otpValidated = true;
          send(res, 200, { status: true, errorMsg: '', ...issueTokens(session) }); return;
        }
        if (action === 'ResetPassword') {
          if (!session.otpValidated || typeof data.Password !== 'string' || !data.Password.length) { send(res, 400, { status: false, error: 'Verify a code and enter a password.' }); return; }
          session.reset = false;
          send(res, 200, { status: true, ...issueTokens(session) }); return;
        }
        if (action === 'LogoutEmployee' || action === 'Exit') {
          sessions.delete(id);
          res.setHeader('Set-Cookie', 'ato_mock=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
          send(res, 200, true); return;
        }
        if (action === 'RefreshToken') {
          if (!session.token || data.accessToken !== session.token || data.refreshToken !== session.refreshToken) { send(res, 401, { error: 'Invalid local session' }); return; }
          send(res, 200, issueTokens(session)); return;
        }
        if (action === 'GetRewardsData') {
          if (!session.token || req.headers.authorization !== `Bearer ${session.token}`) { send(res, 401, { error: 'Invalid local token' }); return; }
          send(res, 200, { ssoData: JSON.stringify({ input_data: employee(session.username) }) }); return;
        }
        if (url.pathname === '/api/calculate') {
          if (!session.token) { send(res, 401, { error: 'Sign in first' }); return; }
          send(res, 200, calculate(data)); return;
        }
        send(res, 404, { error: 'This API is not included in the local mock.' }); return;
      }

      if (req.method !== 'GET' && req.method !== 'HEAD') { send(res, 405, { error: 'Method not allowed' }); return; }
      let pathname = decodeURIComponent(url.pathname);
      if (pathname === '/') pathname = '/index.html';
      if (pathname === '/favicon.ico') { res.writeHead(204); res.end(); return; }
      const filename = await realpath(path.join(root, pathname));
      if (!filename.startsWith(root) || pathname.split('/').some(part => part.startsWith('.')) || !mime[path.extname(filename)]) {
        send(res, 404, { error: 'Not found' }); return;
      }
      let content = await readFile(filename);
      if (path.extname(filename) === '.html') {
        content = Buffer.from(content.toString().replace(/<head>/i, '<head>\n<script src="/mock/local.js"></script>'));
      }
      res.writeHead(200, { 'Content-Type': mime[path.extname(filename)], 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
      res.end(req.method === 'HEAD' ? undefined : content);
    } catch (error) {
      send(res, error.code === 'ENOENT' || error.code === 'EISDIR' ? 404 : 400, { error: 'Unable to serve this local request.' });
    }
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  const server = createServer();
  server.on('error', error => { console.error(`Local preview could not start: ${error.message}`); process.exitCode = 1; });
  server.listen(port, '127.0.0.1', () => {
    console.log(`ATO local mock running at http://127.0.0.1:${port}`);
    console.log('Use any non-empty username/password and any 6-digit code. No real API requests are made by the root portal.');
  });
}
